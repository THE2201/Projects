<?php
require('../php/connectionBD.php');

$idEntrega = $_POST['edit_idEntrega'];
$campus = $_POST['edit_campus'];
$cuenta = $_POST['edit_cuenta'];
$alumno = $_POST['edit_alumno'];
$fechaEntrega= $_POST['edit_fechaEntrega'];

echo "<script>console.log('Valor de campus:', '" . $campus . "');</script>";

$estado = "Activo";
$fecha = date("Y-m-d H:i:s");

$sql = "SELECT idCampus FROM campus WHERE campus = '$campus' AND estado = 'Activo'";
$result = $Conn->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $idCampus = $row['idCampus'];
} else {
    echo "Error: No se encontró el campus en la base de datos.";
    exit();
}

    
      
        $ins = "UPDATE entregas SET  cuenta = '$cuenta', alumno = '$alumno', idCampus = '$idCampus ',fechaEntrega= '$fechaEntrega' WHERE idEntrega = '$idEntrega'";
        if (mysqli_query($Conn, $ins)) {
            echo "<script>alert('Registro editado.');</script>";

            

            header("Location: ../pages/entregas.php");
            exit();
        } else {
            echo "Error al guardar datos para prestamo: " . mysqli_error($Conn);
        }
    

$Conn->close();



?>
