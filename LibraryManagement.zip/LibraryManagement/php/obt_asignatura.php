<?php
require('connectionBD.php'); 

if(isset($_POST['idAsignatura'])) {
    $idAsignatura = $_POST['idAsignatura'];

    $sql = "SELECT * FROM asignaturas WHERE idAsignatura = $idAsignatura";
    $result = $Conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        echo json_encode($row);
    } else {
        echo json_encode(array('error' => 'No se encontró ningún registro con el ID proporcionado.'));
    }
} else {
    echo json_encode(array('error' => 'ID de registro no proporcionado.'));
}
?>