<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require('connectionBD.php');

    $idEditorial = $_POST['edit_idEditorial'];
    $nombre = $_POST['edit_nombre'];
    $correo = $_POST['edit_correo'];
    $telefono = $_POST['edit_telefono'];
    $descripcion = $_POST['edit_descripcion'];


    if(empty($idEditorial) || empty($nombre) || empty($correo) || empty($telefono) || empty($descripcion)){
        echo"Espacios vacios, complete";
    }else{

    $sql = "UPDATE editoriales SET nombre = '$nombre', correo = '$correo', telefono = '$telefono', descripcion = '$descripcion' WHERE idEditorial = '$idEditorial'";
    if ($Conn->query($sql) === TRUE) {
        echo "Registro actualizado correctamente";
    } else {
        echo "Error al actualizar el registro: " . $Conn->error;
    }
    $Conn->close();
    }

    
    
} else {
    echo "Error: No se recibieron los datos del formulario correctamente";
}
?>
