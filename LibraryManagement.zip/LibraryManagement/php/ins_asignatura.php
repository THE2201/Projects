<?php
require('../php/connectionBD.php');

$asignatura = $_POST['asignatura'];
$estado = "Activo";
$fecha = date("Y-m-d H:i:s");

if (empty($asignatura)) {
    echo 'Rellene campo asignatura vacío';
} else {
    $sql = "INSERT INTO asignaturas (asignatura, estado, fecha) 
        VALUES ('$asignatura', '$estado', '$fecha')";

    try {
        if ($Conn->query($sql) === TRUE) {
            echo "Datos guardados correctamente";
        } else {
            echo "Error al guardar datos ya esta registrada la clase $asignatura";
        }
    } catch (mysqli_sql_exception $e) {
        if ($e->getCode() === 1062) {
            echo "La asignatura $asignatura ya está registrada.";
        } else {
            echo "Error al guardar datos: " . $e->getMessage();
        }
    }

    $Conn->close();
}
?>