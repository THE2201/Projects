<?php
$SERVER = '127.0.0.1';
$USERNAME = 'root';
$PASSWORD = '';
$DB = 'bd_biblioteca';

$Conn = mysqli_connect($SERVER, $USERNAME, $PASSWORD, $DB) or die("Error de conexión: " . mysqli_connect_error());

$idCampus = $_POST['idCampus'];
$nuevoCampus = $_POST['nuevoCampus'];
$nuevaDireccion = $_POST['nuevaDireccion'];

if (empty($nuevoCampus) || empty($nuevaDireccion)) { 
    echo "Todos los campos son obligatorios";
} else {

$query = "UPDATE campus SET campus = '$nuevoCampus', direccion = '$nuevaDireccion', fecha = NOW() WHERE idCampus = $idCampus";

try {
    if (mysqli_query($Conn, $query)) {
        echo "Datos guardados correctamente";
    }
} catch (mysqli_sql_exception $e) {
   
    if ($e->getCode() === 1062) {
        echo "Error, El campus '$nuevoCampus' ya está registrado.";
    } else {
        echo "Error al guardar datos: " . $e->getMessage();
    }
}
}


mysqli_close($Conn);
?>

