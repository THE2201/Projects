<?php
require('connectionBD.php'); 

if(isset($_POST['idGenero'])) {
    $idGenero = $_POST['idGenero'];

    $sql = "SELECT * FROM generos WHERE idGenero = $idGenero";
    $result = $Conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        echo json_encode($row);
    } else {
        echo json_encode(array('error' => 'No se encontró ningún registro con el ID proporcionado.'));
    }
} else {
    echo json_encode(array('error' => 'ID de registro no proporcionado.'));
}
?>