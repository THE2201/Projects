<?php
require('../php/connectionBD.php');

$nombre = $_POST['nombre'];
$correo = $_POST['correo'];
$telefono = $_POST['telefono'];
$descripcion = $_POST['descripcion'];


$estado = "Activo";
$fecha = date("Y-m-d H:i:s");

$sql = "INSERT INTO editoriales (nombre, correo, telefono, descripcion, estado, fecha) 
        VALUES ('$nombre', '$correo', '$telefono', '$descripcion', '$estado', '$fecha')";

if ($Conn->query($sql) === TRUE) {
    header("Location: ../pages/editorial.php");
    exit();
} else {
    echo "Error al insertar el registro: " . $Conn->error;
}

$Conn->close();
?>