<?php
require('connectionBD.php');

if (isset($_POST['idGenero'])) {
    $idGenero = $_POST['idGenero'];

    $sql = "UPDATE generos SET estado = 'Inactivo' WHERE idGenero = $idGenero";

    if ($Conn->query($sql) === TRUE) {
        echo "Registro borrado exitosamente.";
    } else {
        echo "Error al borrar el registro: " . $Conn->error;
    }
} else {
    echo "ID de artículo no recibido.";
}
?>
