<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require('connectionBD.php');

    $idArticulo = $_POST['edit_idArticulo'];
    $articulo = $_POST['edit_articulo'];
    $descripcion = $_POST['edit_descripcion'];
    $cantidad = $_POST['edit_cantidad'];

    if (empty($idArticulo) || empty($articulo) || empty($descripcion) || empty($cantidad)) {
        echo'Rellenar campos de articulo vacio.';
    }else{
        $sql = "UPDATE mobiliario SET articulo = '$articulo', descripcion = '$descripcion', cantidad = '$cantidad' WHERE idArticulo = '$idArticulo'"; 
        if ($Conn->query($sql) === TRUE) {
            header("Location: ../pages/mobiliario.php");
        } else {
            echo "Error al actualizar el registro: " . $Conn->error;
        }
        $Conn->close();
    }
} else {
    echo "Error: No se recibieron los datos del formulario correctamente";
}
?>
