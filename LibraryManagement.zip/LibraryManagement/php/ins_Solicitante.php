<?php
require('../php/connectionBD.php');

$campus = $_POST['campus'];
$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$dni = $_POST['dni'];
$tipo = $_POST['tipo'];
$contacto = $_POST['contacto'];
$direccion = $_POST['direccion'];
$estado = "Activo";

$sql = "INSERT INTO solicitantes (idCampus, nombre, apellido, dni, tipo, contacto, direccion, estado) 
VALUES ('$campus', '$nombre', '$apellido', '$dni', '$tipo', '$contacto', '$direccion','$estado' )";

if ($Conn->query($sql) === TRUE) {
    header("Location: ../pages/solicitantes.php");
    exit();
} else {
    echo "Error al insertar el registro: " . $Conn->error;
}

$Conn->close();
?>