<?php
require('../php/connectionBD.php');


//editar

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  

    $idpermiso = $_POST['edit_idPermiso'];
    $agregar = isset($_POST["edit_agregar"]) ? 1 : 0;
    $editar = isset($_POST["edit_editar"]) ? 1 : 0;
    $eliminar = isset($_POST["edit_eliminar"]) ? 1 : 0;
    

    $sql = "UPDATE permisos SET agregar = '$agregar', editar = '$editar', eliminar = '$eliminar'  WHERE idPermiso = '$idpermiso'";

    if ($Conn->query($sql) === TRUE) {
        echo "Registro actualizado correctamente";
    } else {
        echo "Error al actualizar el registro: " . $Conn->error;
    }
} else {
    echo "Error: No se recibieron los datos del formulario correctamente editar 2";
}


?>