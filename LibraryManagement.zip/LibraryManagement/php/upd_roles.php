<?php
require('../php/connectionBD.php');


//editar

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  

    $idrol = $_POST['edit_idrol'];
    $nombre = $_POST['edit_nombre'];
    $libro = isset($_POST["edit_libros"]) ? 1 : 0;
    $mobiliario = isset($_POST["edit_mobiliario"]) ? 1 : 0;
    $prestamo = isset($_POST["edit_prestamo"]) ? 1 : 0;
    $solicitantes = isset($_POST["edit_solicitantes"]) ? 1 : 0;
    $reportes = isset($_POST["edit_reportes"]) ? 1 : 0;
    $configuracion = isset($_POST["edit_configuracion"]) ? 1 : 0;

    $sql = "UPDATE rol SET nombre = '$nombre', libro = '$libro', mobiliario = '$mobiliario' , prestamo = '$prestamo' , solicitantes = '$solicitantes' , reportes = '$reportes', configuracion = '$configuracion' WHERE idrol = '$idrol'";

    if ($Conn->query($sql) === TRUE) {
        echo "Registro actualizado correctamente";
    } else {
        echo "Error al actualizar el registro: " . $Conn->error;
    }
} else {
    echo "Error: No se recibieron los datos del formulario correctamente editar 2";
}


?>