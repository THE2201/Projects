<?php
require('../php/connectionBD.php');

$genero = $_POST['genero'];



$estado = "Activo";
$fecha = date("Y-m-d H:i:s");

$sql = "INSERT INTO generos (genero, estado, fecha) 
        VALUES ('$genero', '$estado', '$fecha')";

if ($Conn->query($sql) === TRUE) {
    header("Location: ../pages/generos.php");
    exit();
} else {
    echo "Error al insertar el registro: " . $Conn->error;
}

$Conn->close();
?>