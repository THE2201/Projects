<?php

require('connectionBD.php');


//Pendiente validacion de vacios //Abel

// Verificar si se reciben los datos del formulario
if(isset($_POST['campus'], $_POST['seccion'], $_POST['genero'], $_POST['titulo'], $_POST['autor'], $_POST['editorial'], $_POST['idioma'], $_POST['cantidad'])) {
    
    // Obtener los datos del formulario
    $campus = $_POST['campus'];
    $seccion = $_POST['seccion'];
    $genero = $_POST['genero'];
    $titulo = $_POST['titulo'];
    $autor = $_POST['autor'];
    $editorial = $_POST['editorial'];
    $idioma = $_POST['idioma'];
    $cantidad = $_POST['cantidad'];

    // Establecer el estado y la fecha
    $estado = "Activo";
    $fecha = date("Y-m-d H:i:s");


    

    // Realizar la inserción de datos
    $sql = "INSERT INTO libros (idCampus, idSeccion, idGenero, titulo, autor, ideditorial, idioma,  total, disponible, estado, fecha) 
            VALUES ('$campus', '$seccion', '$genero', '$titulo', '$autor', '$editorial', '$idioma',  '$cantidad', '$cantidad','$estado', '$fecha')";

    if ($Conn->query($sql) === TRUE) {
        
        header("Location: ../pages/libro.php");
    } else {
        echo "Error al insertar el registro: " . $Conn->error;
    }

    $Conn->close();

} else {
    // Si no se reciben los datos del formulario, devolver mensaje de error
    echo "Error: Se deben proporcionar todos los datos del libro.";
}
?>
