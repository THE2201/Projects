<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require('connectionBD.php');

    $idSeccion = $_POST['edit_idSeccion'];
    $seccion = $_POST['edit_seccion'];
    $descripcion = $_POST['edit_descripcion'];

    $sql = "UPDATE secciones SET seccion = '$seccion', descripcion = '$descripcion' WHERE idSeccion = '$idSeccion'";

    if ($Conn->query($sql) === TRUE) {
        echo "Registro actualizado correctamente";
    } else {
        echo "Error al actualizar el registro: " . $Conn->error;
    }

    $Conn->close();
} else {
    echo "Error: No se recibieron los datos del formulario correctamente";
}
?>
