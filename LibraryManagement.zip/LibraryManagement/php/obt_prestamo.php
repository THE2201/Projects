<?php
require('../php/connectionBD.php');

if(isset($_POST['idPrestamo'])) {
    $idPrestamo = $_POST['idPrestamo'];

    $sql = "SELECT p.idPrestamo, l.titulo AS nombreLibro, CONCAT(s.nombre, ' ', s.apellido) AS nombreSolicitante, p.cantidad, p.fechaIni, p.fechaFin, p.estado, p.fecha 
            FROM prestamo p
            LEFT JOIN libros l ON p.idLibro = l.idLibros
            LEFT JOIN solicitantes s ON p.idCliente = s.idSolicitante
            WHERE p.idPrestamo = $idPrestamo";

    $result = $Conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo json_encode($row);
    } else {
        echo json_encode(array('error' => 'No se encontró el préstamo'));
    }

    $Conn->close();
} else {
    echo json_encode(array('error' => 'No se proporcionó el ID del préstamo'));
}
?>
