<?php
// Establecer conexión a la base de datos
$servername = '127.0.0.1';
$username = 'root';
$password = '';
$dbname = 'bd_biblioteca';

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Verificar si se recibió el ID del campus
if (isset($_POST['idCampus'])) {
    // Obtener el ID del campus seleccionado
    $campus_id = $_POST['idCampus'];

    // Consulta para obtener las secciones del campus seleccionado
    $sql = "SELECT idSeccion, seccion FROM secciones WHERE idCampus = $campus_id";
    $result = $conn->query($sql);

    // Verificar si se encontraron resultados
    if ($result->num_rows > 0) {
        // Crear un array para almacenar las secciones
        $secciones = array();

        // Recorrer los resultados y añadirlos al array de secciones
        while ($row = $result->fetch_assoc()) {
            $secciones[] = $row;
        }

        // Devolver las secciones en formato JSON
        header('Content-Type: application/json');
        echo json_encode($secciones);
    } else {
        // Si no se encontraron secciones, devolver un array vacío
        header('Content-Type: application/json');
        echo json_encode(array());
    }
} else {
    // Si no se recibió el ID del campus, devolver un mensaje de error
    header('HTTP/1.1 400 Bad Request');
    echo 'Error: No se recibió el ID del campus.';
}

// Cerrar conexión
$conn->close();
?>
