<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require('connectionBD.php');

    $idAsignatura = $_POST['edit_idAsignatura'];
    $asignatura = $_POST['edit_asignatura'];
    
   
    if (empty($asignatura)) {
        echo 'Rellene campo asignatura vacio';
    } else {
        $sql = "UPDATE asignaturas SET asignatura = '$asignatura' WHERE idAsignatura = '$idAsignatura'";
        try {
            if ($Conn->query($sql) === TRUE) {
                echo "Datos guardados correctamente";
            }
        } catch (mysqli_sql_exception $e) {
    
            if ($e->getCode() === 1062) {
                echo "La asignatura $asignatura ya está registrada.";
            
            } else {
                echo "Error al guardar datos: " . $e->getMessage();
            }
        }
        $Conn->close();
    }

}
?>



