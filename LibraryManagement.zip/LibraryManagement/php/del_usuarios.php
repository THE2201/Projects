<?php
require('connectionBD.php');

if (isset($_POST['idUsuario'])) {
    $idUsuario = $_POST['idUsuario'];

    $sql = "UPDATE usuarios SET estado = 'Inactivo' WHERE idUsuario = $idUsuario";

    if ($Conn->query($sql) === TRUE) {
        echo "Registro borrado exitosamente.";
    } else {
        echo "Error al borrar el registro: " . $Conn->error;
    }
} else {
    echo "ID de artículo no recibido.";
}
?>
