<?php

require('../php/connectionBD.php');

// Guardar
if (isset($_POST["guardar"])) {
    $nombre = $_POST['nombre'];
    
    // Obtener valores de los checkbox
    $libro = isset($_POST["libro"]) ? 1 : 0;
    $mobiliario = isset($_POST["mobiliario"]) ? 1 : 0;
    $prestamo = isset($_POST["prestamo"]) ? 1 : 0;
    $solicitantes = isset($_POST["solicitantes"]) ? 1 : 0;
    $reportes = isset($_POST["reportes"]) ? 1 : 0;
    $configuracion = isset($_POST["configuracion"]) ? 1 : 0;

    $estado = "Activo";
    $fecha = date("Y-m-d H:i:s");
    
    // Primero insertar en la tabla permisos
    $sql = "INSERT INTO permisos (agregar, editar, eliminar, estado, fecha) 
            VALUES ('0', '0', '0', '$estado', '$fecha')";
    
    if ($Conn->query($sql) === TRUE) {
        // Obtener el ID del permiso insertado
        $idpermiso = $Conn->insert_id;
        
        // Insertar en la tabla rol utilizando el idpermiso obtenido
        $sql_rol = "INSERT INTO rol (idpermiso, nombre, libro, mobiliario, prestamo, solicitantes, reportes, configuracion, estado, fecha) 
                    VALUES ('$idpermiso', '$nombre', '$libro', '$mobiliario', '$prestamo', '$solicitantes', '$reportes', '$configuracion', '$estado', '$fecha')";
        
        if ($Conn->query($sql_rol) === TRUE) {
            $Conn->close();
            header("Location: ../pages/roles.php");
            exit();
        } else {
            echo "Error al insertar el registro en la tabla rol: " . $Conn->error;
        }
    } else {
        echo "Error al insertar el registro en la tabla permisos: " . $Conn->error;
    }
} else {
    echo "Error al procesar el formulario guardar.";
}

/*

if (isset($_POST["guardarcam"])){

//editar

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  

    $idrol = $_POST['edit_idrol'];
    $nombre = $_POST['edit_nombre'];
    $libro = isset($_POST["edit_libro"]) ? 1 : 0;
    $mobiliario = isset($_POST["edit_mobiliario"]) ? 1 : 0;
    $prestamo = isset($_POST["edit_prestamo"]) ? 1 : 0;
    $solicitantes = isset($_POST["solicitantes"]) ? 1 : 0;
    $reportes = isset($_POST["edit_reportes"]) ? 1 : 0;
    $configuracion = isset($_POST["edit_configuracion"]) ? 1 : 0;

    $sql = "UPDATE rol SET nombre = '$nombre', libro = '$libro', mobiliario = '$mobiliario' , prestamo = '$prestamo' , solicitantes = '$solicitantes' , reportes = '$reportes', configuracion = '$configuracion' WHERE idrol = '$idrol'";

    if ($Conn->query($sql) === TRUE) {
        echo "Registro actualizado correctamente";
    } else {
        echo "Error al actualizar el registro: " . $Conn->error;
    }
} else {
    echo "Error: No se recibieron los datos del formulario correctamente editar 2";
}
}else {
    echo "Error: No se recibieron los datos del formulario correctamente editar";
}





if (isset($_POST["guaram"])) {

if (isset($_POST['idrol'])) {
    $idArticulo = $_POST['idrol'];

    $sql = "UPDATE  SET estado = 'Inactivo' WHERE idArticulo = $idArticulo";

    if ($Conn->query($sql) === TRUE) {
        echo "Registro borrado exitosamente.";
    } else {
        echo "Error al borrar el registro: " . $Conn->error;
    }
} else {
    echo "ID de artículo no recibido.";
}
}else {
    echo "Error al procesar el formulario.";
}


?>
*/