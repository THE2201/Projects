<?php
require('../php/connectionBD.php');

$idUsuario = $_POST['edit_idUsuario']; // Asumiendo que recibes el ID del usuario que deseas actualizar
$usuarios = $_POST['edit_usuario'];
$rol_nombre = $_POST['edit_rol'];
$nombre = $_POST['edit_nombre'];
$apellido = $_POST['edit_apellido'];
$campus_nombre = $_POST['edit_campus'];

$estado = "Activo";
$fecha = date("Y-m-d H:i:s");

// Obtener el ID del rol
$sql = "SELECT idrol FROM rol WHERE nombre = '$rol_nombre' AND estado = 'Activo'";
$result = $Conn->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $idRol = $row['idrol'];
} else {
    echo "Error: No se encontró el rol en la base de datos.";
    exit();
}

// Obtener el ID del campus
$sql = "SELECT idCampus FROM campus WHERE campus = '$campus_nombre' AND estado = 'Activo'";
$result = $Conn->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $idCampus = $row['idCampus'];
} else {
    echo "Error: No se encontró el campus en la base de datos.";
    exit();
}

// Actualizar el registro del usuario
$sql = "UPDATE usuarios 
        SET usuario = '$usuarios', 
            idRol = '$idRol', 
            nombre = '$nombre', 
            apellido = '$apellido', 
            idcampus = '$idCampus', 
            estado = '$estado', 
            fecha = '$fecha' 
        WHERE idUsuario = '$idUsuario'";

try {
    if ($Conn->query($sql) === TRUE) {
        echo "Datos guardados correctamente";
    }
} catch (mysqli_sql_exception $e) {
   
    if ($e->getCode() === 1062) {
        echo "Error, El usuario '$usuarios' ya está registrado.";
    } else {
        echo "Error al guardar datos: " . $e->getMessage();
    }
}
$Conn->close();
?>
