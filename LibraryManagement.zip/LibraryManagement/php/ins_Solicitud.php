<?php
require('../php/connectionBD.php');

$usuario = $_POST['usuario'];
$descripcion = $_POST['descripcion'];
$estado = "Activo";

// Obtener idCampus del usuario seleccionado
$sql_idcampus = "SELECT idcampus FROM usuarios WHERE idUsuario = '$usuario'";
$result_idcampus = $Conn->query($sql_idcampus);

if ($result_idcampus->num_rows > 0) {
    $row_idcampus = $result_idcampus->fetch_assoc();
    $idcampus = $row_idcampus['idcampus'];

    // Insertar en la tabla solicitudes
    $sql = "INSERT INTO solicitudes (idUsuario, IdCampus, descripcion, estado) 
            VALUES ('$usuario','$idcampus', '$descripcion', '$estado' )";

    if ($Conn->query($sql) === TRUE) {
        header("Location: ../pages/solicitudes.php");
        exit();
    } else {
        echo "Error al insertar el registro: " . $Conn->error;
    }
}
$Conn->close();
?>