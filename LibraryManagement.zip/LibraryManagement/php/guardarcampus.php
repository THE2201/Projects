<?php
$SERVER = '127.0.0.1';
$USERNAME = 'root';
$PASSWORD = '';
$DB = 'bd_biblioteca';

$Conn = mysqli_connect($SERVER, $USERNAME, $PASSWORD, $DB) or die("Error de conexión: " . mysqli_connect_error());

$campus = $_POST['campus'];
$direccion = $_POST['direccion'];
$estado = $_POST['estado'];

if (empty($campus) || empty($direccion) || empty($estado)) { 
    echo "Todos los campos son obligatorios";
} else {
    $fecha = date('Y-m-d H:i:s');

    $query = "INSERT INTO campus (campus, direccion, estado, fecha) VALUES ('$campus', '$direccion', '$estado', '$fecha')"; 

    try {
        if (mysqli_query($Conn, $query)) {
            echo "Datos guardados correctamente";
        }
    } catch (mysqli_sql_exception $e) {
       
        if ($e->getCode() === 1062) {
            echo "Error, El campus '$campus' ya está registrado.";
        } else {
            echo "Error al guardar datos: " . $e->getMessage();
        }
    }
}

mysqli_close($Conn);
?>
