<?php
$SERVER = '127.0.0.1';
$USERNAME = 'root';
$PASSWORD = '';
$DB = 'bd_biblioteca';

$Conn = mysqli_connect($SERVER, $USERNAME, $PASSWORD, $DB) or die("Error de conexión: " . mysqli_connect_error());

$idCampus = $_POST['idCampus'];

$query = "UPDATE campus SET estado = 'Inactivo' WHERE idCampus = $idCampus";

if (mysqli_query($Conn, $query)) {
    echo "Campus eliminado correctamente";
} else {
    echo "Error al eliminar campus: " . mysqli_error($Conn);
}

mysqli_close($Conn);
?>
