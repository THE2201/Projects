<?php
$SERVER = '127.0.0.1';
$USERNAME = 'root';
$PASSWORD = '';
$DB = 'bd_biblioteca';

$Conn = mysqli_connect($SERVER, $USERNAME, $PASSWORD, $DB) or die("Error de conexión: " . mysqli_connect_error());

$idLibrosAsignatura = $_POST['idLibrosAsignatura'];

$query = "UPDATE librosasignaturas SET estado = 'Inactivo' WHERE idLibrosAsignatura = $idLibrosAsignatura";

if (mysqli_query($Conn, $query)) {
    echo "Libro Eliminado correctamente";
} else {
    echo "Error al eliminar libro: " . mysqli_error($Conn);
}

mysqli_close($Conn);
?>
