<?php
require('connectionBD.php');

if (isset($_POST['idUsuario'])) {
    $idUsuario = $_POST['idUsuario'];

    $sql = "UPDATE usuarios SET password = 'temporal24' WHERE idUsuario = $idUsuario";

    if ($Conn->query($sql) === TRUE) {
        echo "Cambio exitosamente.";
    } else {
        echo "Error al borrar el registro: " . $Conn->error;
    }
} else {
    echo "ID de artículo no recibido.";
}
?>
