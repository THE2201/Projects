<?php
$servername = '127.0.0.1';
$username = 'root';
$password = '';
$dbname = 'bd_biblioteca';



// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener el ID del campus seleccionado
$idCampus = $_POST['idCampus'];

// Consulta SQL para obtener las secciones según el campus seleccionado
$sql = "SELECT idSeccion, seccion FROM secciones WHERE idCampus = $idCampus AND estado = 'Activo'";
$result = $conn->query($sql);

// Crear un array para almacenar las opciones de sección
$secciones = array();

// Obtener las secciones y agregarlas al array
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $secciones[] = $row;
    }
}

// Devolver las opciones de sección como JSON
echo json_encode($secciones);

// Cerrar conexión
$conn->close();
?>

