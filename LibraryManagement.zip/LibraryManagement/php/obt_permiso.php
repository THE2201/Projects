<?php
if(isset($_POST['idPermiso'])) {
    require('connectionBD.php'); 
    
    $idPermiso = $_POST['idPermiso'];

    $sql = "SELECT * FROM permisos WHERE idPermiso = $idPermiso";
    $result = $Conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        echo json_encode($row);
    } else {
        echo json_encode(array('error' => 'No se encontró la sección'));
    }

    $Conn->close();
} else {
    echo json_encode(array('error' => 'No se proporcionó el ID de la sección'));
}
?>