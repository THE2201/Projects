<?php
require('connectionBD.php');
if (isset($_POST['idPrestamo'])) {
    $idPrestamo = $_POST['idPrestamo'];

    // Cambiar el estado del préstamo a "Inactivo"
    $sql_update_estado = "UPDATE prestamo SET estado = 'Inactivo' WHERE idPrestamo = ?";
    $stmt_update_estado = $Conn->prepare($sql_update_estado);
    if ($stmt_update_estado === false) {
        die('Error de preparación de la consulta de actualización de estado: ' . $Conn->error);
    }
    $stmt_update_estado->bind_param('i', $idPrestamo);
    if (!$stmt_update_estado->execute()) {
        die('Error al ejecutar la consulta de actualización de estado: ' . $stmt_update_estado->error);
    }

    echo "Estado del préstamo actualizado correctamente.<br>";

    // Obtener el idlibro y la cantidad asociada al préstamo
    $sql_select = "SELECT idlibro, cantidad FROM prestamo WHERE idPrestamo = ?";
    $stmt_select = $Conn->prepare($sql_select);
    if ($stmt_select === false) {
        die('Error de preparación de la consulta de selección: ' . $Conn->error);
    }
    $stmt_select->bind_param('i', $idPrestamo);
    if (!$stmt_select->execute()) {
        die('Error al ejecutar la consulta de selección: ' . $stmt_select->error);
    }
    $stmt_select->bind_result($idlibro, $cantidad);
    $stmt_select->fetch();
    $stmt_select->close();

    echo "idlibro: " . $idlibro . ", cantidad: " . $cantidad . "<br>"; // Imprimir los valores de idlibro y cantidad

    // Actualizar el campo 'disponible' en la tabla 'libro' sumando la cantidad prestada
    $sql_update_libro = "UPDATE libros SET disponible = disponible + ? WHERE idLibros = ?";
    $stmt_update_libro = $Conn->prepare($sql_update_libro);
    if ($stmt_update_libro === false) {
        die('Error de preparación de la consulta de actualización del libro: ' . $Conn->error);
    }
    $stmt_update_libro->bind_param('ii', $cantidad, $idlibro);
    if (!$stmt_update_libro->execute()) {
        die('Error al ejecutar la consulta de actualización del libro: ' . $stmt_update_libro->error);
    }

    echo "Libro actualizado correctamente.";
}
  
?>
