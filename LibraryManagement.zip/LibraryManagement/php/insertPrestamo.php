<?php
require('../php/connectionBD.php');

$libro = $_POST['libro'];
$Cliente = $_POST['solicitante'];
$Canti = $_POST['cantidad'];
$fin = $_POST['fechaInicial'];
$ffi =  $_POST['fechaFinal'];
$fecha = date('Y-m-d H:i:s');
$primerN = explode(" ", $Cliente);



if (!$libro || !$Cliente || !$Canti || !$fin || !$ffi) {
    echo "<script>alert('Espacios vacios.');</script>";
} else {
    //Operacion para buscar ID del titulo de libros
    $sql = "SELECT idLibros, disponible from libros WHERE titulo='$libro'";
    $RS = mysqli_query($Conn, $sql);
    if (mysqli_num_rows($RS) > 0) {
        while ($dat = mysqli_fetch_assoc($RS)) {
            $idLib = $dat["idLibros"];
            $disp1 = $dat["disponible"];
        }
    }

    //Validaciones
    if ($Canti > $disp1) {
        echo "<script>alert('Cantidad de libros no disponible.');</script>";

        echo "<script>window.history.back();</script>";
    } else if ($Canti < 1) {
        echo "<script>alert('Cantidad de libros invalida.');</script>";
    } else if ($fin > $ffi) {
        echo "<script>alert('Fecha mal seleccionada');</script>";
    } else {
        //Busqueda de Usuario mediante ID
        $sql1 = "SELECT idSolicitante from solicitantes WHERE nombre='$primerN[0]'";
        $RS1 = mysqli_query($Conn, $sql1);
        if (mysqli_num_rows($RS1) > 0) {
            while ($dat = mysqli_fetch_assoc($RS1)) {
                $idSol = $dat["idSolicitante"];
            }
        }
        //Insercion NUEVA en Prestamos
        $ins = "INSERT INTO prestamo (idLibro, idCliente, cantidad, fechaIni, fechaFin, estado, fecha) VALUES ($idLib, $idSol, '$Canti' , '$fin', '$ffi', 'Activo', '$fecha')";
        if (mysqli_query($Conn, $ins)) {
            echo "<script>alert('Exito al registrar Prestamo.');</script>";

            //Actualizar libros disponibles del seleccionado
            $restaDisp = $disp1 - $Canti;
            $sql3 = "UPDATE libros SET disponible=$restaDisp WHERE idLibros=$idLib";
            mysqli_query($Conn, $sql3);

            header("Location: ../pages/prestamos.php");
            exit();
        } else {
            echo "Error al guardar datos para prestamo: " . mysqli_error($Conn);
        }
    }
}
$Conn->close();
?>
