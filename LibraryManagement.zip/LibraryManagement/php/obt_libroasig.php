<?php
require('../php/connectionBD.php');

if(isset($_POST['idLibrosAsignatura'])) {
    $idLibrosAsignatura = $_POST['idLibrosAsignatura'];

    $sql = "SELECT lb.idLibrosAsignatura, lb.titulo , lb.autor  , lb.estado, ca.campus, ag.asignatura, ed.nombre 
            FROM librosasignaturas lb
            LEFT JOIN campus ca ON lb.idCampus = ca.idCampus
            LEFT JOIN asignaturas ag ON lb.idAsignatura = ag.idAsignatura
            LEFT JOIN editoriales ed ON lb.ideditorial = ed.idEditorial
            WHERE lb.idLibrosAsignatura = $idLibrosAsignatura";

    $result = $Conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo json_encode($row);
    } else {
        echo json_encode(array('error' => 'No se encontró el préstamo'));
    }

    $Conn->close();
} else {
    echo json_encode(array('error' => 'No se proporcionó el ID del préstamo'));
}
?>
