<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require('connectionBD.php');

    $idSolicitante = $_POST['edit_idSolicitante'];
    $campus = $_POST['edit_campus'];
    $nombre = $_POST['edit_nombre'];
    $apellido = $_POST['edit_apellido'];
    $dni = $_POST['edit_dni'];
    $tipo = $_POST['edit_tipo'];
    $contacto = $_POST['edit_contacto'];
    $direccion = $_POST['edit_direccion'];

    if (empty($idSolicitante) || empty($campus) || empty($nombre) || empty($apellido) || empty($dni) || empty($tipo) || empty($contacto) || empty($direccion)) {
        echo 'Rellene espacios vacios del solicitante';
    } else {
        $sql = "UPDATE solicitantes SET idCampus = '$campus', nombre = '$nombre', apellido = '$apellido', dni = '$dni', tipo = '$tipo', contacto = '$contacto', direccion = '$direccion' WHERE idSolicitante = '$idSolicitante'";

        if ($Conn->query($sql) === TRUE) {
            echo "Registro actualizado correctamente";
        } else {
            echo "Error al actualizar el registro: " . $Conn->error;
        }
        $Conn->close();
    }
} else {
    echo "Error: No se recibieron los datos del formulario correctamente";
}
