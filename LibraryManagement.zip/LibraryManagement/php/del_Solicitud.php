<?php
require('connectionBD.php');

if (isset($_POST['idSolicitud'])) {
    $idSolicitud = $_POST['idSolicitud'];

    $sql = "UPDATE solicitudes SET estado = 'Inactivo' WHERE idSolicitud = $idSolicitud";

    if ($Conn->query($sql) === TRUE) {
        echo "Registro borrado exitosamente.";
    } else {
        echo "Error al borrar el registro: " . $Conn->error;
    }
} else {
    echo "ID de Solicitud no recibido.";
}
?>