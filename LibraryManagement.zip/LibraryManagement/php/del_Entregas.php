<?php
require('connectionBD.php');

if (isset($_POST['idEntrega'])) {
    $idEntrega = $_POST['idEntrega'];

    $sql = "UPDATE entregas SET estado = 'Inactivo' WHERE idEntrega = $idEntrega";

    if ($Conn->query($sql) === TRUE) {
        echo "Registro borrado exitosamente.";

     
        $sql3 = "UPDATE librosasignaturas SET disponible = disponible + 1 WHERE idLibrosAsignatura=$idEntrega";
        mysqli_query($Conn, $sql3);

        header("Location: ../pages/entregas.php");

    } else {
        echo "Error al borrar el registro: " . $Conn->error;
    }
} else {
    echo "idEntrega no recibido.";
}
?>
