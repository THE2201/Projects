<?php
require('../php/connectionBD.php');



$editorial = $_POST['editorial'];
$autor = $_POST['autor'];
$titulo = $_POST['titulo'];
$asignatura = $_POST['asignatura'];
$campus_nombre = $_POST['campus'];
$cantidad = $_POST['cantidad'];
$cantidad = $_POST['cantidad'];

$estado = "Activo";
$fecha = date("Y-m-d H:i:s");

// Obtener el ID del rol
$sql = "SELECT idEditorial FROM editoriales WHERE nombre = ? AND estado = 'Activo'";
$stmt = $Conn->prepare($sql);
$stmt->bind_param("s", $editorial);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $idEditorial = $row['idEditorial'];
} else {
    echo "Error: No se encontró el rol en la base de datos.";
    exit();
}

$sql = "SELECT idAsignatura FROM asignaturas WHERE asignatura = ? AND estado = 'Activo'";
$stmt = $Conn->prepare($sql);
$stmt->bind_param("s", $asignatura);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $idAsignatura = $row['idAsignatura'];
} else {
    echo "Error: No se encontró el rol en la base de datos.";
    exit();
}

// Obtener el ID del campus
$sql = "SELECT idCampus FROM campus WHERE campus = ? AND estado = 'Activo'";
$stmt = $Conn->prepare($sql);
$stmt->bind_param("s", $campus_nombre);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $idCampus = $row['idCampus'];
} else {
    echo "Error: No se encontró el campus en la base de datos.";
    exit();
}

// Imprimir los valores en la consola
echo "<script>";
echo "console.log('Editorial: " . $idAsignatura . "');";
echo "console.log('Autor: " . $autor . "');";
echo "console.log('Título: " . $titulo . "');";
echo "console.log('Asignatura: " . $idAsignatura . "');";
echo "console.log('Campus: " . $idCampus . "');";
echo "console.log('Cantidad: " . $cantidad . "');";
echo "</script>";

$sql = "INSERT INTO librosasignaturas (idCampus, IdAsignatura, titulo, autor, ideditorial, total, disponible, estado, fecha) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $Conn->prepare($sql);
$stmt->bind_param("iissiiiss", $idCampus, $idAsignatura, $titulo, $autor, $idEditorial, $cantidad, $cantidad, $estado, $fecha);

try {
    if ($stmt->execute()) {
        echo "<script>alert('Libro creado correctamente.');window.location.href='../pages/libroasignatura.php';</script>";

    }
} catch (mysqli_sql_exception $e) {
    if ($e->getCode() === 1062) {
        // Manejar error de duplicado si es necesario
    } else {
        echo "Error al guardar datos: " . $e->getMessage();
    }
}

$stmt->close();
$Conn->close();
?>
