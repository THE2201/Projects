<?php
// Conexión a la base de datos
$servername = '127.0.0.1';
$username = 'root';
$password = '';
$dbname = 'bd_biblioteca';

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener los datos del formulario
$idLibros = $_POST['idLibros'];
$cantidad = $_POST['cantidad'];

// Actualizar los registros en la base de datos
$sql = "UPDATE libros SET total = total + $cantidad, disponible = disponible + $cantidad WHERE idLibros = $idLibros";
if ($conn->query($sql) === TRUE) {
    echo "Registros actualizados correctamente";
 
    
} else {
    echo "Error al actualizar registros: " . $conn->error;
}

$conn->close();
?>
