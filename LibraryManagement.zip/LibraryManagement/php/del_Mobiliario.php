<?php
require('connectionBD.php');

if (isset($_POST['idArticulo'])) {
    $idArticulo = $_POST['idArticulo'];

    $sql = "UPDATE mobiliario SET estado = 'Inactivo' WHERE idArticulo = $idArticulo";

    if ($Conn->query($sql) === TRUE) {
        echo "Registro borrado exitosamente.";
    } else {
        echo "Error al borrar el registro: " . $Conn->error;
    }
} else {
    echo "ID de artículo no recibido.";
}
?>
