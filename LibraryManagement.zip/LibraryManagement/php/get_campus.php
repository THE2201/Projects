<?php
// Aquí establece tu conexión a la base de datos y realiza la consulta para obtener la lista de campus
$servername = '127.0.0.1';
$username = 'root';
$password = '';
$dbname = 'bd_biblioteca';


// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Consulta SQL para obtener la lista de campus
$sql = "SELECT idCampus, campus FROM campus where estado = 'Activo'";
$result = $conn->query($sql);

// Crear un array para almacenar las opciones de campus
$campus = array();

// Obtener los campus y agregarlos al array
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $campus[] = $row;
    }
}

// Devolver las opciones de campus como JSON
echo json_encode($campus);

// Cerrar conexión
$conn->close();
?>
