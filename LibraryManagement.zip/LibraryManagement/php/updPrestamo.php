<?php
require('../php/connectionBD.php');

$fin = $_POST['edit_fechaInicial'];
$ffi =  $_POST['edit_fechaFinal'];
$idPrestamo = $_POST['edit_idPrestamo']; // Asegúrate de recibir el ID del préstamo

echo "Valor de Fecha Inicial: " . $fin . "<br>";
echo "Valor de Fecha Final: " . $ffi . "<br>";
echo "Valor de Fecha Final: " . $idPrestamo . "<br>";

if (!$fin || !$ffi ) {
    echo "<script>alert('Fechas incompletas.');</script>";
} else {
    // Actualización en la tabla prestamo
    $sql_update = "UPDATE prestamo SET fechaIni = '$fin', fechaFin = '$ffi' WHERE idPrestamo = $idPrestamo";
    if (mysqli_query($Conn, $sql_update)) {
        echo "<script>alert('Éxito al actualizar las fechas del préstamo.');</script>";
        echo "<script>window.history.back();</script>"; 
        exit();
    } else {
        echo "Error al actualizar las fechas del préstamo: " . mysqli_error($Conn);
    }
}

$Conn->close();
?>
