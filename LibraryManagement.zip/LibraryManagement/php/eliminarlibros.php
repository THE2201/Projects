<?php
$SERVER = '127.0.0.1';
$USERNAME = 'root';
$PASSWORD = '';
$DB = 'bd_biblioteca';

$Conn = mysqli_connect($SERVER, $USERNAME, $PASSWORD, $DB) or die("Error de conexión: " . mysqli_connect_error());

$idLibros = $_POST['idLibros'];

$query = "UPDATE libros SET estado = 'Inactivo' WHERE idLibros = $idLibros";

if (mysqli_query($Conn, $query)) {
    echo "Libro Eliminado correctamente";
} else {
    echo "Error al eliminar libro: " . mysqli_error($Conn);
}

mysqli_close($Conn);
?>
