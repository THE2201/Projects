<?php
require('../php/connectionBD.php');

$campus = $_POST['campus'];
$articulo = $_POST['articulo'];
$descripcion = $_POST['descripcion'];
$cantidad = $_POST['cantidad'];

$estado = "Activo";
$fecha = date("Y-m-d H:i:s");

$sql = "INSERT INTO mobiliario (idCampus, articulo, descripcion, cantidad, estado, fecha) 
        VALUES ('$campus', '$articulo', '$descripcion', '$cantidad', '$estado', '$fecha')";

if ($Conn->query($sql) === TRUE) {
    header("Location: ../pages/mobiliario.php");
    exit();
} else {
    echo "Error al insertar el registro: " . $Conn->error;
}

$Conn->close();
?>
