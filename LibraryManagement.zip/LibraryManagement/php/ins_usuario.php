<?php
require('../php/connectionBD.php');

$usuarios = $_POST['usuarios'];
$rol_nombre = $_POST['rol'];
$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$campus_nombre = $_POST['campus'];

$estado = "Activo";
$fecha = date("Y-m-d H:i:s");
$contrasena_temporal = "temporal24"; // Contraseña temporal

// Obtener el ID del rol
$sql = "SELECT idRol FROM rol WHERE nombre = '$rol_nombre' AND estado = 'Activo'";
$result = $Conn->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $idRol = $row['idRol'];
} else {
    echo "Error: No se encontró el rol en la base de datos.";
    exit();
}

// Obtener el ID del campus
$sql = "SELECT idCampus FROM campus WHERE campus = '$campus_nombre' AND estado = 'Activo'";
$result = $Conn->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $idCampus = $row['idCampus'];
} else {
    echo "Error: No se encontró el campus en la base de datos.";
    exit();
}

$sql = "INSERT INTO usuarios (usuario, password, idRol, nombre, apellido, idCampus, estado, fecha) 
        VALUES ('$usuarios', '$contrasena_temporal', '$idRol', '$nombre', '$apellido', '$idCampus', '$estado', '$fecha')";


try {
    if ($Conn->query($sql) === TRUE) {
        echo "<script>alert('Usuario creado correctamente.');window.location.href='../pages/usuarios.php';</script>";

    }
} catch (mysqli_sql_exception $e) {
   
    if ($e->getCode() === 1062) {
        echo "<script>alert('Error, el usuario $usuarios ya está registrado.');window.location.href='../pages/usuarios.php';</script>";
  
    } else {
        echo "Error al guardar datos: " . $e->getMessage();
    }
}
$Conn->close();
?>
