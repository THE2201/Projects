<?php
require('../php/connectionBD.php');

if(isset($_POST['idEntrega'])) {
    $idEntrega = $_POST['idEntrega'];

    $sql = "SELECT e.idEntrega, e.alumno, e.fechaEntrega, ca.campus, e.estado, e.cuenta, lb.titulo , lb.idLibrosAsignatura
    FROM entregas e
    LEFT JOIN librosasignaturas lb ON e.idLibrosAsignatura = lb.idLibrosAsignatura
    LEFT JOIN campus ca ON e.idCampus = ca.idCampus       
        WHERE e.idEntrega = $idEntrega";

    $result = $Conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo json_encode($row);
    } else {
        echo json_encode(array('error' => 'No se encontró el préstamo'));
    }

    $Conn->close();
} else {
    echo json_encode(array('error' => 'No se proporcionó el ID del préstamo'));
}
?>
