<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require('connectionBD.php');

    $idGenero = $_POST['edit_idGenero'];
    $genero = $_POST['edit_genero'];


    if (empty($idGenero) || empty($genero)) {
        echo'Rellenar campos de editorial';
    } else {

        $sql = "UPDATE generos SET genero = '$genero' WHERE idGenero = '$idGenero'";
        if ($Conn->query($sql) === TRUE) {
            echo "Registro actualizado correctamente";
        } else {
            echo "Error al actualizar el registro: " . $Conn->error;
        }
        $Conn->close();
    }
} else {
    echo "Error: No se recibieron los datos del formulario correctamente";
}
