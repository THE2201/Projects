<?php
require('../php/connectionBD.php');

// Obtener los valores enviados por el formulario
$idAsignaturaedit = $_POST['edit_idlibroasig'];
$editorial = $_POST['edit_editorial'];
$autor = $_POST['edit_autor'];
$titulo = $_POST['edit_titulo'];
$asignatura = $_POST['edit_asignatura'];
$campus_nombre = $_POST['edit_campus'];


// Obtener los IDs correspondientes a los valores seleccionados
$sql_editorial = "SELECT idEditorial FROM editoriales WHERE nombre = ? AND estado = 'Activo'";
$stmt_editorial = $Conn->prepare($sql_editorial);
$stmt_editorial->bind_param("s", $editorial);
$stmt_editorial->execute();
$result_editorial = $stmt_editorial->get_result();

if ($result_editorial->num_rows > 0) {
    $row_editorial = $result_editorial->fetch_assoc();
    $idEditorial = $row_editorial['idEditorial'];
} else {
    echo "Error: No se encontró la editorial en la base de datos.";
    exit();
}

$sql_asignatura = "SELECT idAsignatura FROM asignaturas WHERE asignatura = ? AND estado = 'Activo'";
$stmt_asignatura = $Conn->prepare($sql_asignatura);
$stmt_asignatura->bind_param("s", $asignatura);
$stmt_asignatura->execute();
$result_asignatura = $stmt_asignatura->get_result();

if ($result_asignatura->num_rows > 0) {
    $row_asignatura = $result_asignatura->fetch_assoc();
    $idAsignatura = $row_asignatura['idAsignatura'];
} else {
    echo "Error: No se encontró la asignatura en la base de datos.";
    exit();
}

$sql_campus = "SELECT idCampus FROM campus WHERE campus = ? AND estado = 'Activo'";
$stmt_campus = $Conn->prepare($sql_campus);
$stmt_campus->bind_param("s", $campus_nombre);
$stmt_campus->execute();
$result_campus = $stmt_campus->get_result();

if ($result_campus->num_rows > 0) {
    $row_campus = $result_campus->fetch_assoc();
    $idCampus = $row_campus['idCampus'];
} else {
    echo "Error: No se encontró el campus en la base de datos.";
    exit();
}

// Preparar la consulta SQL para actualizar el registro
$sql_update = "UPDATE librosasignaturas SET idCampus = ?, IdAsignatura = ?, titulo = ?, autor = ?, ideditorial = ? WHERE idLibrosAsignatura = ?";

$stmt_update = $Conn->prepare($sql_update);
$stmt_update->bind_param("iissii", $idCampus, $idAsignatura, $titulo, $autor, $idEditorial, $idAsignaturaedit);

// Ejecutar la consulta de actualización
try {
    if ($stmt_update->execute()) {
        echo "Libro actualizado correctamente";
    }
} catch (mysqli_sql_exception $e) {
    if ($e->getCode() === 1062) {
        // Manejar error de duplicado si es necesario
    } else {
        echo "Error al guardar datos: " . $e->getMessage();
    }
}

// Cerrar la conexión y liberar los recursos
$stmt_update->close();
$stmt_editorial->close();
$stmt_asignatura->close();
$stmt_campus->close();
$Conn->close();
?>
