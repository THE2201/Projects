<?php
require('connectionBD.php');

if (isset($_POST['idSeccion'])) {
    $idSeccion = $_POST['idSeccion'];

    $sql = "UPDATE secciones SET estado = 'Inactivo' WHERE idSeccion = $idSeccion";

    if ($Conn->query($sql) === TRUE) {
        echo "Registro borrado exitosamente.";
    } else {
        echo "Error al borrar el registro: " . $Conn->error;
    }
} else {
    echo "idSeccion no recibido.";
}
?>
