<?php
if(isset($_POST['idUsuario'])) {
    require('connectionBD.php'); 
    
    $idUsuario = $_POST['idUsuario'];

    $sql = "SELECT * FROM usuarios WHERE idUsuario = $idUsuario";
    $result = $Conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        echo json_encode($row);
    } else {
        echo json_encode(array('error' => 'No se encontró la sección'));
    }

    $Conn->close();
} else {
    echo json_encode(array('error' => 'No se proporcionó el ID de la sección'));
}
?>
