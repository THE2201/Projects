<?php
require('../php/connectionBD.php');

$titulo = $_POST['titulo'];
$alumno = $_POST['alumno'];
$Canti = $_POST['cantidad'];
$cuenta = $_POST['cuenta'];
$campus = $_POST['campus'];

$fechaEntrega = $_POST['fechaEntrega'];

$estado = "Activo";
$fecha = date("Y-m-d H:i:s");

echo "<script>";
echo "console.log('Cantidad de libros:', " . json_encode($campus) . ");";
echo "console.log('Titulooooooooooooo de libros:', " . json_encode($titulo) . ");";
echo "</script>";

$sql = "SELECT idCampus FROM campus WHERE campus = '$campus' AND estado = 'Activo'";
$result = $Conn->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $idCampus = $row['idCampus'];
} else {
    echo "Error: No se encontró el campus en la base de datos.";
    exit();
}


if (!$titulo || !$alumno || !$Canti || !$fechaEntrega) {
    echo "<script>alert('Espacios vacios.');</script>";
    echo "<script>window.history.back();</script>";
    
    exit; 
} else {
    //Operacion para buscar ID del titulo de libros
    $sql = "SELECT idLibrosAsignatura, disponible from librosasignaturas WHERE idLibrosAsignatura='$titulo'";
    $RS = mysqli_query($Conn, $sql);
    if (mysqli_num_rows($RS) > 0) {
        while ($dat = mysqli_fetch_assoc($RS)) {
            $idLib = $dat["idLibrosAsignatura"];
            $disp1 = $dat["disponible"];
        }
    }

    //Validaciones
    if ($Canti > $disp1) {
        echo "<script>alert('Cantidad de libros no disponible.');</script>";

        echo "<script>window.history.back();</script>";
    } else if ($Canti < 1) {
        echo "<script>alert('Cantidad de libros invalida.');</script>";
    } else {
      
        $ins = "INSERT INTO entregas (idLibrosAsignatura, cuenta, alumno, idCampus, cantidad, fechaEntrega, estado, fecha) VALUES ('$idLib', '$cuenta', '$alumno', $idCampus,'$Canti' ,  '$fechaEntrega', 'Activo', '$fecha')";
        if (mysqli_query($Conn, $ins)) {
            echo "<script>alert('Exito al registrar Prestamo.');</script>";

            //Actualizar libros disponibles del seleccionado
            $restaDisp = $disp1 - $Canti;
            $sql3 = "UPDATE librosasignaturas SET disponible=$restaDisp WHERE idLibrosAsignatura=$idLib";
            mysqli_query($Conn, $sql3);

            header("Location: ../pages/entregas.php");
            exit();
        } else {
            echo "Error al guardar datos para entrega: " . mysqli_error($Conn);
        }
    }
}
$Conn->close();



?>
