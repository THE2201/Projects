<?php
require('connectionBD.php');

if (isset($_POST['idEditorial'])) {
    $idEditorial = $_POST['idEditorial'];

    $sql = "UPDATE editoriales SET estado = 'Inactivo' WHERE idEditorial = $idEditorial";

    if ($Conn->query($sql) === TRUE) {
        echo "Registro borrado exitosamente.";
    } else {
        echo "Error al borrar el registro: " . $Conn->error;
    }
} else {
    echo "ID de artículo no recibido.";
}
?>
