<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require('connectionBD.php');

    $idSolicitud = $_POST['edit_idSolicitud'];
    $usuario = $_POST['edit_usuario']; 
    $descripcion = $_POST['edit_descripcion'];

    $sql_idcampus = "SELECT idcampus FROM usuarios WHERE idUsuario = '$usuario'";
    $result_idcampus = $Conn->query($sql_idcampus);

    if ($result_idcampus->num_rows > 0) {
        $row_idcampus = $result_idcampus->fetch_assoc();
        $idcampus = $row_idcampus['idcampus'];

        // Actualizar el registro en la tabla solicitudes
        $sql = "UPDATE solicitudes SET idUsuario = '$usuario', idCampus = '$idcampus', descripcion = '$descripcion' WHERE idSolicitud = '$idSolicitud'";

        if ($Conn->query($sql) === TRUE) {
            echo "Registro actualizado correctamente";
        } else {
            echo "Error al actualizar el registro: " . $Conn->error;
        }
    } else {
        echo "No se encontró el idCampus del usuario seleccionado";
    }

    $Conn->close();
} else {
    echo "Error: No se recibieron los datos del formulario correctamente";
}
?>