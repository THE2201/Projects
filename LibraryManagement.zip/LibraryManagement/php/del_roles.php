<?php
require('connectionBD.php');

if (isset($_POST['idrol'])) {
    $idrol = $_POST['idrol'];

    $sql = "UPDATE rol SET estado = 'Inactivo' WHERE idrol = $idrol";

    if ($Conn->query($sql) === TRUE) {
        echo "Registro borrado exitosamente.";
    } else {
        echo "Error al borrar el registro: " . $Conn->error;
    }
} else {
    echo "ID de artículo no recibido.";
}
?>
