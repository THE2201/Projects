<?php
require('connectionBD.php');

if (isset($_POST['idAsignatura'])) {
    $idAsignatura = $_POST['idAsignatura'];

    $sql = "UPDATE asignaturas SET estado = 'Inactivo' WHERE idAsignatura = $idAsignatura";

    if ($Conn->query($sql) === TRUE) {
        echo "Registro borrado exitosamente.";
    } else {
        echo "Error al borrar el registro: " . $Conn->error;
    }
} else {
    echo "ID de artículo no recibido.";
}
?>

