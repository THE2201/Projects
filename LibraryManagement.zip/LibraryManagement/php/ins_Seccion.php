<?php
require('../php/connectionBD.php');

$campus = $_POST['campus'];
$seccion = $_POST['seccion'];
$descripcion = $_POST['descripcion'];

$estado = "Activo";
$fecha = date("Y-m-d H:i:s");

$sql = "INSERT INTO secciones (idCampus, seccion, descripcion, estado, fecha) 
        VALUES ('$campus', '$seccion', '$descripcion', '$estado', '$fecha')";

if ($Conn->query($sql) === TRUE) {
    header("Location: ../pages/seccion.php");
    exit();
} else {
    echo "Error al insertar el registro: " . $Conn->error;
}

$Conn->close();
?>
