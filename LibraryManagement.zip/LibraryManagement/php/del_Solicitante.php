<?php
require('connectionBD.php');

if (isset($_POST['idSolicitante'])) {
    $idSolicitante = $_POST['idSolicitante'];

    $sql = "UPDATE solicitantes SET estado = 'Inactivo' WHERE idSolicitante = $idSolicitante";

    if ($Conn->query($sql) === TRUE) {
        echo "Registro borrado exitosamente.";
    } else {
        echo "Error al borrar el registro: " . $Conn->error;
    }
} else {
    echo "ID de Solicitante no recibido.";
}
?>