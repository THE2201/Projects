<?php

require('connectionBD.php');
// Verificar si se reciben los datos del formulario
if(isset($_POST['idLibro'], $_POST['campus'], $_POST['seccion'], $_POST['genero'], $_POST['titulo'], $_POST['autor'], $_POST['editorial'], $_POST['idioma'])) {
    
    // Obtener los datos del formulario
    $idLibro = $_POST['idLibro'];
    $campus = $_POST['campus'];
    $seccion = $_POST['seccion'];
    $genero = $_POST['genero'];
    $titulo = $_POST['titulo'];
    $autor = $_POST['autor'];
    $editorial = $_POST['editorial'];
    $idioma = $_POST['idioma'];

    $estado = "Activo";
    $fecha = date("Y-m-d H:i:s"); // Obtener la fecha actual del servidor

    // Establecer conexión a la base de datos
 
   // Actualizar el registro del usuario
   if(empty($idLibro) || empty($campus) || empty($seccion) || empty($genero) || empty($titulo) || empty($autor) || empty($editorial) || empty($idioma)){
    echo"Espacios vacios, complete";
}else{
   $sql = "SELECT idGenero FROM generos WHERE genero = '$genero' AND estado = 'Activo'";
$result = $Conn->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $idGenero = $row['idGenero'];
} else {
    echo "Error: No se encontró el campus en la base de datos.";
    exit();
}



$sql = "UPDATE libros 
        SET 
            idCampus = '$campus', 
            idSeccion = '$seccion', 
            idGenero = '$idGenero', 
            titulo = '$titulo', 
            autor = '$autor',  
            ideditorial = '$editorial', 
            idioma = '$idioma', 
            estado = '$estado', 
            fecha = '$fecha' 
        WHERE idLibros = '$idLibro'";


if ($Conn->query($sql) === TRUE) {
echo "Registro actualizado correctamente";
} else {
echo "Error al actualizar el registro: " . $Conn->error;
}

$Conn->close();
} 

} else {
    // Si no se reciben los datos del formulario, devolver mensaje de error
    echo "Error: Se deben proporcionar todos los datos del libro.";
}
?>
