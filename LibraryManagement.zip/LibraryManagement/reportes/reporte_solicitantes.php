<?php
include('C:/xampp/htdocs/bibliotecaUTH/library/tcpdf.php');
ob_end_clean(); // Limpiar la memoria

require('../php/connectionBD.php');
session_start();
$usuario = $_SESSION['username'];
if (!isset($usuario)) {
    header('Location: inicio.php');
}

$sql = "SELECT campus.campus AS campus_nombre
        FROM usuarios
        INNER JOIN campus ON usuarios.idcampus = campus.idcampus
        WHERE usuarios.usuario = '$usuario'";
$result = $Conn->query($sql);
if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $campusName = $row['campus_nombre'];
} else {
    $campusName = 'No hay sesion iniciada';
}

class MYPDF extends TCPDF {
    // Variable para controlar si ya se ha impreso el encabezado
    protected $headerPrinted = false;
    protected $campusName = '';

    public function setCampusName($name) {
        $this->campusName = $name;
    }

    public function Header() {
        if (!$this->headerPrinted) {
            $this->SetFont('helvetica', 'B', 12);
            $logo_file = dirname(__FILE__) . '/../img/uthlogo.jpg';
            $logo_width = 120;
            $logo_height = 60;
            $logo_x = (300 - $logo_width) / 2;
            $logo_y = 5;
            $this->Image($logo_file, $logo_x, $logo_y, $logo_width, $logo_height, 'jpg', '', 'T', false, 300, '', false, false, 0, false, false, false);

            $title = '';
            $title_width = $this->GetStringWidth($title);
            $title_x = (210 - $title_width) / 2;
            $title_y = $logo_y + $logo_height + 5;
            $this->SetXY($title_x, $title_y);
            $this->Cell(0, 10, $title, 0, 1, 'C', 0, '', 0, false, 'M', 'M');

            $this->Ln(5);
            $this->SetLineWidth(0.1);
            $this->Line(10, $this->GetY(), 285, $this->GetY());

            $this->headerPrinted = true;
        }
    }

    public function Footer() {
        $this->SetY(-15);
        $this->SetFont('helvetica', 'I', 8);
        $this->Cell(0, 10, 'Página ' . $this->getAliasNumPage() . '/' . $this->getAliasNbPages(), 0, false, 'C', 0, '', 0, false, 'T', 'M');

        //Fecha y hora
        date_default_timezone_set('America/Tegucigalpa');
        $fecha_actual = date('d-m-Y');
        $hora_actual = date('h:i A');
        $this->Cell(0, 10, 'Fecha: ' . $fecha_actual . ' Hora: ' . $hora_actual, 0, 1, 'C', 0, '', 0, false, 'M', 'M');
    }
}

// Iniciando un nuevo pdf
$pdf = new MYPDF('L', PDF_UNIT, 'Letter', true, 'UTF-8', false);
$pdf->setCampusName($campusName);

// Establecer margenes del PDF
$pdf->SetMargins(20, 30, 25);
$pdf->SetHeaderMargin(20);
$pdf->setPrintFooter(true);
$pdf->setPrintHeader(true); // Eliminar la línea superior del PDF por defecto
$pdf->SetAutoPageBreak(true, PDF_MARGIN_BOTTOM); // Activa o desactiva el modo de salto de página automático
 
//Informacion del PDF
$pdf->SetCreator('grupo1');
$pdf->SetAuthor('grupo1');
$pdf->SetTitle('Reporte Solicitantes');
 
$pdf->AddPage();
$pdf->Ln(30);
$pdf->SetTextColor(0, 100, 0);

$biblioteca = 'Solicitantes';
$pdf->SetFont('helvetica', 'B', 18);
$pdf->Cell(0, 10, 'Reporte ' . $biblioteca, 0, 1, 'C');

$pdf->Ln(15);

$pdf->SetTextColor(0, 100, 0);
$pdf->SetFont('helvetica', 'B', 10);

$pdf->Ln(10);

//Nombre del campus
$pdf->Cell(0, 10, 'Campus: ' . $campusName, 0, 1, 'L');

// Agregar un borde alrededor de la tabla y resaltar las celdas de encabezado
$pdf->SetLineWidth(0.1);
$pdf->SetDrawColor(0, 0, 0);
$pdf->SetFillColor(232, 232, 232);

// Realiza tu consulta SQL
$query = "SELECT * FROM solicitantes";
$result = mysqli_query($Conn, $query);

// Agregar los datos al PDF
if (mysqli_num_rows($result) > 0) {
    // Encabezados de la tabla
    $pdf->SetFont('helvetica', 'B', 10);
    $pdf->Cell(15, 10, 'ID', 1, 0, 'C');
    $pdf->Cell(35, 10, 'NOMBRE', 1, 0, 'C');
    $pdf->Cell(35, 10, 'APELLIDO', 1, 0, 'C');
    $pdf->Cell(30, 10, 'DNI', 1, 0, 'C');
    $pdf->Cell(25, 10, 'CONTACTO', 1, 0, 'C');
    $pdf->Cell(65, 10, 'DIRECCION', 1, 0, 'C');
    $pdf->Cell(20, 10, 'ESTADO', 1, 0, 'C');
    $pdf->Cell(37, 10, 'FECHA', 1, 1, 'C');
    $pdf->SetFont('helvetica', '', 10);

    // Datos de la tabla
    while ($row = mysqli_fetch_assoc($result)) {
        $pdf->Cell(15, 10, $row['idSolicitante'], 1, 0, 'C');
        $pdf->Cell(35, 10, $row['nombre'], 1, 0, 'C');
        $pdf->Cell(35, 10, $row['apellido'], 1, 0, 'C');
        $pdf->Cell(30, 10, $row['dni'], 1, 0, 'C');
        $pdf->Cell(25, 10, $row['contacto'], 1, 0, 'C');
        $pdf->Cell(65, 10, $row['direccion'], 1, 0, 'C');
        $pdf->Cell(20, 10, $row['estado'], 1, 0, 'C');
        $pdf->Cell(37, 10, $row['fecha'], 1, 1, 'C');
    }
} else {
    $pdf->Cell(0, 10, 'No hay datos disponibles', 1, 1, 'C');
}

// Finalizar y generar el PDF
$pdf->Output('reporte.pdf', 'I');
?>