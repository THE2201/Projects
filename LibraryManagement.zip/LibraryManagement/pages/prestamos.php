<?php
require('../php/connectionBD.php');
session_start();
$usuario = $_SESSION['username'];


if (!isset($usuario)) {
    header('Location: inicio.php');
  }
$sqlPermisos = "SELECT p.editar, p.eliminar, P.agregar
                FROM usuarios u
                INNER JOIN rol r ON u.idRol = r.idRol
                INNER JOIN permisos p ON r.idPermiso = p.idPermiso
                WHERE u.usuario = '$usuario'";
$resultPermisos = $Conn->query($sqlPermisos);

if ($resultPermisos->num_rows > 0) {
    // Obtener los permisos del usuario
    $permisos = $resultPermisos->fetch_assoc();
} else {
    // Si no se encontraron permisos, se pueden establecer valores predeterminados o manejar el error según sea necesario
    // Por ejemplo, puedes asignar valores predeterminados para los permisos o mostrar un mensaje de error
    $permisos = array('editar' => 0, 'eliminar' => 0); // Valores predeterminados
    echo "No se encontraron permisos para el usuario.";
}

$sql = "SELECT pr.idPrestamo, l.titulo AS nombreLibro, CONCAT(s.nombre, ' ', s.apellido) AS nombreCompleto, pr.cantidad, pr.fechaIni,pr.fechaFin,pr.estado,pr.fecha FROM prestamo pr LEFT JOIN libros l ON pr.idLibro = l.idLibros LEFT JOIN solicitantes s ON pr.idCliente = s.idSolicitante WHERE pr.estado = 'Activo'";
$result = $Conn->query($sql);



?>

<!DOCTYPE html>
<html lang="es" dir="ltr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="#" />
    <title>Prestamos | Biblioteca</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <!--datables CSS básico-->
    <link rel="stylesheet" href="https://cdn.datatables.net/2.0.2/css/dataTables.dataTables.min.css">
    <!--datables estilo bootstrap 5 CSS-->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/2.0.2/css/dataTables.bootstrap5.css">
</head>

<body>
    <header>
        <h4 class="text-center p-3 mb-2 bg-success text-white">Prestamos</h4>
    </header>

    <div class="container">
        <div class="row"></div>
        <div class="col-lg-12">
        <?php
                    if ($permisos['agregar'] == 1) {
                        echo '<button id="btnNuevo" type="button" class="btn btn-success" data-toggle="modal" data-target="#modalCRUD">Nuevo</button><br><br>';
                        $reporte_url = "../reportes/reporte_prestamos.php?usuario=" . $usuario; // Adjuntar el nombre de usuario como parámetro en la URL
                        echo '<a href="' . $reporte_url . '" target="_blank" class="btn btn-success">Ver Reporte</a>';
                    } else {
                        echo "<td></td>"; // Espacio vacío si no tiene permisos
                    }
            ?>
        </div>
    </div>
    </div>
    <br>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table id="tablaMob" class="table table-striped table-bordered table-condensed" style="width:100%">
                        <thead class="text-center">
                            <tr>
                                <th>ID</th>
                                <th>Libro</th>       
                                <th>Solicitantes</th>       
                                <th>Cantidad</th>   
                                <th>Fecha Inicial</th>  
                                <th>Fecha Final</th>                       
                                <th>Acciones</th>
                                
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {

                                  

                                    echo "<tr>";
                                    echo "<td>".$row["idPrestamo"]."</td>";
                                    echo "<td>".$row["nombreLibro"]."</td>";  
                                    echo "<td>".$row["nombreCompleto"]."</td>";  
                                    echo "<td>".$row["cantidad"]."</td>";  
                                    echo "<td>".$row["fechaIni"]."</td>";   
                                    echo "<td>".$row["fechaFin"]."</td>";   
                                    echo "<td>";
                                    
                                    if ($permisos['editar'] == 1 && $permisos['eliminar'] == 1) {
                                        echo "<button class='btn btn-primary btnEditar' data-id='".$row["idPrestamo"]."'>Editar</button>";
                                        echo "<button class='btn btn-danger btnBorrar' data-id='".$row["idPrestamo"]."'>Regresar</button>";
                                    } elseif ($permisos['editar'] == 1 ) {
                                        echo "<button class='btn btn-primary btnEditar' data-id='".$row["idPrestamo"]."'>Editar</button>";
                                    } elseif ($permisos['eliminar'] == 1) {
                                        echo "<button class='btn btn-danger btnBorrar' data-id='".$row["idPrestamo"]."'>Regresar</button>";
                                    } else {
                                        echo "</td>"; // Espacio vacío si no tiene permisos
                                    }
                                    
                                    echo "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='7'>No se encontraron registros</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!--Modal para CRUD-->
    <div class="modal fade" id="modalCRUD" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Nuevo Registro</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        <!-- <span aria-hidden="true">&times;</span> -->
                    </button>
                </div>
                <form id="formNuevoRegistro" method="POST" action="../php/insertPrestamo.php" class="needs-validation" novalidate>
                    <div class="modal-body">
                    <input type="hidden" id="edit_idrol" name="edit_idrol">
                             <div class="form-group">
                                <label for="rol" class="col-form-label">Libro:</label>
                                <select class="form-control" id="libro"  name="libro" required>
                                <option value="">Seleccione un libro</option>
                                <?php
                                    $sql=mysqli_query($Conn,"SELECT titulo FROM libros WHERE estado ='Activo'");
                                    while($row=mysqli_fetch_array($sql)){
                                        echo '<option value="' . $row["titulo"] . '">' . $row["titulo"] . '</option>';
                                    }
                                    ?>
                                </select>
                            
                             </div>
                             <div class="form-group">
                                <label for="rol" class="col-form-label">Solicitante:</label>
                                    <select class="form-control" id="solicitante" name="solicitante" required>
                                        <option value="">Seleccione un solicitante</option>
                                        <?php
                                        $sql = mysqli_query($Conn, "SELECT nombre, apellido FROM solicitantes WHERE estado ='Activo'");
                                        while ($row = mysqli_fetch_array($sql)) {
                                            // Concatenar nombre y apellido
                                            $nombreCompleto = $row["nombre"] . ' ' . $row["apellido"];
                                            echo '<option value="' . $nombreCompleto . '">' . $nombreCompleto . '</option>';
                                        }
                                        ?>
                                    </select>
                            
                             </div>
                             <div class="form-group">
                                    <label for="cantidad" class="col-form-label">Cantidad:</label>
                                    <input type="number" class="form-control" id="cantidad" name="cantidad" min="1" required>
                                    <div class="invalid-feedback">
                                        Ingresa un número válido mayor que 0.
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="fechaInicial" class="col-form-label">Fecha inicial:</label>
                                    <input type="date" class="form-control" id="fechaInicial" name="fechaInicial" required >
                                </div>
                                <div class="form-group">
                                    <label for="fechaFinal" class="col-form-label">Fecha final:</label>
                                    <input type="date" class="form-control" id="fechaFinal" name="fechaFinal" required>
                                    <div class="invalid-feedback" id="fechaError">
                                        La fecha final no puede ser menor que la fecha inicial.
                                    </div>
                                </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>                        
                        <button type="submit" class="btn btn-dark" ">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal para editar registros -->
    <div class="modal fade" id="modalEditar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Editar Registro</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        <!-- <span aria-hidden="true">&times;</span> -->
                    </button>
                </div>
                <form id="formEditarRegistro" method="POST" action="../php/updPrestamo.php" class="needs-validation" novalidate>
                    <div class="modal-body">
                    <input type="hidden" id="edit_idPrestamo" name="edit_idPrestamo">
                    <div class="form-group">
                                <label for="rol" class="col-form-label">Libro:</label>
                                <input type="text" class="form-control" id="edit_libro_text" name="edit_libro_text"  readonly required>
                            
                             </div>
                           
                             <div class="form-group">
                                <label for="rol" class="col-form-label">Solicitante:</label>
                                <input type="text" class="form-control" id="edit_solicitante" name="edit_solicitante" readonly  required>
                            
                             </div>
                             <div class="form-group">
                                    <label for="cantidad" class="col-form-label">Cantidad:</label>
                                    <input type="number" class="form-control" id="edit_cantidad" name="edit_cantidad" min="1" readonly required>
                                    <div class="invalid-feedback">
                                        Ingresa un número válido mayor que 0.
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="fechaInicial" class="col-form-label">Fecha inicial:</label>
                                    <input type="date" class="form-control" id="edit_fechaInicial" name="edit_fechaInicial" required >
                                </div>
                                <div class="form-group">
                                    <label for="fechaFinal" class="col-form-label">Fecha final:</label>
                                    <input type="date" class="form-control" id="edit_fechaFinal" name="edit_fechaFinal" required>
                                    <div class="invalid-feedback" id="fechaError">
                                        La fecha final no puede ser menor que la fecha inicial.
                                    </div>
                                </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>                        
                        <button type="submit" class="btn btn-dark" >Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- jQuery, Popper.js, Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>

    <!-- datatables JS -->
    <script src="https://cdn.datatables.net/2.0.2/js/dataTables.js"></script>
    <script type="text/javascript" src="../js/scriptLibros.js"></script>

    <!-- JavaScript para abrir el modal al hacer clic en Nuevo -->
    <script>
        $(document).ready(function() {


            //Validacion

            document.getElementById('fechaFinal').addEventListener('change', function() {
                var fechaInicial = document.getElementById('fechaInicial').value;
                var fechaFinal = document.getElementById('fechaFinal').value;
                
                if (fechaInicial > fechaFinal) {
                    document.getElementById('fechaFinal').classList.add('is-invalid');
                    document.getElementById('fechaError').style.display = 'block';
                } else {
                    document.getElementById('fechaFinal').classList.remove('is-invalid');
                    document.getElementById('fechaError').style.display = 'none';
                }
            });

            document.getElementById('edit_fechaFinal').addEventListener('change', function() {
                var fechaInicial = document.getElementById('edit_fechaInicial').value;
                var fechaFinal = document.getElementById('edit_fechaFinal').value;
                
                if (fechaInicial > fechaFinal) {
                    document.getElementById('edit_fechaFinal').classList.add('is-invalid');
                    document.getElementById('fechaError').style.display = 'block';
                } else {
                    document.getElementById('edit_fechaFinal').classList.remove('is-invalid');
                    document.getElementById('fechaError').style.display = 'none';
                }
            });

        $('#btnNuevo').click(function() {
            $('#modalCRUD').modal('show');
        });

        var tablaMob = $("#tablaMob").DataTable({
            "columnDefs": [{
                "data": null,
                
            }],
            
            "language": {
                "lengthMenu": "Mostrar _MENU_ registros",
                "zeroRecords": "No se encontraron resultados",
                "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
                "infoFiltered": "(filtrado de un total de _MAX_ registros)",
                "sSearch": "Buscar:",
                "oPaginate": {
                    "sFirst": "Primero",
                    "sLast": "Último",
                    "sNext": "Siguiente",
                    "sPrevious": "Anterior"
                },
                "sProcessing": "Procesando...",
            }
        });

        $('#tablaMob tbody').on('click', 'button.btnBorrar', function () {
            var idPrestamo = $(this).attr('data-id');
            if (confirm("¿Estás seguro de que deseas borrar este registro?")) {
                $.ajax({
                    url: '../php/delPrestamo.php',
                    method: 'POST',
                    data: { idPrestamo: idPrestamo },
                    success: function (response) {
                        alert(response);
                        
                        location.reload();
                    },
                    error: function (xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            }
        });

        $("#btnNuevo").click(function () {
            $("#formPersonas").trigger("reset");
            $(".modal-header").css("background-color", "#004e18");
            $(".modal-header").css("color", "white");
            $(".modal-title").text("Registro");
            $("#modalCRUD").modal("show");
            id = null;
            opcion = 1;
        });

        $('#tablaMob tbody').on('click', 'button.btnEditar', function () {
    var idPrestamo = $(this).attr('data-id');

    $.ajax({
    url: '../php/obt_prestamo.php',
    method: 'POST',
    data: { idPrestamo: idPrestamo },
    dataType: 'json',
    success: function (response) {
        console.log(response);
        $('#edit_idPrestamo').val(response.idPrestamo); 
        $('#edit_libro_text').val(response.nombreLibro); // Mostrar el nombre del libro
        $('#edit_solicitante').val(response.nombreSolicitante); // Mostrar el nombre del solicitante
        $('#edit_cantidad').val(response.cantidad);

        // Asignar las fechas al formato adecuado (YYYY-MM-DD)
        var fechaIni = new Date(response.fechaIni);
        var fechaFin = new Date(response.fechaFin);

        // Formatear las fechas en el formato de fecha necesario
        var fechaIniFormateada = fechaIni.toISOString().split('T')[0];
        var fechaFinFormateada = fechaFin.toISOString().split('T')[0];

        // Asignar las fechas formateadas a los campos del formulario modal
        $('#edit_fechaInicial').val(fechaIniFormateada);
        $('#edit_fechaFinal').val(fechaFinFormateada);

        // Mostrar el modal
        $('#modalEditar').modal('show');
    },
    error: function (xhr, status, error) {
        console.error(xhr.responseText);
    }
});
});

        $('#formEditarRegistro').submit(function(e) {
            e.preventDefault(); 
            
            $.ajax({
                url: $(this).attr('action'),
                method: $(this).attr('method'),
                data: $(this).serialize(),
                success: function(response) {
                    alert(response); 
                    $('#modalEditar').modal('hide');
                    location.reload();
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText); 
                }
            });
        });
        
    });

    (function() {
        'use strict';
        window.addEventListener('load', function() {
            var forms = document.getElementsByClassName('needs-validation');
            var validation = Array.prototype.filter.call(forms, function(form) {
                form.addEventListener('submit', function(event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                    
                }, false);
                
            });
        }, false);
    })();
    </script>
</body>
</html>
