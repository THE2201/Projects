<?php
require('../php/connectionBD.php');
session_start();

$usuario = $_SESSION['username'];
if (!isset($usuario)) {
    header('Location: inicio.php');
  }

include_once ('../php/connectionBD.php');
$objeto = new Conexiong();
$conexion = $objeto->Conectarg();

// Recepción de los datos enviados mediante POST desde el JS   

         
$permiso = (isset($_POST['idPermiso'])) ? $_POST['idPermiso'] : '';
$nombre = (isset($_POST['nombre'])) ? $_POST['nombre'] : '';
$libros = (isset($_POST['libro'])) ? $_POST['libro'] : '';
$mobiliario = (isset($_POST['mobiliario'])) ? $_POST['mobiliario'] : '';
$prestamos = (isset($_POST['prestamo'])) ? $_POST['prestamo'] : '';
$solicitantes = (isset($_POST['solicitantes'])) ? $_POST['solicitantes'] : '';
$reportes = (isset($_POST['reportes'])) ? $_POST['reportes'] : '';
$configuracion = (isset($_POST['configuracion'])) ? $_POST['configuracion'] : '';
$opcion = (isset($_POST['opcion'])) ? $_POST['opcion'] : '';
$id = (isset($_POST['idrol'])) ? $_POST['idrol'] : '';

switch($opcion){            //DE AQUI PARA ABAJO SEGUIR MODIFICANDO!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    case 1: //alta
        $consulta = "INSERT INTO rol (idPermiso, nombre, libro, mobiliario, prestamo, solicitantes, reportes, configuracion) VALUES('$permiso', '$nombre', '$libros', '$mobiliario', '$prestamos', '$solicitantes', '$reportes', '$configuracion') ";			
        $resultado = $conexion->prepare($consulta);
        $resultado->execute(); 

        $consulta = "SELECT idrol, idPermiso, nombre, libro, mobiliario, prestamo, solicitantes, reportes, configuracion FROM rol ORDER BY idrol DESC LIMIT 1";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break;
    case 2: //modificación
        $consulta = "UPDATE rol SET idPermiso='$permiso', nombre='$nombre', libro='$libros', mobiliario='$mobiliario', prestamo='$prestamos', solicitantes='$solicitantes', reportes='$reportes', configuracion='$configuracion' WHERE idrol='$id' ";		
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();        
        
        $consulta = "SELECT idrol, idPermiso, nombre, libro, mobiliario, prestamo, solicitantes, reportes, configuracion FROM rol WHERE idrol='$id' ";       
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break;        
    case 3://baja
        $consulta = "DELETE FROM rol WHERE idRol='$id' ";		
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();     
        $consulta = "SELECT idRol, idPermiso, nombre, libro, mobiliario, prestamo, solicitantes, reportes, configuracion FROM rol ORDER BY idrol DESC LIMIT 1";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);                      
        break;        
}

print json_encode($data, JSON_UNESCAPED_UNICODE); //enviar el array final en formato json a JS
$conexion = NULL;