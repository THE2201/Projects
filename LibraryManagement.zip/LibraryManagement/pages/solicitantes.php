<?php
require('../php/connectionBD.php');
session_start();
$usuario = $_SESSION['username'];
if (!isset($usuario)) {
    header('Location: inicio.php');
}

$sql = "SELECT solicitantes.*, solicitantes.idSolicitante, campus.campus AS nombre_campus, tipo.tipo AS tipo_descrip 
        FROM solicitantes 
        INNER JOIN campus ON solicitantes.idCampus = campus.idCampus
        INNER JOIN tipo ON solicitantes.tipo = tipo.id
        WHERE solicitantes.estado = 'Activo'";

$result = $Conn->query($sql);

function obtenerOp($campo, $campo2, $tabla)
{
    $options = '';
    global $Conn;

    if (!$Conn) {
        die("Error de conexión: " . $Conn);
    }

    $sql = "SELECT $campo, $campo2 FROM $tabla WHERE estado = 'Activo'";

    $result = $Conn->query($sql);

    if ($result === false) {
        die("Error al recuperar los datos de $tabla");
    }

    foreach ($result as $row) {
        $options .= '<option value="' . $row[$campo] . '">' . $row[$campo] . ' - ' . $row[$campo2] . '</option>';
    }

    return $options;
}

$campusOp = obtenerOp('IdCampus', 'campus', 'campus');
$tipoOp = obtenerOp('id', 'tipo', 'tipo');



$sqlPermisos = "SELECT p.editar, p.eliminar, P.agregar
                FROM usuarios u
                INNER JOIN rol r ON u.idRol = r.idRol
                INNER JOIN permisos p ON r.idPermiso = p.idPermiso
                WHERE u.usuario = '$usuario'";
$resultPermisos = $Conn->query($sqlPermisos);

if ($resultPermisos->num_rows > 0) {
    // Obtener los permisos del usuario
    $permisos = $resultPermisos->fetch_assoc();
} else {
    // Si no se encontraron permisos, se pueden establecer valores predeterminados o manejar el error según sea necesario
    // Por ejemplo, puedes asignar valores predeterminados para los permisos o mostrar un mensaje de error
    $permisos = array('editar' => 0, 'eliminar' => 0); // Valores predeterminados
    echo "No se encontraron permisos para el usuario.";
}

?>

<!DOCTYPE html>
<html lang="es" dir="ltr">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="#" />
    <title>Solicitantes | Libreria</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <!--datables CSS básico-->
    <link rel="stylesheet" href="https://cdn.datatables.net/2.0.2/css/dataTables.dataTables.min.css">
    <!--datables estilo bootstrap 5 CSS-->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/2.0.2/css/dataTables.bootstrap5.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/css/bootstrap-select.min.css">
    <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet">
</head>

<body>
    <header>
        <h4 class="text-center p-3 mb-2 bg-success text-white">Solicitantes</h4>
    </header>
    <div class="container">
        <div class="row"></div>
        <div class="col-lg-12">
            <?php
            if ($permisos['agregar'] == 1) {
                echo '<button id="btnNuevo" type="button" class="btn btn-success" data-toggle="modal" data-target="#modalCRUD">Nuevo</button><br><br>';
                $reporte_url = "reportes/reporte_solicitantes.pdf";
                echo '<a href="../reportes/reporte_solicitantes.php" target="_blank" class="btn btn-success">Ver Reporte</a>';
            } else {
                echo "<td></td>"; // Espacio vacío si no tiene permisos
            }
            ?>
        </div>
    </div>
    </div>
    <br>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table id="tablaSolicitantes" class="table table-striped table-bordered table-condensed" style="width:100%">
                        <thead class="text-center">
                            <tr>
                                <th>ID</th>
                                <th>Campus</th>
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th>DNI</th>
                                <th>Tipo</th>
                                <th>Contacto</th>
                                <th>Dirección</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo "<tr>";
                                    echo "<td>" . $row["idSolicitante"] . "</td>";
                                    echo "<td>" . $row["nombre_campus"] . "</td>";
                                    echo "<td>" . $row["nombre"] . "</td>";
                                    echo "<td>" . $row["apellido"] . "</td>";
                                    echo "<td>" . $row["dni"] . "</td>";
                                    echo "<td>" . $row["tipo_descrip"] . "</td>";
                                    echo "<td>" . $row["contacto"] . "</td>";
                                    echo "<td>" . $row["direccion"] . "</td>";
                                    echo "<td>";

                                    if ($permisos['editar'] == 1 && $permisos['eliminar'] == 1) {
                                        echo "<button class='btn btn-primary btnEditar' data-id='" . $row["idSolicitante"] . "'>Editar</button>";
                                        echo "<button class='btn btn-danger btnBorrar' data-id='" . $row["idSolicitante"] . "'>Borrar</button>";
                                    } elseif ($permisos['editar'] == 1) {
                                        echo "<button class='btn btn-primary btnEditar' data-id='" . $row["idSolicitante"] . "'>Editar</button>";
                                    } elseif ($permisos['eliminar'] == 1) {
                                        echo "<button class='btn btn-danger btnBorrar' data-id='" . $row["idSolicitante"] . "'>Borrar</button>";
                                    } else {
                                        echo "</td>"; // Espacio vacío si no tiene permisos
                                    }

                                    echo "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='7'>No se encontraron registros</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!--Modal para CRUD-->
    <div class="modal fade" id="modalCRUD" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Nuevo Registro</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="formNuevoRegistro" method="POST" action="../php/ins_Solicitante.php" onsubmit="return validaCampos('1');">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="campus" class="col-form-label">Campus:</label>
                            <br>
                            <select class="selectpicker form-control" data-style="btn-success" id="campus" name="campus">
                                <option value="default">Seleccione una opción</option>
                                <?php echo $campusOp; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="nombre" class="col-form-label">Nombre:</label>
                            <input type="text" class="form-control" id="nombre" name="nombre" onkeypress="return validacion_letras(event);">
                        </div>
                        <div class="form-group">
                            <label for="apellido" class="col-form-label">Apellido:</label>
                            <input type="text" class="form-control" id="apellido" name="apellido" onkeypress="return validacion_letras(event);">
                        </div>
                        <div class="form-group">
                            <label for="dni" class="col-form-label">DNI:</label>
                            <input type="text" class="form-control" id="dni" name="dni" maxlength="13" onkeypress="return validacion_numeros(event);">
                        </div>
                        <div class="form-group">
                            <label for="tipo" class="col-form-label">Tipo:</label>
                            <br>
                            <select class="selectpicker form-control" data-style="btn-success" id="tipo" name="tipo">
                                <option value="default" selected>Seleccione una opción</option>
                                <?php echo $tipoOp; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="contacto" class="col-form-label">Contacto:</label>
                            <input type="text" class="form-control" id="contacto" name="contacto" maxlength="8" onkeypress="return validacion_numeros(event);">
                        </div>
                        <div class="form-group">
                            <label for="direccion" class="col-form-label">Dirección:</label>
                            <input type="text" class="form-control" id="direccion" name="direccion">
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal" onclick="limpiar()">Cancelar</button>
                        <button type="submit" class="btn btn-dark">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!--Modal para CRUD-->
    <div class="modal fade" id="modalEditar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Editar Registro</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="formEditarRegistro" method="POST" action="../php/upd_Solicitante.php">
                    <div class="modal-body">
                        <input type="hidden" id="edit_idSolicitante" name="edit_idSolicitante">
                        <div class="form-group">
                            <label for="campus" class="col-form-label">Campus:</label>
                            <br>
                            <select class="selectpicker form-control" data-style="btn-success" id="edit_campus" name="edit_campus">
                                <option value="default" selected>Seleccione una opción</option>
                                <?php echo $campusOp; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="nombre" class="col-form-label">Nombre:</label>
                            <input type="text" class="form-control" id="edit_nombre" name="edit_nombre" onkeypress="return validacion_letras(event);">
                        </div>
                        <div class="form-group">
                            <label for="apellido" class="col-form-label">Apellido:</label>
                            <input type="text" class="form-control" id="edit_apellido" name="edit_apellido" onkeypress="return validacion_letras(event);">
                        </div>
                        <div class="form-group">
                            <label for="dni" class="col-form-label">DNI:</label>
                            <input type="text" class="form-control" id="edit_dni" name="edit_dni" onkeypress="return validacion_numeros(event);">
                        </div>
                        <div class="form-group">
                            <label for="tipo" class="col-form-label">Tipo:</label>
                            <br>
                            <select class="selectpicker form-control" data-style="btn-success" id="edit_tipo" name="edit_tipo">
                                <option value="default" selected>Seleccione una opción</option>
                                <?php echo $tipoOp; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="contacto" class="col-form-label">Contacto:</label>
                            <input type="text" class="form-control" id="edit_contacto" name="edit_contacto" onkeypress="return validacion_numeros(event);">
                        </div>
                        <div class="form-group">
                            <label for="direccion" class="col-form-label">Dirección:</label>
                            <input type="text" class="form-control" id="edit_direccion" name="edit_direccion">
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-dark">Editar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- jQuery, Popper.js, Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/js/bootstrap-select.min.js"></script>

    <!-- datatables JS -->
    <script src="https://cdn.datatables.net/2.0.2/js/dataTables.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>


    <!-- JavaScript para abrir el modal al hacer clic en Nuevo -->
    <script>
        $(document).ready(function() {
            $('#btnNuevo').click(function() {
                $('#modalCRUD').modal('show');
            });

            var tablaSolicitantes = $("#tablaSolicitantes").DataTable({
                "columnDefs": [{
                    "data": null,

                }],

                "language": {
                    "lengthMenu": "Mostrar _MENU_ registros",
                    "zeroRecords": "No se encontraron resultados",
                    "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                    "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
                    "infoFiltered": "(filtrado de un total de _MAX_ registros)",
                    "sSearch": "Buscar:",
                    "oPaginate": {
                        "sFirst": "Primero",
                        "sLast": "Último",
                        "sNext": "Siguiente",
                        "sPrevious": "Anterior"
                    },
                    "sProcessing": "Procesando...",
                }
            });

            $('#tablaSolicitantes tbody').on('click', 'button.btnBorrar', function() {
                var idSolicitante = $(this).attr('data-id');
                if (confirm("¿Estás seguro de que deseas borrar este registro?")) {
                    $.ajax({
                        url: '../php/del_Solicitante.php',
                        method: 'POST',
                        data: {
                            idSolicitante: idSolicitante
                        },
                        success: function(response) {
                            alert(response);
                            location.reload();
                        },
                        error: function(xhr, status, error) {
                            console.error(xhr.responseText);
                        }
                    });
                }
            });

            $("#btnNuevo").click(function() {
                $("#formPersonas").trigger("reset");
                $(".modal-header").css("background-color", "#004e18");
                $(".modal-header").css("color", "white");
                $(".modal-title").text("Registro");
                $("#modalCRUD").modal("show");
                id = null;
                opcion = 1;
            });

            $('#tablaSolicitantes tbody').on('click', 'button.btnEditar', function() {
                var idSolicitante = $(this).attr('data-id');

                $.ajax({
                    url: '../php/obt_Solicitante.php',
                    method: 'POST',
                    data: {
                        idSolicitante: idSolicitante
                    },
                    dataType: 'json',
                    success: function(response) {
                        $('#edit_idSolicitante').val(response.idSolicitante);
                        $('#edit_campus').val(response.campus);
                        $('#edit_nombre').val(response.nombre);
                        $('#edit_apellido').val(response.apellido);
                        $('#edit_dni').val(response.dni);
                        $('#edit_tipo').val(response.tipo);
                        $('#edit_contacto').val(response.contacto);
                        $('#edit_direccion').val(response.direccion);

                        $('#modalEditar').modal('show');
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });

            $('#formEditarRegistro').submit(function(e) {
                e.preventDefault();

                if (!validaCampos(2)) {
                    return;
                }

                $.ajax({
                    url: $(this).attr('action'),
                    method: $(this).attr('method'),
                    data: $(this).serialize(),
                    success: function(response) {
                        alert(response);
                        $('#modalEditar').modal('hide');
                        location.reload();

                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });

        });
    </script>
    <script>
        var id, campus, nombre, apellido, dni, tipo, contacto, direccion;

        function validaCampos(indice) {
            if (indice == 1) {
                campus = $("#campus").val();
                nombre = $("#nombre").val();
                apellido = $("#apellido").val();
                dni = $("#dni").val();
                tipo = $("#tipo").val();
                contacto = $("#contacto").val();
                direccion = $("#direccion").val();
            }

            if (indice == 2) {
                campus = $("#edit_campus").val();
                nombre = $("#edit_nombre").val();
                apellido = $("#edit_apellido").val();
                dni = $("#edit_dni").val();
                tipo = $("#edit_tipo").val();
                contacto = $("#edit_contacto").val();
                direccion = $("#edit_direccion").val();
            }

            if ($.trim(campus) == "") {
                toastr.error("No ha seleccionado un campus", "Aviso");
                return false;
            }
            if ($.trim(nombre) == "") {
                toastr.error("No ha ingresado un nombre", "Aviso");
                return false;
            }
            if ($.trim(apellido) == "") {
                toastr.error("No ha ingresado un apellido", "Aviso");
                return false;
            }
            if ($.trim(dni) == "") {
                toastr.error("No ha ingresado un DNI", "Aviso");
                return false;
            }
            if ($.trim(tipo) == "") {
                toastr.error("No ha seleccionado un tipo", "Aviso");
                return false;
            }
            if ($.trim(contacto) == "") {
                toastr.error("No ha ingresado un contacto", "Aviso");
                return false;
            }
            if ($.trim(direccion) == "") {
                toastr.error("No ha ingresado una direccion", "Aviso");
                return false;
            }
            return true;
        }
    </script>

    <script>
        function limpiar() {

            var campus = document.getElementById('campus');
            var nombre = document.getElementById('nombre');
            var apellido = document.getElementById('apellido');
            var dni = document.getElementById('dni');
            var tipo = document.getElementById('tipo');
            var contacto = document.getElementById('contacto');
            var direccion = document.getElementById('direccion');

            campus.value = 'Seleccione una opción';
            nombre.value = '';
            apellido.value = '';
            dni.value = '';
            tipo.value = 'Seleccione una opción';
            contacto.value = '';
            direccion.value = '';
            location.reload();
        }

        function validacion_numeros(e) {
            let key = e.keyCode || e.which;
            let teclas = String.fromCharCode(key).toLocaleLowerCase();
            let numero = "0123456789";

            if (numero.indexOf(teclas) == -1)
                return false;
        }

        function validacion_letras(e) {
            let key = e.keyCode || e.which;
            let teclas = String.fromCharCode(key).toLocaleLowerCase();
            let letra = "  áéíóúabcdefghijklmnñopqrstuvwxyz";

            if (letra.indexOf(teclas) == -1)
                return false;
        }
    </script>
</body>

</html>