<?php
require_once('../php/connectionBD.php');
session_start();
if (!isset($_SESSION['username'])) {
  header('Location: inicio.php');
}
$username = $_SESSION['username'];

// Obtener el ID del usuario utilizando el nombre de usuario
$sentencia = $Conn->prepare("SELECT idUsuario,idcampus FROM usuarios WHERE usuario = ?");
$sentencia->bind_param("s", $username);
$sentencia->execute();
$resultado = $sentencia->get_result();

if ($resultado->num_rows > 0) {
  $fila = $resultado->fetch_assoc();
  $idUsuario = $fila['idUsuario'];
  $idcampus = $fila['idcampus'];

  // Ahora que tenemos el ID del usuario, podemos recuperar sus permisos
  $sentenciaPermisos = $Conn->prepare("SELECT * FROM rol WHERE idRol IN (SELECT idRol FROM usuarios WHERE idUsuario = ?)");
  $sentenciaPermisos->bind_param("i", $idUsuario);
  $sentenciaPermisos->execute();
  $resultadoPermisos = $sentenciaPermisos->get_result();
  $permisos = $resultadoPermisos->fetch_assoc();

  // $permisos ahora contiene los permisos del usuario
} else {
  echo "No se encontró el usuario en la base de datos.";
}

function getCount($tab)
{
  $tabla = $tab;
  global $Conn;
  $sql = "SELECT * FROM $tabla WHERE estado='Activo'";
  $rs = mysqli_query($Conn, $sql);
  $rws = mysqli_num_rows($rs);
  return $rws;
}

?>
<!DOCTYPE html>
<html lang="es" dir="ltr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inicio | Biblioteca</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
  <!-- SWAL -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.6/dist/sweetalert2.all.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.6/dist/sweetalert2.min.css" rel="stylesheet">
  <!-- JQuery Call -->
  <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
  <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
  <!-- Icon -->
  <link rel="apple-touch-icon" sizes="180x180" href="../img/Icon/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="../img/Icon/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="../img/Icon/favicon-16x16.png">
  <link rel="manifest" href="../img/Icon/site.webmanifest">
  <link rel="stylesheet" href="../css/index.css">
  <script>
    window.history.forward();
  </script>

  <style>
    /* Definición de la animación */
    @keyframes moveText {
      0% {
        left: 1%;
      }

      /* Comienza fuera del contenedor */
      100% {
        left: 100%;
      }

      /* Termina fuera del contenedor */
    }

    a {
      cursor: default;
    }

    .Op {
      display: flex;
      justify-content: center;
      align-content: center;
      flex-wrap: wrap;
      font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;

    }

    
  </style>
</head>

<body>


  <nav class="main-menu">
    <ul>
      <li>
        <a href="index.php">
        <i class="fa fa-box fa-2x"></i>
          <span class="nav-text"><strong>Inicio | Biblioteca</strong></span>
        </a>
      </li><br><br>
      <?php

      if ($permisos['libro'] == 1) {
        echo '<li class="has-subnav">
            <a href="javascript:void(0);" class="subLibros" ondblclick="loadLibrosForm();">
              <i class="fa fa-book fa-2x"></i>
              <span class="nav-text">Libros <span class="fas fa-caret-down flecLib"></span></span>
            </a>
            <ul class="navOcLib">
              <li><a href="javascript:void(0);" onclick="loadLibroForm();">Libros</a></li>
              <li><a href="javascript:void(0);" onclick="loadEditorialesForm();">Editoriales</a></li>
              <li><a href="javascript:void(0);" onclick="loadGeneroForm();">Generos</a></li>
              <li><a href="javascript:void(0);" onclick="loadSeccionesForm();">Secciones</a></li>
              <li><a href="javascript:void(0);" onclick="loadSolicitudForm();">Solicitudes</a></li>
            </ul>
          </li>';
      }

      if ($permisos['mobiliario'] == 1) {
        echo '<li class="has-subnav">';
        echo '<a href="javascript:void(0);" onclick="loadMobiliarioForm();">';
        echo '<i class="fa fa-archive fa-2x"></i>';
        echo '<span class="nav-text">Mobiliario</span>';
        echo '</a>';
        echo '</li>';
      }

      if ($permisos['prestamo'] == 1) {
        echo '<li>
              <a href="javascript:void(0);" onclick="loadPrestamoForm();">
                <i class="fa fa-tags fa-2x"></i>
                <span class="nav-text">Prestamos</span>
              </a>
            </li>';
      }

      if ($permisos['prestamo'] == 1) {
        echo '<li>
        <a href="javascript:void(0);" class="subEnt" ondblclick="loadentregaForm();">
         <i class="fa fa-graduation-cap fa-2x"></i>
          <span class="nav-text">Entrega de Libros <span class="fas fa-caret-down flecEnt"></span></span>

        </a>
      
        <ul class="navOcEnt">
          <li><a href="javascript:void(0);" onclick="loadAsignaturaForm();">Asignatura</a></li>
          <li><a href="javascript:void(0);" onclick="loadlibroasigForm();">Libros de Facultad</a></li>
          <li><a href="javascript:void(0);" onclick="loadEntregaForm();">Entrega</a></li>

            </ul>
          </li>';
      }


      if ($permisos['solicitantes'] == 1) {
        echo '<li>
            <a href="javascript:void(0);" onclick="loadSolicitanteForm();">
              <i class="fa fa-users fa-2x"></i>
              <span class="nav-text">Solicitantes</span>
            </a>
          </li>';
      }



      if ($permisos['configuracion'] == 1) {
        echo '<li>
        <a href="javascript:void(0);" class="subConfig" ondblclick="loadConfigForm();">
          <i class="fa fa-cogs fa-2x"></i>
          <span class="nav-text">Configuracion <span class="fas fa-caret-down flecConf"></span></span>

        </a>
      

        <ul class="navOcConf">
          <li><a href="javascript:void(0);" onclick="loadUsuarioForm();">Usuarios</a></li>
          <li><a href="javascript:void(0);" onclick="loadCampusForm();">Campus</a></li>
          <li><a href="javascript:void(0);" onclick="loadHistorialRegistroForm();">Roles</a></li>

        </ul>
      </li>';
      }

      ?>
    </ul>

    <ul class="logout">
      <li>
        <a href="miCuenta.php" target="_blank">
          <i class="fa fa-user fa-2x"></i>
          <span class="nav-text"><?php echo $_SESSION['username']; ?></span>
        </a>
      </li>

      <li>
        <!-- onclick="Logout(); -->
        <a onclick="Logout();">
          <i class="fa fa-close fa-2x"></i>
          <span class="nav-text">Cerrar Sesion</span>
        </a>
      </li>
    </ul>
  </nav>

  <main id="formContainer">
    <div class="Op">
      <div class="sal">
        <h1>Bienvenido <?php echo $username ?> | Biblioteca</h1>
      </div>
      <?php
      $sql = "SELECT campus FROM campus WHERE idCampus ='$idcampus'";
      $result = $Conn->query($sql);
      if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          $ccmp = $row['campus'];
        }
      }
      ?>

      <div class="Op"> <a href="javascript:void(0);" onclick="loadLibroForm();"><ion-icon name="book-outline"></a> </ion-icon><span class="Tt"><?= getCount('libros') ?> Libros registrados </span></div>
      <div class="Op"><a href="javascript:void(0);" onclick="loadPrestamoForm();"><ion-icon name="repeat-outline"></a></ion-icon><span class="Tt"><?= getCount('prestamo') ?> Prestamos creados</span></div>
      <div class="Op"><a href="javascript:void(0);" onclick="loadSolicitudForm();"><ion-icon name="archive-outline"></a></ion-icon><span class="Tt"><?= getCount('solicitudes') ?> Solicitudes creadas</span></div>
      <div class="Op"><a href="javascript:void(0);"><ion-icon name="business-outline"></a></ion-icon><span class="Tt">Campus <?= $ccmp ?></span></div>
    </div>

  </main>


  <script src="https://kit.fontawesome.com/a076d05399.js"></script>
  <script>
    function loadLibroForm() {
      document.getElementById('formContainer').innerHTML = '<iframe src="libro.php" frameborder="0"></iframe>';
    }

    function loadReportepdfForm() {
      document.getElementById('formContainer').innerHTML = '<iframe src="reportepdf.php" frameborder="0"></iframe>';
    }

    function loadSeccionesForm() {
      document.getElementById('formContainer').innerHTML = '<iframe src="seccion.php" frameborder="0"></iframe>';
    }


    function loadEditorialesForm() {
      document.getElementById('formContainer').innerHTML = '<iframe src="editorial.php" frameborder="0"></iframe>';
    }

    function loadHistorialRegistroForm() {
      document.getElementById('formContainer').innerHTML = '<iframe src="roles.php" frameborder="0"></iframe>';
    }

    function loadGeneroForm() {
      document.getElementById('formContainer').innerHTML = '<iframe src="../pages/generos.php" frameborder="0"></iframe>';
    }

    function loadSolicitanteForm() {
      document.getElementById('formContainer').innerHTML = '<iframe src="../pages/solicitantes.php" frameborder="0"></iframe>'; //Abel
    }

    function loadSeccionForm() {
      document.getElementById('formContainer').innerHTML = '<iframe src="../pages/seccion.php" frameborder="0"></iframe>';
    }

    function loadUsuarioForm() {
      document.getElementById('formContainer').innerHTML = '<iframe src="usuarios.php" frameborder="0"></iframe>';
    }

    function loadCampusForm() {
      document.getElementById('formContainer').innerHTML = '<iframe src="campus.php" frameborder="0"></iframe>';
    }

    function loadLibrosForm() {
      document.getElementById('formContainer').innerHTML = '<iframe src="libro.php" frameborder="0"></iframe>';
    }

    function loadSolicitudForm() {
      document.getElementById('formContainer').innerHTML = '<iframe src="solicitudes.php" frameborder="0"></iframe>';
    }

    function loadPrestamoForm() {
      document.getElementById('formContainer').innerHTML = '<iframe src="prestamos.php" frameborder="0"></iframe>';
    }

    function loadEditorialForm() {
      document.getElementById('formContainer').innerHTML = '<iframe src="editorial.php" frameborder="0"></iframe>'; //Abel
    }

    function loadMobiliarioForm() {
      document.getElementById('formContainer').innerHTML = '<iframe src="mobiliario.php" frameborder="0"></iframe>'; //Abel
    }

    //ultimo agregado
    function loadAsignaturaForm() {
      document.getElementById('formContainer').innerHTML = '<iframe src="asignaturas.php" frameborder="0"></iframe>'; //Abel
    }

    function loadEntregaForm() {
      document.getElementById('formContainer').innerHTML = '<iframe src="entregas.php" frameborder="0"></iframe>'; //Abel
    }

    function loadlibroasigForm() {
      document.getElementById('formContainer').innerHTML = '<iframe src="libroasignatura.php" frameborder="0"></iframe>'; //Abel
    }



    function Logout() {
      Swal.fire({
        title: "Cerrar esta sesion",
        text: "Cerrar Sesion",
        icon: "question",
        showConfirmButton: false,
        showCancelButton: false,
        html: "<a style='background-color: rgba(235, 8, 8, 0.5);border: noneborder-radius: 5px;text-decoration: none; padding= 15px;' href='../php/logout.php'>Cerrar Sesion</a>"

      })
    }

    //Funciones para desplegar menu
    $('.subLibros').click(function() {
      $('.navOcLib').toggleClass("navShLib");
      $('.flecLib').toggleClass("rotate");

      //ocultar otros cuando este abra
      $('.navOcRep').removeClass("navShRep");
      $('.flecRep').removeClass("rotate");
      $('.navOcConf').removeClass("navShConf");
      $('.flecConf').removeClass("rotate");
      $('.flecEnt').removeClass("rotate");
      $('.navOcEnt').removeClass("navShEnt");
      $('.flecEnt').removeClass("rotate");
    });


    $('.subReportes').click(function() {
      $('.navOcRep').toggleClass("navShRep");
      $('.flecRep').toggleClass("rotate");
      //ocultar otros cuando este abra
      $('.navOcLib').removeClass("navShLib");
      $('.flecLib').removeClass("rotate");
      $('.navOcConf').removeClass("navShConf");
      $('.flecConf').removeClass("rotate");
      $('.navOcEnt').removeClass("navShEnt");
      $('.flecEnt').removeClass("rotate");
    });


    $('.subConfig').click(function() {
      $('.navOcConf').toggleClass("navShConf");
      $('.flecConf').toggleClass("rotate");
      //ocultar otros cuando este abra
      $('.navOcLib').removeClass("navShLib");
      $('.flecLib').removeClass("rotate");
      $('.navOcRep').removeClass("navShRep");
      $('.flecRep').removeClass("rotate");
      $('.navOcEnt').removeClass("navShEnt");
      $('.flecEnt').removeClass("rotate");
    });

    $('.subEnt').click(function() {
      $('.navOcEnt').toggleClass("navShEnt");
      $('.flecEnt').toggleClass("rotate");
      //ocultar otros cuando este abra
      $('.navOcLib').removeClass("navShLib");
      $('.flecLib').removeClass("rotate");
      $('.navOcRep').removeClass("navShRep");
      $('.flecRep').removeClass("rotate");
      $('.navOcConf').removeClass("navShConf");
      $('.flecConf').removeClass("rotate");
    });

  </script>
</body>
</html>