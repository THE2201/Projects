<?php
require('../php/connectionBD.php');
session_start();

if (isset($_SESSION['username'])) {
    header('Location: index.php');
  }

?>

<!DOCTYPE html>
<html lang="es" dir="ltr">

<head>
    <meta charset='UTF-8'>
    <title>Login | Biblioteca</title>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <link rel='stylesheet' href='../css/estilos.css'>
    <!-- Icon -->
    <link rel="apple-touch-icon" sizes="180x180" href="../img/Icon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../img/Icon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../img/Icon/favicon-16x16.png">
    <link rel="manifest" href="../img/Icon/site.webmanifest">

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.6/dist/sweetalert2.all.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.6/dist/sweetalert2.min.css" rel="stylesheet">

    <script>
        window.history.forward();

        function altLoginIncomp() {
            const Toast = Swal.mixin({
                toast: true,
                position: "top-right",
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
            });
            Toast.fire({
                icon: "error",
                title: "Usuario o contraseña incorrecto."
            });
        }
        function altLoginVacio() {
            const Toast = Swal.mixin({
                toast: true,
                position: "top-right",
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
            });
            Toast.fire({
                icon: "warning",
                title: "Ingrese credenciales en los espacios."
            });
        }

        
    </script>

</head>

<body>
    <section>
        <div class="formulario">
            <div class="form">
                <form action="inicio.php" method="POST">
                    <h1>Biblioteca UTH</h1>
                    <h2>Iniciar Sesión</h2>

                    <div class="input"> <ion-icon name="person-outline"></ion-icon>
                        <input type="text" title="Espacio Usuario" name="user">
                        <label for="user">Usuario</label>
                    </div>

                    <div class="input"> <ion-icon name="lock-closed-outline"></ion-icon>
                        <input type="password" title="Espacio Contraseña" name="passwd">
                        <label for="passwd">Contraseña</label>
                    </div>


                    <button type="submit" id="btLogin" name="btLogin">Iniciar Sesión</button><br><br>
                    <button type="reset">Cancelar</button>
                </form>
            </div>
        </div>
    </section>
</body>

</html>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['btLogin'])) {
        if (!empty($_POST["user"]) && !empty($_POST["passwd"])) {
            $usuario = $_POST["user"];
            $contra = $_POST["passwd"];

            $SQL = "SELECT * FROM usuarios WHERE usuario='$usuario' AND password='$contra'";
            $RS = $Conn->Query($SQL);

            if ($RS->num_rows == 1) {
                $_SESSION["username"] = $usuario;
                $_SESSION["password"] = $contra;
                header("Location: index.php");
            } else {
                echo "<script>altLoginIncomp();</script>";
            }
            $Conn->close();
        } else {
            echo "<script>altLoginVacio();</script>";
        }
    }
}
?>