<?php
require('../php/connectionBD.php');
session_start();
$usuario = $_SESSION['username'];

if (!isset($usuario)) {
    header('Location: inicio.php');
  }

$sqlPermisos = "SELECT p.editar, p.eliminar, P.agregar
                FROM usuarios u
                INNER JOIN rol r ON u.idRol = r.idRol
                INNER JOIN permisos p ON r.idPermiso = p.idPermiso
                WHERE u.usuario = '$usuario'";
$resultPermisos = $Conn->query($sqlPermisos);

if ($resultPermisos->num_rows > 0) {
    // Obtener los permisos del usuario
    $permisos = $resultPermisos->fetch_assoc();
} else {
    // Si no se encontraron permisos, se pueden establecer valores predeterminados o manejar el error según sea necesario
    // Por ejemplo, puedes asignar valores predeterminados para los permisos o mostrar un mensaje de error
    $permisos = array('editar' => 0, 'eliminar' => 0); // Valores predeterminados
    echo "No se encontraron permisos para el usuario.";
}

?>
<!DOCTYPE html>
<html lang="es" dir="ltr">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="#" />
    <title>Libros | Biblioteca</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <!--datables CSS básico-->
    <link rel="stylesheet" href="https://cdn.datatables.net/2.0.2/css/dataTables.dataTables.min.css">
    <!--datables estilo bootstrap 5 CSS-->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/css/bootstrap-select.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/2.0.2/css/dataTables.bootstrap5.css">
    <!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

</head>

<body>
    <header>

        <h4 class="text-center p-3 mb-2 bg-success text-white">Libros</h4>
    </header>

    <div class="container">
    <div class="col-lg-12">
        <?php
            if ($permisos['agregar'] == 1) {
                echo '<button id="btnNuevo" type="button" class="btn btn-success" data-toggle="modal" data-target="#modalCRUD">Nuevo</button><br><br>';
                $reporte_url = "reportes/reporte_libros.pdf";
                echo '<a href="../reportes/reporte_libros.php" target="_blank" class="btn btn-success">Ver Reporte</a>';
            } else {
                echo "<td></td>"; // Espacio vacío si no tiene permisos
            }
            ?>
        </div>
    </div>
    </div>
    <br>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table id="tablaLibros" class="table table-striped table-bordered table-condensed" style="width:100%">
                        <thead class="text-center">
                            <tr>
                                <th>ID</th>
                                <th>Campus</th>
                                <th>Asignatura</th>
                                <th>Titulo</th>
                                <th>Autor</th>
                                <th>Editorial</th>
                                <th>Disponible</th>
                                <th>Total</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <?php


// Crear una instancia de la clase Conexiong y conectarse a la base de datos
$connection = Conexiong::Conectarg();

$query = "SELECT 
librosasignaturas.idLibrosAsignatura, 
librosasignaturas.titulo, 
librosasignaturas.autor, 

campus.campus AS nombre_campus, 
asignaturas.asignatura AS nombre_asignatura,
editoriales.nombre AS nombre_editorial, 
librosasignaturas.total,
librosasignaturas.disponible 
FROM 
librosasignaturas 
INNER JOIN 
campus ON librosasignaturas.idCampus = campus.idCampus 
INNER JOIN 
asignaturas ON librosasignaturas.IdAsignatura = asignaturas.idAsignatura 
INNER JOIN 
editoriales ON librosasignaturas.ideditorial = editoriales.idEditorial 
WHERE 
librosasignaturas.estado = 'Activo';"; 

// Preparar la consulta SQL
$stmt = $connection->prepare($query);
// Ejecutar la consulta
$stmt->execute();
// Obtener los resultados
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($result) > 0) {
    foreach ($result as $row) {
        echo "<tr>";
        echo "<td>" . $row['idLibrosAsignatura'] . "</td>";
        echo "<td>" . $row['nombre_campus'] . "</td>";
        echo "<td>" . $row['nombre_asignatura'] . "</td>";
        echo "<td>" . $row['titulo'] . "</td>";
        echo "<td>" . $row['autor'] . "</td>";
        echo "<td>" . $row['nombre_editorial'] . "</td>";
        echo "<td>" . $row['disponible'] . "</td>";
        echo "<td>" . $row['total'] . "</td>";
        echo "<td>";
                                    
        if ($permisos['editar'] == 1 && $permisos['eliminar'] == 1) {
            echo "<button class='btn btn-primary btnEditar' data-id='".$row["idLibrosAsignatura"]."'>Editar</button>";
            echo "<button class='btn btn-danger btnBorrar' data-id='".$row["idLibrosAsignatura"]."'>Borrar</button>";
            echo "<button class='btn btn-success btnAgregar' data-id='".$row["idLibrosAsignatura"]."'>Agregar</button>";
        } elseif ($permisos['editar'] == 1 ) {
            echo "<button class='btn btn-primary btnEditar' data-id='".$row["idLibrosAsignatura"]."'>Editar</button>";
        } elseif ($permisos['eliminar'] == 1) {
            echo "<button class='btn btn-danger btnBorrar' data-id='".$row["idLibrosAsignatura"]."'>Borrar</button>";
        } else {
            echo "</td>"; // Espacio vacío si no tiene permisos
        }
        
        echo "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='4'>0 resultados</td></tr>";
}

// Consulta para obtener los campus desde la base de datos
$query_campus = "SELECT idCampus, campus FROM campus WHERE estado = 'Activo'";
$stmt_campus = $connection->prepare($query_campus);
$stmt_campus->execute();
$campus_data = $stmt_campus->fetchAll(PDO::FETCH_ASSOC);

// Consulta para obtener las secciones desde la base de datos
$query_seccion = "SELECT idSeccion, seccion FROM secciones WHERE estado = 'Activo'";
$stmt_seccion = $connection->prepare($query_seccion);
$stmt_seccion->execute();
$seccion_data = $stmt_seccion->fetchAll(PDO::FETCH_ASSOC);

// Consulta para obtener los géneros desde la base de datos
$query_genero = "SELECT idGenero, genero FROM generos WHERE estado = 'Activo'";
$stmt_genero = $connection->prepare($query_genero);
$stmt_genero->execute();
$genero_data = $stmt_genero->fetchAll(PDO::FETCH_ASSOC);

// Consulta para obtener las editoriales desde la base de datos
$query_editorial = "SELECT idEditorial, nombre FROM editoriales WHERE estado = 'Activo'";
$stmt_editorial = $connection->prepare($query_editorial);
$stmt_editorial->execute();
$editorial_data = $stmt_editorial->fetchAll(PDO::FETCH_ASSOC);

// Cerrar la conexión
$connection = null;
?>



<!-- SELECT * FROM libros WHERE estado = 'Activo'; -->

                        <tbody>
                            <!-- <?php
                                    //foreach($data as $dat) {
                                    //
                                    ?> -->
                            <!-- <tr>
                                <td><?php echo $dat['id'] ?></td>
                                <td><?php echo $dat['local'] ?></td>
                                <td><?php echo $dat['genero'] ?></td>
                                <td><?php echo $dat['titulo'] ?></td>
                                <td><?php echo $dat['autor'] ?></td>
                                <td><?php echo $dat['editorial'] ?></td>
                                <td><?php echo $dat['idioma'] ?></td>
                                <td><?php echo $dat['cantidad'] ?></td>
                                                             
                                <td></td>
                            </tr>
                            //<?php
                                // }
                                ?>-->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<!-- Modal para CRUD -->
<div class="modal fade" id="modalCRUD" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Agregar Libro</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="formLibros" method="POST" action="../php/ins_libroasig.php" class="needs-validation" novalidate>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="campus" class="col-form-label">Campus:</label>
                        <select class="form-control" id="campus" name="campus" required>
                                <option value="">Seleccione una opcion</option>
                                <?php
                                $sql = mysqli_query($Conn, "SELECT campus FROM campus WHERE estado ='Activo'");
                                while ($row = mysqli_fetch_array($sql)) {
                                    echo '<option value="' . $row["campus"] . '">' . $row["campus"] . '</option>';
                                }
                                ?>
                            </select>
                    </div>
                    <div class="form-group">
                        <label for="asignatura" class="col-form-label">Asignatura:</label>
                        <select class="form-control" id="asignatura" name="asignatura" required>
                                <option value="">Seleccione una opcion</option>
                                <?php
                                $sql = mysqli_query($Conn, "SELECT asignatura FROM asignaturas WHERE estado ='Activo'");
                                while ($row = mysqli_fetch_array($sql)) {
                                    echo '<option value="' . $row["asignatura"] . '">' . $row["asignatura"] . '</option>';
                                }
                                ?>
                            </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="titulo" class="col-form-label">Título:</label>
                        <input type="text" class="form-control" id="titulo" name="titulo" >
                    </div>
                    <div class="form-group">
                        <label for="autor" class="col-form-label">Autor:</label>
                        <input type="text" class="form-control" id="autor" name="autor" required>
                    </div>
                    <div class="form-group">
                        <label for="editorial" class="col-form-label">Asignatura:</label>
                        <select class="form-control" id="editorial" name="editorial" required>
                                <option value="">Seleccione una opcion</option>
                                <?php
                                $sql = mysqli_query($Conn, "SELECT nombre FROM editoriales WHERE estado ='Activo'");
                                while ($row = mysqli_fetch_array($sql)) {
                                    echo '<option value="' . $row["nombre"] . '">' . $row["nombre"] . '</option>';
                                }
                                ?>
                            </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="cantidad" class="col-form-label">Cantidad:</label>
                        <input type="number" class="form-control" id="cantidad" name="cantidad" required >
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-dark" id="guardar" name="guardar">Guardar</button>
                </div>
            </form>
        </div>
    </div>
</div>


<!-- Modal para Editar -->
<div class="modal fade" id="modalEditar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Agregar Libro</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="formEditarRegistro" method="POST" action="../php/upd_libroasig.php" class="needs-validation" novalidate>
                <div class="modal-body">
                <input type="hidden" id="edit_idlibroasig" name="edit_idlibroasig">
                    <div class="form-group">
                        <label for="campus" class="col-form-label">Campus:</label>
                        <select class="form-control" id="edit_campus" name="edit_campus" required>
                                <option value="">Seleccione una opcion</option>
                                <?php
                                $sql = mysqli_query($Conn, "SELECT campus FROM campus WHERE estado ='Activo'");
                                while ($row = mysqli_fetch_array($sql)) {
                                    echo '<option value="' . $row["campus"] . '">' . $row["campus"] . '</option>';
                                }
                                ?>
                            </select>
                    </div>
                    <div class="form-group">
                        <label for="asignatura" class="col-form-label">Asignatura:</label>
                        <select class="form-control" id="edit_asignatura" name="edit_asignatura" required>
                                <option value="">Seleccione una opcion</option>
                                <?php
                                $sql = mysqli_query($Conn, "SELECT asignatura FROM asignaturas WHERE estado ='Activo'");
                                while ($row = mysqli_fetch_array($sql)) {
                                    echo '<option value="' . $row["asignatura"] . '">' . $row["asignatura"] . '</option>';
                                }
                                ?>
                            </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="titulo" class="col-form-label">Título:</label>
                        <input type="text" class="form-control" id="edit_titulo" name="edit_titulo" required>
                    </div>
                    <div class="form-group">
                        <label for="autor" class="col-form-label">Autor:</label>
                        <input type="text" class="form-control" id="edit_autor" name="edit_autor" required>
                    </div>
                    <div class="form-group">
                        <label for="editorial" class="col-form-label">Asignatura:</label>
                        <select class="form-control" id="edit_editorial" name="edit_editorial" required>
                                <option value="">Seleccione una opcion</option>
                                <?php
                                $sql = mysqli_query($Conn, "SELECT nombre FROM editoriales WHERE estado ='Activo'");
                                while ($row = mysqli_fetch_array($sql)) {
                                    echo '<option value="' . $row["nombre"] . '">' . $row["nombre"] . '</option>';
                                }
                                ?>
                            </select>
                    </div>
                    
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-dark" id="guardar" name="guardar">Guardar</button>
                </div>
            </form>
        </div>
    </div>
</div>



<script>
$(document).ready(function () {
    tablaLibros = $("#tablaLibros").DataTable({
        // Configuración del DataTable
        "language": {
            "lengthMenu": "Mostrar _MENU_ registros",
            "zeroRecords": "No se encontraron resultados",
            "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
            "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
            "infoFiltered": "(filtrado de un total de _MAX_ registros)",
            "sSearch": "Buscar:",
            "oPaginate": {
                "sFirst": "Primero",
                "sLast": "Último",
                "sNext": "Siguiente",
                "sPrevious": "Anterior"
            },
            "sProcessing": "Procesando...",
        }
    });

    $("#btnNuevo").click(function() {
                $("#formPersonas").trigger("reset");
                $(".modal-header").css("background-color", "#004e18");
                $(".modal-header").css("color", "white");
                $(".modal-title").text("Registro");
                $("#modalCRUD").modal("show");
                id = null;
                opcion = 1;
            });


            $(document).ready(function() {
            // Escuchar el evento click del botón de editar
            $(document).on("click", ".btnEditar", function() {
                // Obtener el ID del libro a editar
                var idLibrosAsignatura = $(this).attr('data-id');

        // Realizar una solicitud AJAX para obtener los detalles del libro a editar
        $.ajax({
            url: '../php/obt_libroasig.php',
            method: 'POST',
            data: { idLibrosAsignatura: idLibrosAsignatura },
            dataType: 'json',
            success: function(response) {
                // Rellenar el formulario de edición con los detalles del libro
                $('#edit_idlibroasig').val(response.idLibrosAsignatura);
                $('#edit_titulo').val(response.titulo);
                $('#edit_editorial').val(response.nombre);
                $('#edit_autor').val(response.autor);
                $('#edit_asignatura').val(response.asignatura);
                $('#edit_campus').val(response.campus);

                // Mostrar el modal de edición
                $('#modalEditar').modal('show');
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
                    }
                });
            });
        });

            $('#formEditarRegistro').submit(function(e) {
                e.preventDefault();
                var form = this;

                if (form.checkValidity() === false) {
                    e.stopPropagation(); // Detener la propagación del evento para evitar que se muestre la validación predeterminada del navegador
                    form.classList.add('was-validated'); // Marcar los campos inválidos
                    return;
                }

                $.ajax({
                    url: $(this).attr('action'),
                    method: $(this).attr('method'),
                    data: $(this).serialize(),
                    success: function(response) {
                        alert(response);
                        $('#modalEditar').modal('hide');
                        location.reload();
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });
        });
      

  




$(document).ready(function() {
    // Escuchar el evento click del botón de borrado
    $(document).on("click", ".btnBorrar", function() {
        // Obtener el ID del libro a eliminar
        var idLibrosAsignatura = $(this).closest("tr").find("td:first").text();

        // Mostrar mensaje de confirmación antes de eliminar el libro
        if (confirm("¿Estás seguro de eliminar este libro?")) {
            // Realizar la solicitud AJAX para eliminar el libro
            $.ajax({
                type: "POST",
                url: "../php/del_libroasi.php", // Ruta de tu script PHP para eliminar el libro de la base de datos
                data: {
                    idLibrosAsignatura: idLibrosAsignatura
                },
                success: function(response) {
                    // Mostrar mensaje de éxito o error
                    alert(response);
                    // Recargar la página después de eliminar el libro
                    location.reload();
                },
                error: function(xhr, status, error) {
                    // Manejar errores de la solicitud AJAX
                    console.error(xhr.responseText);
                    alert("Error al eliminar el libro. Por favor, inténtalo de nuevo.");
                }
            });
        }
    });
});

  $(document).ready(function(){
    $('.btnAgregar').click(function(){
        var idLibrosAsignatura = $(this).data('id'); // Obtener el idLibros de la fila correspondiente
        
        var cantidad = prompt("Ingrese la cantidad a agregar:", "0"); // Solicitar al usuario que ingrese la cantidad
        
        // Verificar si se ingresó una cantidad válida
        if (cantidad !== null && !isNaN(cantidad.trim())) {
            // Realizar la solicitud AJAX solo si se ingresó una cantidad válida
            $.ajax({
                url: '../php/agregar_cant_libroasig.php',
                type: 'post',
                data: { idLibrosAsignatura: idLibrosAsignatura, cantidad: cantidad },
                success: function(response){
                    alert(response);
                   window.location.reload();   
                },
                error: function(xhr, status, error) {
                    alert("Error: " + xhr.responseText);
                }
            });
        } else {
            alert("Por favor, ingrese una cantidad válida.");
        }
    });
});

$(document).ready(function(){
    $('.guardar').click(function(){
        var editorial = $("#editorial").val();
            var autor = $("#autor").val();
            var titulo = $("#titulo").val();
            var asignatura = $("#asignatura").val();
            var campus_nombre = $("#campus").val();
            var cantidad = $("#cantidad").val();

            // Imprimir los valores en la consola
            console.log("Editorial: " + editorial);
            console.log("Autor: " + autor);
            console.log("Título: " + titulo);
            console.log("Asignatura: " + asignatura);
            console.log("Campus: " + campus_nombre);
            console.log("Cantidad: " + cantidad);
    });
});



(function() {
            'use strict';
            window.addEventListener('load', function() {
                var forms = document.getElementsByClassName('needs-validation');
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault(); // Detiene el envío del formulario si la validación falla
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();
</script>



    <!-- jQuery, Popper.js, Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/js/bootstrap-select.min.js"></script>

    <!-- datatables JS -->
    <script src="https://cdn.datatables.net/2.0.2/js/dataTables.js"></script>
    
    



</body>

</html>
