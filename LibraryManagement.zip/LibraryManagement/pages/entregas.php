<?php
require('../php/connectionBD.php');
session_start();
$usuario = $_SESSION['username'];
if (!isset($usuario)) {
    header('Location: inicio.php');
  }
$sqlPermisos = "SELECT p.editar, p.eliminar, P.agregar
                FROM usuarios u
                INNER JOIN rol r ON u.idRol = r.idRol
                INNER JOIN permisos p ON r.idPermiso = p.idPermiso
                WHERE u.usuario = '$usuario'";
$resultPermisos = $Conn->query($sqlPermisos);

if ($resultPermisos->num_rows > 0) {
    $permisos = $resultPermisos->fetch_assoc();
} else {
    $permisos = array('editar' => 0, 'eliminar' => 0); 
    echo "No se encontraron permisos para el usuario.";
}

$sql = "SELECT e.idEntrega, e.idLibrosAsignatura, e.alumno, e.cuenta, ca.campus, e.cantidad, c.titulo, e.fechaEntrega 
        FROM entregas e
        INNER JOIN librosasignaturas c ON e.idLibrosAsignatura = c.idLibrosAsignatura
        INNER JOIN campus ca ON e.idCampus = ca.idCampus
        WHERE e.estado = 'Activo'";
$result = $Conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es" dir="ltr">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="#" />
    <title>Entregas | Biblioteca</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <!--datables CSS básico-->
    <link rel="stylesheet" href="https://cdn.datatables.net/2.0.2/css/dataTables.dataTables.min.css">
    <!--datables estilo bootstrap 5 CSS-->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/2.0.2/css/dataTables.bootstrap5.css">

    
</head>

<body>
    <header>
        <h4 class="text-center p-3 mb-2 bg-success text-white">Entregas</h4>
    </header>

    <div class="container">
        <div class="row"></div>
        <div class="col-lg-12">
        <?php
            if ($permisos['agregar'] == 1) {
                echo '<button id="btnNuevo" type="button" class="btn btn-success" data-toggle="modal" data-target="#modalCRUD">Nuevo</button>';
            } else {
                echo "<td></td>"; // Espacio vacío si no tiene permisos
            }
            ?>
        </div>
    </div>
    </div>
    <br>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table id="tablaMob" class="table table-striped table-bordered table-condensed" style="width:100%">
                        <thead class="text-center">
                            <tr>
                                <th>ID</th>
                                <th>Libro</th>
                                <th>Cuenta</th>
                                <th>Alumno</th>
                                <th>Campus</th>
                                <th>Cantidad</th>
                                <th>Fecha Entrega</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                                    echo "<tr>";
                                    echo "<td>".$row["idEntrega"]."</td>";
                                    echo "<td>".$row["titulo"]."</td>";
                                    echo "<td>".$row["cuenta"]."</td>";
                                    echo "<td>".$row["alumno"]."</td>";
                                    echo "<td>".$row["campus"]."</td>";
                                    echo "<td>".$row["cantidad"]."</td>";
                                    echo "<td>".$row["fechaEntrega"]."</td>";
                                    echo "<td>";
                                    
                                    if ($permisos['editar'] == 1 && $permisos['eliminar'] == 1) {
                                        echo "<button class='btn btn-primary btnEditar' data-id='".$row["idEntrega"]."'>Editar</button>";
                                        echo "<button class='btn btn-danger btnBorrar' data-id='".$row["idEntrega"]."'>Borrar</button>";
                                    } elseif ($permisos['editar'] == 1 ) {
                                        echo "<button class='btn btn-primary btnEditar' data-id='".$row["idEntrega"]."'>Editar</button>";
                                    } elseif ($permisos['eliminar'] == 1) {
                                        echo "<button class='btn btn-danger btnBorrar' data-id='".$row["idEntrega"]."'>Borrar</button>";
                                    } else {
                                        echo "</td>"; // Espacio vacío si no tiene permisos
                                    }
                                    
                                    echo "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='7'>No se encontraron registros</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!--Modal para CRUD-->
    <div class="modal fade" id="modalCRUD" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Nuevo Registro</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="formNuevoRegistro" method="POST" action="../php/ins_Entrega.php" class="needs-validation" novalidate>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="titulo" class="col-form-label">Titulo:</label>
                            <select class="form-control" id="titulo" name="titulo" required>
                                <?php
                                    $sql_titulo = "SELECT * FROM librosasignaturas WHERE estado = 'Activo'";
                                    $result_titulo = $Conn->query($sql_titulo);
                                    if ($result_titulo->num_rows > 0) {
                                        while($row_titulo = $result_titulo->fetch_assoc()) {
                                            echo "<option value='".$row_titulo["idLibrosAsignatura"]."'>".$row_titulo["titulo"]."</option>";
                                        }
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="form-group">
                                    <label for="edit_alumno" class="col-form-label">Cuenta:</label>
                                    <input type="text" class="form-control" id="cuenta" name="cuenta" maxlength="12" oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                </div>
                        <div class="form-group">
                            <label for="alumno" class="col-form-label">Alumno:</label>
                            <input type="text" class="form-control" id="alumno" name="alumno" required>
                        </div>
                        <div class="form-group">
                            <label for="titulo" class="col-form-label">Campus:</label>
                            <select class="form-control" id="campus" name="campus" required>
                                <?php
                                    $sql_titulo = "SELECT * FROM campus WHERE estado = 'Activo'";
                                    $result_titulo = $Conn->query($sql_titulo);
                                    if ($result_titulo->num_rows > 0) {
                                        while($row_titulo = $result_titulo->fetch_assoc()) {
                                            echo "<option value='".$row_titulo["campus"]."'>".$row_titulo["campus"]."</option>";
                                        }
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="cantidad" class="col-form-label">Cantidad:</label>
                            <input type="number" class="form-control" value="1" id="cantidad" name="cantidad" required readonly>

                        </div>
                        <div class="form-group">
                            <label for="cantidad" class="col-form-label">Fecha de Entrega:</label>
                            <input type="date" class="form-control" id="fechaEntrega" name="fechaEntrega" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-dark">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal para editar registros -->
    <div class="modal fade" id="modalEditar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Editar Registro</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="formEditarRegistro" method="POST" action="../php/upd_entregas.php">
                    <div class="modal-body">
                        <input type="hidden" id="edit_idEntrega" name="edit_idEntrega" >
                        <div class="form-group">
                            <label for="titulo" class="col-form-label">Titulo:</label>
                           
                            <select class="form-control" id="edit_titulo" name="edit_titulo" required disabled>
                                <?php
                                    $sql_titulo = "SELECT * FROM librosasignaturas WHERE estado = 'Activo'";
                                    $result_titulo = $Conn->query($sql_titulo);
                                    if ($result_titulo->num_rows > 0) {
                                        while($row_titulo = $result_titulo->fetch_assoc()) {
                                            echo "<option value='".$row_titulo["idLibrosAsignatura"]."'>".$row_titulo["titulo"]."</option>";
                                        }
                                    }
                                ?>
                            </select>
                        </div>
                                     <div class="form-group">
                                    <label for="edit_alumno" class="col-form-label">Cuenta:</label>
                                    <input type="text" class="form-control" id="edit_cuenta" name="edit_cuenta" maxlength="12" oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                </div>
                        <div class="form-group">
                            <label for="edit_alumno" class="col-form-label">Alumno:</label>
                            <input type="text" class="form-control" id="edit_alumno" name="edit_alumno">
                        </div>
                        <div class="form-group">
                            <label for="titulo" class="col-form-label">Campus:</label>
                            <select class="form-control" id="edit_campus" name="edit_campus" required>
                                <?php
                                    $sql_titulo = "SELECT * FROM campus WHERE estado = 'Activo'";
                                    $result_titulo = $Conn->query($sql_titulo);
                                    if ($result_titulo->num_rows > 0) {
                                        while($row_titulo = $result_titulo->fetch_assoc()) {
                                            echo "<option value='".$row_titulo["campus"]."'>".$row_titulo["campus"]."</option>";
                                        }
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="cantidad" class="col-form-label">Fecha de Entrega:</label>
                            <input type="date" class="form-control" id="edit_fechaEntrega" name="edit_fechaEntrega" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-dark" >Guardar Cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- jQuery, Popper.js, Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>

    <!-- datatables JS -->
    <script src="https://cdn.datatables.net/2.0.2/js/dataTables.js"></script>
    

    <!-- JavaScript para abrir el modal al hacer clic en Nuevo y las validaciones de campos vacíos -->
    <script>
        $(document).ready(function() {
            $('#btnNuevo').click(function() {
                $('#modalCRUD').modal('show');
            });

            var tablaMob = $("#tablaMob").DataTable({
                "columnDefs": [{
                    "data": null,
                }],

                "language": {
                    "lengthMenu": "Mostrar _MENU_ registros",
                    "zeroRecords": "No se encontraron resultados",
                    "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                    "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
                    "infoFiltered": "(filtrado de un total de _MAX_ registros)",
                    "sSearch": "Buscar:",
                    "oPaginate": {
                        "sFirst": "Primero",
                        "sLast": "Último",
                        "sNext": "Siguiente",
                        "sPrevious": "Anterior"
                    },
                    "sProcessing": "Procesando...",
                }
            });

            $('#tablaMob tbody').on('click', 'button.btnBorrar', function() {
                var idEntrega = $(this).attr('data-id');
                if (confirm("¿Estás seguro de que deseas borrar este registro?")) {
                    $.ajax({
                        url: '../php/del_Entregas.php',
                        method: 'POST',
                        data: {
                            idEntrega: idEntrega
                        },
                        success: function(response) {
                          
                            location.reload();
                        },
                        error: function(xhr, status, error) {
                            console.error(xhr.responseText);
                        }
                    });
                }
            });

            $("#btnNuevo").click(function() {
                $("#formPersonas").trigger("reset");
                $(".modal-header").css("background-color", "#004e18");
                $(".modal-header").css("color", "white");
                $(".modal-title").text("Registro");
                $("#modalCRUD").modal("show");
                id = null;
                opcion = 1;
            });

            $('#tablaMob tbody').on('click', 'button.btnEditar', function() {
                var idEntrega = $(this).attr('data-id');
                $.ajax({
                    url: '../php/obt_entrega.php',
                    method: 'POST',
                    data: {
                        idEntrega: idEntrega
                    },
                    dataType: 'json',
                    success: function(response) {

                        $('#edit_idEntrega').val(response.idEntrega);
                        $('#edit_titulo').val(response.idLibrosAsignatura);
                        $('#edit_alumno').val(response.alumno);
                        $('#edit_cuenta').val(response.cuenta);
                        $('#edit_campus').val(response.campus);
                        

                       
                        var fechaEntr = new Date(response.fechaEntrega);

                        // Formatear las fechas en el formato de fecha necesario
                        var fechaFormateada = fechaEntr.toISOString().split('T')[0];
                       

                        // Asignar las fechas formateadas a los campos del formulario modal
                       
                        $('#edit_fechaEntrega').val(fechaFormateada);

                        $('#modalEditar').modal('show');
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });

    


            $('#formNuevoRegistro').submit(function(e) {
                e.preventDefault();
                var titulo = $('#titulo').val().trim();
                var alumno = $('#alumno').val().trim();
                var cantidad = $('#cantidad').val().trim();
                var cuenta = $('#cuenta').val().trim();

                if (titulo === '' || alumno === '' || cantidad === '' || cuenta === '' ) {
                    alert('Por favor, complete todos los campos.');
                    return;
                }
                $(this).unbind('submit').submit();
            });

           

            (function() {
            'use strict';
            window.addEventListener('load', function() {
                var forms = document.getElementsByClassName('needs-validation');
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');

                    }, false);

                });
            }, false);
        })();
            
        });

       
    </script>
</body>
</html>
