<?php
require('../php/connectionBD.php');
session_start();
$usuario = $_SESSION['username'];
if (!isset($usuario)) {
    header('Location: inicio.php');
}

//Realizo busqueda del titulo del ID
$User = $_SESSION['username'];
$SQL = "SELECT * from usuarios WHERE usuario= '$User'";
$RS = mysqli_query($Conn, $SQL);

if (mysqli_num_rows($RS) == 1) {
    while ($dat0 = mysqli_fetch_assoc($RS)) {
        $idUsuario = $dat0["idUsuario"];
        $usuario = $dat0["usuario"];
        $password = $dat0["password"];
        $nombre = $dat0["nombre"];
        $apellido = $dat0["apellido"];
        $idcampus = $dat0["idcampus"];
        $estado = $dat0["estado"];
        $fecha = $dat0["fecha"];
    }
}

$SQL1 = "SELECT campus from campus WHERE idCampus= '$idcampus'";
$RS1 = mysqli_query($Conn, $SQL1);
if (mysqli_num_rows($RS1) == 1) {
    while ($dat0 = mysqli_fetch_assoc($RS1)) {
        $campus = $dat0["campus"];
    }
}



?>
<!DOCTYPE html>
<html lang="es" dir="ltr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Mi Cuenta | Biblioteca</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/miCuenta.css">
    <!--datables CSS básico-->
    <link rel="stylesheet" href="https://cdn.datatables.net/2.0.2/css/dataTables.dataTables.min.css">
    <!--datables estilo bootstrap 5 CSS-->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="apple-touch-icon" sizes="180x180" href="../img/Icon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../img/Icon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../img/Icon/favicon-16x16.png">
    <link rel="manifest" href="../img/Icon/site.webmanifest">
</head>

<body style="background: black;">
    <div id="box">
        <form action="miCuenta.php" method="POST">

            <h1>Detalles de Cuenta</h1>
            <hr>
            <div>
                <label>Usuario</label><br>
                <?php echo "<input type='text' id=fus name=fus value='$usuario'>"; ?>
            </div>

            <div>
                <label>Nombre</label><br>
                <?php echo "<input type='text' id=fName  name=fName value='$nombre'>"; ?>
            </div>

            <div>
                <label>Apellido</label><br>
                <?php echo "<input type='text' id=fApe  name=fApe value='$apellido'>"; ?>
            </div>
            <hr>


            <div>
                <?php echo "<input type='hidden' id=idcamp value='$idcampus'>"; ?>
                <label>Asignado a Campus</label><br>
                <?php echo "<input type='text' readonly value='$campus'>"; ?>
            </div>

            <div>
                <label>Fecha de Creacion</label><br>
                <?php echo "<input type='text' readonly value='$fecha'>"; ?>
            </div>
            <hr>

            <div>
                <label>Cambio de Contraseña</label><br>
                <input type="text" name="contra" id="contra" value="">
            </div>

            <div>
                <hr>
                <input id="Cambio" class="bt" type="submit" name="Cambio" value="Guardar Cambios">
                <button type="button" class="bt" onclick="goToInicio()">Cerrar</button>
            </div>
        </form>
    </div>

    <script>
        function goToInicio() {
            window.location.href = "index.php";
        }
    </script>
    <!-- jQuery, Popper.js, Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
</body>

</html>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $pwd = $_POST['contra'];
    $fus = $_POST['fus'];
    $fname = $_POST['fName'];
    $fape = $_POST['fApe'];

    if (empty($pwd)) {
        echo "<script>alert('Campo contraseña vacia');</script>";
    } else {
        // Actualiza la contraseña en la base de datos
        $SQL = "UPDATE usuarios SET usuario='$fus', nombre='$fname', apellido='$fape', password='$pwd' WHERE idUsuario= '$idUsuario'";

        if ($Conn->query($SQL) === TRUE) {
            $_SESSION['username'] = '';
            $_SESSION['password'] = '';
            echo "<script>alert('Cambios realizados! Iniciar sesion nuevamente');</script>";
            echo "<script>window.location.href='../php/logout.php' </script>";
        } else {
            echo "Error al actualizar la contraseña: " . $Conn->error;
        }
        $Conn->close();
    }
}
?>