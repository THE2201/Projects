<?php
require('../php/connectionBD.php');
session_start();
$usuario = $_SESSION['username'];
if (!isset($usuario)) {
    header('Location: inicio.php');
}

$sql = "SELECT u.idUsuario, u.usuario, u.password, r.nombre AS nombreRol, u.nombre, u.apellido, c.campus AS nombreCampus, u.estado, u.fecha
        FROM usuarios u
        LEFT JOIN rol r ON u.idRol = r.idrol
        LEFT JOIN campus c ON u.idcampus = c.idcampus
        WHERE u.estado = 'Activo'";
$result = $Conn->query($sql);


?>

<!DOCTYPE html>
<html lang="es" dir="ltr">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="#" />
    <title>Roles | Biblioteca</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <!--datables CSS básico-->
    <link rel="stylesheet" href="https://cdn.datatables.net/2.0.2/css/dataTables.dataTables.min.css">
    <!--datables estilo bootstrap 5 CSS-->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/2.0.2/css/dataTables.bootstrap5.css">
</head>

<body>
    <header>
        <h4 class="text-center p-3 mb-2 bg-success text-white">Usuarios</h4>
    </header>

    <div class="container">
        <div class="row"></div>
        <div class="col-lg-12">
            <button id="btnNuevo" type="button" class="btn btn-success" data-toggle="modal" data-target="#modalCRUD">Nuevo</button>
        </div>
    </div>
    </div>
    <br>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table id="tablaMob" class="table table-striped table-bordered table-condensed" style="width:100%">
                        <thead class="text-center">
                            <tr>
                                <th>ID</th>
                                <th>Usuario</th>
                                <th>Rol</th>
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th>Campus</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo "<tr>";
                                    echo "<td>" . $row["idUsuario"] . "</td>";
                                    echo "<td>" . $row["usuario"] . "</td>";
                                    echo "<td>" . $row["nombreRol"] . "</td>"; // Mostrar el nombre del rol
                                    echo "<td>" . $row["nombre"] . "</td>";
                                    echo "<td>" . $row["apellido"] . "</td>";
                                    echo "<td>" . $row["nombreCampus"] . "</td>"; // Mostrar el nombre del campus
                                    echo "<td><button class='btn btn-primary btnEditar' data-id='" . $row["idUsuario"] . "'>Editar</button><button class='btn btn-danger btnBorrar' data-id='" . $row["idUsuario"] . "'>Borrar</button><button class='btn btn-primary btnReset' data-id='" . $row["idUsuario"] . "'>Restablecer</button></td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='7'>No se encontraron registros</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!--Modal para CRUD-->
    <div class="modal fade" id="modalCRUD" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Nuevo Registro</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="formNuevoRegistro" method="POST" action="../php/ins_usuario.php" class="needs-validation" novalidate>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="nombre" class="col-form-label">Usuarios</label>
                            <input type="text" class="form-control" id="usuarios" name="usuarios" required oninput="this.value = this.value.toUpperCase()">
                            <div class="invalid-feedback">
                                Por favor, ingresa un valor para el usuario.
                            </div>
                        </div>



                        <div class="form-group">
                            <label for="rol" class="col-form-label">Rol:</label>
                            <select class="form-control" id="rol" name="rol" required>
                                <option value="">Seleccione un rol</option>
                                <?php
                                $sql = mysqli_query($Conn, "SELECT nombre FROM rol WHERE estado ='Activo'");
                                while ($row = mysqli_fetch_array($sql)) {
                                    echo '<option value="' . $row["nombre"] . '">' . $row["nombre"] . '</option>';
                                }
                                ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="nombre" class="col-form-label">Nombre</label>
                            <input type="text" class="form-control" id="nombre" name="nombre" required>
                            <div class="invalid-feedback">
                                Por favor, ingresa un valor para el nombre.
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="apellido" class="col-form-label">Apellido</label>
                            <input type="text" class="form-control" id="apellido" name="apellido" required>
                            <div class="invalid-feedback">
                                Por favor, ingresa un valor para el apellido.
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="campus" class="col-form-label">Campus:</label>
                            <select class="form-control" id="campus" name="campus" required>
                                <option value="">Seleccione un campus</option>
                                <?php
                                $sql = mysqli_query($Conn, "SELECT campus FROM campus WHERE estado ='Activo' ");
                                while ($row = mysqli_fetch_array($sql)) {
                                    echo '<option value="' . $row["campus"] . '">' . $row["campus"] . '</option>';
                                }
                                ?>
                            </select>
                        </div>



                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-dark" id="guardar" name="guardar">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal para editar registros -->
    <div class="modal fade" id="modalEditar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Editar Registro</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="formEditarRegistro" method="POST" action="../php/upd_usuario.php" class="needs-validation" novalidate>
                    <div class="modal-body">
                        <input type="hidden" id="edit_idUsuario" name="edit_idUsuario">
                        <div class="form-group">
                            <label for="nombre" class="col-form-label">Usuarios</label>
                            <input type="text" class="form-control" id="edit_usuario" name="edit_usuario" required oninput="this.value = this.value.toUpperCase()">
                            <div class="invalid-feedback">
                                Por favor, ingresa un valor para el usuario.
                            </div>
                        </div>



                        <div class="form-group">
                            <label for="rol" class="col-form-label">Rol:</label>
                            <select class="form-control" id="edit_rol" name="edit_rol" required>
                                <option value="">Seleccione un rol</option>
                                <?php
                                $sql = mysqli_query($Conn, "SELECT nombre FROM rol WHERE estado ='Activo'");
                                while ($row = mysqli_fetch_array($sql)) {
                                    echo '<option value="' . $row["nombre"] . '">' . $row["nombre"] . '</option>';
                                }
                                ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="nombre" class="col-form-label">Nombre</label>
                            <input type="text" class="form-control" id="edit_nombre" name="edit_nombre" required>
                            <div class="invalid-feedback">
                                Por favor, ingresa un valor para el nombre.
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="apellido" class="col-form-label">Apellido</label>
                            <input type="text" class="form-control" id="edit_apellido" name="edit_apellido" required>
                            <div class="invalid-feedback">
                                Por favor, ingresa un valor para el apellido.
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="campus" class="col-form-label">Campus:</label>
                            <select class="form-control" id="edit_campus" name="edit_campus" required>
                                <option name="edit_campus" value="">Seleccione un campus</option>
                                <?php
                                $sql = mysqli_query($Conn, "SELECT campus FROM campus WHERE estado ='Activo' ");
                                while ($row = mysqli_fetch_array($sql)) {
                                    echo '<option value="' . $row["campus"] . '">' . $row["campus"] . '</option>';
                                }
                                ?>
                            </select>
                        </div>



                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-dark" id="btnGuardarCambios" name="guardarcam">Guardar Cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>



    <!-- jQuery, Popper.js, Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>

    <!-- datatables JS -->
    <script src="https://cdn.datatables.net/2.0.2/js/dataTables.js"></script>
    <script type="text/javascript" src="../js/scriptLibros.js"></script>

    <!-- JavaScript para abrir el modal al hacer clic en Nuevo -->
    <script>
        $(document).ready(function() {
            $('#btnNuevo').click(function() {
                $('#modalCRUD').modal('show');
            });

            $('#btnEditar').click(function() {
                $('#modalCRUD').modal('show');
            });

            var tablaMob = $("#tablaMob").DataTable({
                "columnDefs": [{
                    "data": null,

                }],

                "language": {
                    "lengthMenu": "Mostrar _MENU_ registros",
                    "zeroRecords": "No se encontraron resultados",
                    "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                    "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
                    "infoFiltered": "(filtrado de un total de _MAX_ registros)",
                    "sSearch": "Buscar:",
                    "oPaginate": {
                        "sFirst": "Primero",
                        "sLast": "Último",
                        "sNext": "Siguiente",
                        "sPrevious": "Anterior"
                    },
                    "sProcessing": "Procesando...",
                }
            });

            $('#tablaMob tbody').on('click', 'button.btnBorrar', function() {
                var idUsuario = $(this).attr('data-id');
                if (confirm("¿Estás seguro de que deseas borrar este registro?")) {
                    $.ajax({
                        url: '../php/del_usuarios.php',
                        method: 'POST',
                        data: {
                            idUsuario: idUsuario
                        },
                        success: function(response) {
                            alert(response);

                            location.reload();
                        },
                        error: function(xhr, status, error) {
                            console.error(xhr.responseText);
                        }
                    });
                }
            });

            $('#tablaMob tbody').on('click', 'button.btnReset', function() {
                var idUsuario = $(this).attr('data-id');
                if (confirm("Confirme para restablecer su contraseña")) {
                    $.ajax({
                        url: '../php/ret_usuarios.php',
                        method: 'POST',
                        data: {
                            idUsuario: idUsuario
                        },
                        success: function(response) {
                            alert(response);

                            location.reload();
                        },
                        error: function(xhr, status, error) {
                            console.error(xhr.responseText);
                        }
                    });
                }
            });

            $("#btnNuevo").click(function() {
                $("#formPersonas").trigger("reset");
                $(".modal-header").css("background-color", "#004e18");
                $(".modal-header").css("color", "white");
                $(".modal-title").text("Registro");
                $("#modalCRUD").modal("show");
                id = null;
                opcion = 1;
            });

            $('#tablaMob tbody').on('click', 'button.btnEditar', function() {
                var idUsuario = $(this).attr('data-id');

                $.ajax({
                    url: '../php/obt_usuario.php',
                    method: 'POST',
                    data: {
                        idUsuario: idUsuario
                    },
                    dataType: 'json',
                    success: function(response) {

                        $('#edit_idUsuario').val(response.idUsuario);
                        $('#edit_usuario').val(response.usuario);
                        $('#edit_rol').val(response.rol);
                        $('#edit_nombre').val(response.nombre);
                        $('#edit_apellido').val(response.apellido);
                        $('#edit_campus').val(response.campus);



                        $('#modalEditar').modal('show');
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });

            $('#formEditarRegistro').submit(function(e) {
                e.preventDefault();
                var form = this;

                if (form.checkValidity() === false) {
                    e.stopPropagation(); // Detener la propagación del evento para evitar que se muestre la validación predeterminada del navegador
                    form.classList.add('was-validated'); // Marcar los campos inválidos
                    return;
                }

                $.ajax({
                    url: $(this).attr('action'),
                    method: $(this).attr('method'),
                    data: $(this).serialize(),
                    success: function(response) {
                        alert(response);
                        $('#modalEditar').modal('hide');
                        location.reload();
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });
        });






        //Validacion 

        (function() {
            'use strict';
            window.addEventListener('load', function() {
                var forms = document.getElementsByClassName('needs-validation');
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault(); // Detiene el envío del formulario si la validación falla
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();
    </script>
</body>

</html>