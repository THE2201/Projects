<?php
require('../php/connectionBD.php');
session_start();
$usuario = $_SESSION['username'];
if (!isset($usuario)) {
    header('Location: inicio.php');
}

$sql = "SELECT solicitudes.*, solicitudes.idSolicitud, campus.Campus AS nombre_campus, CONCAT(usuarios.nombre, ' ', usuarios.apellido) AS nombre_usuario
        FROM solicitudes 
        INNER JOIN campus ON solicitudes.idCampus = campus.idCampus
        INNER JOIN usuarios ON solicitudes.idUsuario = usuarios.idUsuario
        WHERE solicitudes.estado = 'Activo'";
$result = $Conn->query($sql);

function obtenerOp($campo, $campo2, $tabla)
{
    $options = '';
    global $Conn;

    if (!$Conn) {
        die("Error de conexión: " . $Conn);
    }

    $sql = "SELECT $campo, $campo2 FROM $tabla";
    $result = $Conn->query($sql);

    if ($result === false) {
        die("Error al recuperar los datos de $tabla");
    }
    foreach ($result as $row) {
        $options .= '<option value="' . $row[$campo] . '">' . $row[$campo] . ' - ' . $row[$campo2] . '</option>';
    }
    return $options;
}
$userOp = obtenerOp('idUsuario', 'usuario', 'usuarios');

$sqlPermisos = "SELECT p.editar, p.eliminar, P.agregar
                FROM usuarios u
                INNER JOIN rol r ON u.idRol = r.idRol
                INNER JOIN permisos p ON r.idPermiso = p.idPermiso
                WHERE u.usuario = '$usuario'";
$resultPermisos = $Conn->query($sqlPermisos);

if ($resultPermisos->num_rows > 0) {
    // Obtener los permisos del usuario
    $permisos = $resultPermisos->fetch_assoc();
} else {
    // Si no se encontraron permisos, se pueden establecer valores predeterminados o manejar el error según sea necesario
    // Por ejemplo, puedes asignar valores predeterminados para los permisos o mostrar un mensaje de error
    $permisos = array('editar' => 0, 'eliminar' => 0); // Valores predeterminados
    echo "No se encontraron permisos para el usuario.";
}


?>
<!DOCTYPE html>
<html lang="es" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="#" />
    <title>Solicitudes | Biblioteca</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!--datables CSS básico-->
    <link rel="stylesheet" href="https://cdn.datatables.net/2.0.2/css/dataTables.dataTables.min.css">
    <!--datables estilo bootstrap 5 CSS-->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/2.0.2/css/dataTables.bootstrap5.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/css/bootstrap-select.min.css">
    <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet">
</head>

<body>
    <header>
        <h4 class="text-center p-3 mb-2 bg-success text-white">Solicitudes</h4>
    </header>
    <div class="container">
        <div class="row"></div>
        <div class="col-lg-12">
            <?php
            if ($permisos['agregar'] == 1) {
                echo '<button id="btnNuevo" type="button" class="btn btn-success" data-toggle="modal" data-target="#modalCRUD">Nuevo</button>';
            } else {
                echo "<td></td>"; // Espacio vacío si no tiene permisos
            }
            ?>
        </div>
    </div>
    </div>
    <br>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table id="tablaSolicitudes" class="table table-striped table-bordered table-condensed" style="width:100%">
                        <thead class="text-center">
                            <tr>
                                <th>ID</th>
                                <th>Usuario</th>
                                <th>Campus</th>
                                <th>Descripción</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo "<tr>";
                                    echo "<td>" . $row["idSolicitud"] . "</td>";
                                    echo "<td>" . $row["nombre_usuario"] . "</td>";
                                    echo "<td>" . $row["nombre_campus"] . "</td>";
                                    echo "<td>" . $row["descripcion"] . "</td>";
                                    echo "<td>";

                                    if ($permisos['editar'] == 1 && $permisos['eliminar'] == 1) {
                                        echo "<button class='btn btn-primary btnEditar' data-id='" . $row["idSolicitud"] . "'>Editar</button>";
                                        echo "<button class='btn btn-danger btnBorrar' data-id='" . $row["idSolicitud"] . "'>Borrar</button>";
                                    } elseif ($permisos['editar'] == 1) {
                                        echo "<button class='btn btn-primary btnEditar' data-id='" . $row["idSolicitud"] . "'>Editar</button>";
                                    } elseif ($permisos['eliminar'] == 1) {
                                        echo "<button class='btn btn-danger btnBorrar' data-id='" . $row["idSolicitud"] . "'>Borrar</button>";
                                    } else {
                                        echo "</td>"; // Espacio vacío si no tiene permisos
                                    }

                                    echo "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='7'>No se encontraron registros</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!--Modal para CRUD-->
    <div class="modal fade" id="modalCRUD" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Nuevo Registro</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="formNuevoRegistro" method="POST" action="../php/ins_Solicitud.php" onsubmit="return validaCampos('1');">
                    <div class="modal-body">
                        <input type="hidden" id="idcampus" name="idcampus">
                        <div class="form-group">
                            <label for="usuario" class="col-form-label">Usuario:</label>
                            <br>
                            <select class="selectpicker" data-style="btn-success" id="usuario" name="usuario">
                                <option value="default" selected>Seleccione una opción</option>
                                <?php echo $userOp; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="descripcion" class="col-form-label">Descripción:</label>
                            <input type="text" class="form-control" id="descripcion" name="descripcion">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal" onclick="limpiar()">Cancelar</button>
                        <button type="submit" class="btn btn-dark">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!--Modal para CRUD-->
    <div class="modal fade" id="modalEditar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Editar Registro</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="formEditarRegistro" method="POST" action="../php/upd_Solicitud.php">
                    <div class="modal-body">
                        <input type="hidden" id="edit_idSolicitud" name="edit_idSolicitud">
                        <input type="hidden" id="edit_idcampus" name="edit_idcampus">
                        <div class="form-group">
                            <label for="usuario" class="col-form-label">Usuario:</label>
                            <br>
                            <select class="selectpicker" data-style="btn-success" id="edit_usuario" name="edit_usuario">
                                <option value="default" selected>Seleccione una opción</option>
                                <?php echo $userOp; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="descripcion" class="col-form-label">Descripción:</label>
                            <input type="text" class="form-control" id="edit_descripcion" name="edit_descripcion">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-dark">Editar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- jQuery, Popper.js, Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/js/bootstrap-select.min.js"></script>
    <!-- datatables JS -->

    <script src="https://cdn.datatables.net/2.0.2/js/dataTables.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <!-- JavaScript para abrir el modal al hacer clic en Nuevo -->
    <script>
        $(document).ready(function() {
            $('#btnNuevo').click(function() {
                $('#modalCRUD').modal('show');
            });

            var tablaSolicitudes = $("#tablaSolicitudes").DataTable({
                "columnDefs": [{
                    "data": null,

                }],

                "language": {
                    "lengthMenu": "Mostrar _MENU_ registros",
                    "zeroRecords": "No se encontraron resultados",
                    "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                    "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
                    "infoFiltered": "(filtrado de un total de _MAX_ registros)",
                    "sSearch": "Buscar:",
                    "oPaginate": {
                        "sFirst": "Primero",
                        "sLast": "Último",
                        "sNext": "Siguiente",
                        "sPrevious": "Anterior"
                    },
                    "sProcessing": "Procesando...",
                }
            });

            $('#tablaSolicitudes tbody').on('click', 'button.btnBorrar', function() {
                var idSolicitud = $(this).attr('data-id');
                if (confirm("¿Estás seguro de que deseas borrar este registro?")) {
                    $.ajax({
                        url: '../php/del_Solicitud.php',
                        method: 'POST',
                        data: {
                            idSolicitud: idSolicitud
                        },
                        success: function(response) {
                            alert(response);
                            location.reload();
                        },
                        error: function(xhr, status, error) {
                            console.error(xhr.responseText);
                        }
                    });
                }
            });

            $("#btnNuevo").click(function() {
                $("#formPersonas").trigger("reset");
                $(".modal-header").css("background-color", "#004e18");
                $(".modal-header").css("color", "white");
                $(".modal-title").text("Registro");
                $("#modalCRUD").modal("show");
                id = null;
                opcion = 1;
            });

            $('#tablaSolicitudes tbody').on('click', 'button.btnEditar', function() {
                var idSolicitud = $(this).attr('data-id');

                $.ajax({
                    url: '../php/obt_Solicitud.php',
                    method: 'POST',
                    data: {
                        idSolicitud: idSolicitud
                    },
                    dataType: 'json',
                    success: function(response) {
                        $('#edit_idSolicitud').val(response.idSolicitud);
                        $('#edit_idcampus').val(response.idcampus);
                        $('#edit_usuario').val(response.usuario);
                        $('#edit_descripcion').val(response.descripcion);
                        $('#modalEditar').modal('show');
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });

            $('#formEditarRegistro').submit(function(e) {
                e.preventDefault();

                if (!validaCampos(2)) {
                    return;
                }

                $.ajax({
                    url: $(this).attr('action'),
                    method: $(this).attr('method'),
                    data: $(this).serialize(),
                    success: function(response) {
                        alert(response);
                        $('#modalEditar').modal('hide');
                        location.reload();
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });

        });
    </script>
    <script>
        var usuario, descripcion;

        function validaCampos(indice) {
            if (indice == 1) {
                usuario = $("#usuario").val();
                descripcion = $("#descripcion").val();
            }

            if (indice == 2) {
                usuario = $("#edit_usuario").val();
                descripcion = $("#edit_descripcion").val();

            }

            if ($.trim(usuario) == "") {
                toastr.error("No ha seleccionado un usuario", "Aviso");
                return false;
            }
            if ($.trim(descripcion) == "") {
                toastr.error("No ha ingresado una descripción", "Aviso");
                return false;
            }
            return true;
        }
    </script>

    <script>
        function limpiar() {
            var usuario = document.getElementById('usuario');
            var descripcion = document.getElementById('descripcion');

            usuario.value = 'Seleccione una opción';
            descripcion.value = '';
            location.reload();
        }
    </script>
</body>

</html>