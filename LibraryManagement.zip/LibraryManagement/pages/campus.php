<?php
require('../php/connectionBD.php');
session_start();
$usuario = $_SESSION['username'];
if (!isset($usuario)) {
    header('Location: inicio.php');
  }
?>
<!DOCTYPE html>
<html lang="es" dir="ltr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="#" />
    <title>Campus | Biblioteca</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <!--datables CSS básico-->
    <link rel="stylesheet" href="https://cdn.datatables.net/2.0.2/css/dataTables.dataTables.min.css">
    <!--datables estilo bootstrap 5 CSS-->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/2.0.2/css/dataTables.bootstrap5.css">
  </head>
<body>
    <header>
        <h4 class="text-center p-3 mb-2 bg-success text-white">Campus</h4>
    </header>

    <div class="container">
        <div class="row"></div>
        <div class="col-lg-12">
            <button id="btnNuevo" type="button" class="btn btn-success" data-toggle="modal">Nuevo</button>
        </div>

    </div>
    </div>
    <br>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table id="tablaLibros" class="table table-striped table-bordered table-condensed" style="width:100%">
                        <thead class="text-center">
                            <tr>
                                <th>ID</th>
                                <th>Campus</th>
                                <th>Direccion</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <?php
// Crear una instancia de la clase Conexiong y conectarse a la base de datos
$connection = Conexiong::Conectarg();

$query = "SELECT idCampus, campus, direccion FROM campus WHERE estado != 'Inactivo'";
// Preparar la consulta SQL
$stmt = $connection->prepare($query);
// Ejecutar la consulta
$stmt->execute();
// Obtener los resultados
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($result) > 0) {
    foreach ($result as $row) {
        echo "<tr>";
        echo "<td>" . $row['idCampus'] . "</td>";
        echo "<td>" . $row['campus'] . "</td>";
        echo "<td>" . $row['direccion'] . "</td>";
        
        echo "<td>";
        echo "<button type='button' class='btn btn-info btnEditar' data-id='" . $row['idCampus'] . "' data-campus='" . $row['campus'] . "' data-direccion='" . $row['direccion'] . "'>Editar</button>     ";
        echo "<button type='button' class='btn btn-danger btnEliminar' data-id='" . $row['idCampus'] . "'>Eliminar</button>";
        echo "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='4'>0 resultados</td></tr>";
}

// Cerrar la conexión
$connection = null;
?>




                        <tbody>
                            <!-- <?php
                                    //foreach($data as $dat) {
                                    //
                                    ?> -->
                            <!-- <tr>
                                <td><?php echo $dat['id'] ?></td>
                                <td><?php echo $dat['local'] ?></td>
                                <td><?php echo $dat['genero'] ?></td>
                                <td><?php echo $dat['titulo'] ?></td>
                                <td><?php echo $dat['autor'] ?></td>
                                <td><?php echo $dat['editorial'] ?></td>
                                <td><?php echo $dat['idioma'] ?></td>
                                <td><?php echo $dat['cantidad'] ?></td>
                                                             
                                <td></td>
                            </tr>
                            //<?php
                                // }
                                ?>-->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<!-- Modal para editar datos -->
<div class="modal fade" id="modalEditar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Editar datos de campus</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="idCampus">
                <div class="mb-3">
                    <label for="editarCampus" class="form-label">Campus</label>
                    <input type="text" class="form-control" id="editarCampus">
                </div>
                <div class="mb-3">
                    <label for="editarDireccion" class="form-label">Dirección</label>
                    <input type="text" class="form-control" id="editarDireccion">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" id="btnGuardarCambios">Guardar cambios</button>
            </div>
        </div>
    </div>
</div>


 <!--Modal para CRUD-->
 <div class="modal fade" id="modalCRUD" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"></h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <form id="formNuevoCampus">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="local" class="col-form-label">Campus:</label>
                        <input type="text" class="form-control" id="local">
                    </div>
                    <div class="form-group">
                        <label for="genero" class="col-form-label">Direccion:</label>
                        <input type="text" class="form-control" id="genero">
                    </div>
                    <div class="form-group">
                        <label for="estado" class="col-form-label">Estado:</label>
                        <select class="form-control" id="estado">
                            <option value="Activo">Activo</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" id="btnGuardar" class="btn btn-dark">Guardar</button>
                </div>
            </form>
        </div>
    </div>
</div>



   
    <!-- jQuery, Popper.js, Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>

    <!-- datatables JS -->



    <script src="https://cdn.datatables.net/2.0.2/js/dataTables.js"></script>


    <script>

  $(document).ready(function() {
        // Mostrar el modal CRUD al hacer clic en el botón "Nuevo"
        $("#btnNuevo").click(function() {
            // Limpiar los campos del modal
            $("#local").val("");
            $("#genero").val("");

            // Cambiar el título del modal según la acción (Agregar nuevo campus)
            $(".modal-title").text("Agregar nuevo campus");

            // Mostrar el modal
            $("#modalCRUD").modal("show");
        });
    });


    $(document).ready(function() {
    // Escuchar el evento submit del formulario dentro del modal
    $("#formNuevoCampus").submit(function(event) {
        // Evitar que se recargue la página al enviar el formulario
        event.preventDefault();

        // Obtener los valores ingresados por el usuario
        var campus = $("#local").val();
        var direccion = $("#genero").val();
        var estado = $("#estado").val(); // Obtener el valor seleccionado del combobox "Estado"

        // Realizar la solicitud AJAX para guardar los datos en la base de datos
        $.ajax({
            type: "POST",
            url: "../php/guardarcampus.php", // Ruta de tu script PHP para guardar los datos en la base de datos
            data: {
                campus: campus,
                direccion: direccion,
                estado: estado // Incluir el valor de "Estado" en los datos enviados
            },
            success: function(response) {
                // Mostrar mensaje de éxito o error
                alert(response);

                // Cerrar el modal después de guardar los datos
                $("#modalCRUD").modal("hide");

                // Actualizar la página u otra acción necesaria
                location.reload();
            },
            error: function(xhr, status, error) {
                // Manejar errores de la solicitud AJAX
                console.error(xhr.responseText);
                alert("Error al guardar los datos. Por favor, inténtalo de nuevo.");
            }
        });
    });
});


$(document).ready(function() {
    // Función para editar datos
    $(document).on("click", ".btnEditar", function() {
        // Obtener los datos de la fila seleccionada
        var idCampus = $(this).data('id');
        var campus = $(this).data('campus');
        var direccion = $(this).data('direccion');
        var estado = $(this).data('estado'); // Obtener el estado actual del campus

        // Mostrar los datos en el formulario de edición
        $("#idCampus").val(idCampus);
        $("#editarCampus").val(campus);
        $("#editarDireccion").val(direccion);
        
        // Seleccionar la opción correspondiente en el campo de estado del formulario
        $("#editarEstado").val(estado);

        // Mostrar el modal de edición
        $("#modalEditar").modal("show");
    });

    // Función para guardar cambios
    $("#btnGuardarCambios").click(function() {
        // Obtener los nuevos valores del formulario
        var idCampus = $("#idCampus").val();
        var nuevoCampus = $("#editarCampus").val();
        var nuevaDireccion = $("#editarDireccion").val();
        var nuevoEstado = $("#editarEstado").val();

        // Verificar si se ha seleccionado un estado
        if (nuevoEstado === null || nuevoEstado === "") {
            alert("Por favor, seleccione un estado.");
            return; // Detener la ejecución si no se ha seleccionado un estado
        }

        // Realizar la solicitud AJAX para actualizar los datos
        $.ajax({
            type: "POST",
            url: "../php/actualizarcampus.php",
            data: {
                idCampus: idCampus,
                nuevoCampus: nuevoCampus,
                nuevaDireccion: nuevaDireccion,
                nuevoEstado: nuevoEstado
            },
            success: function(response) {
                // Actualizar la página o cualquier otra acción que desees realizar después de guardar los cambios
                alert(response); // Mostrar mensaje de éxito o error
                location.reload();
            },
            error: function(xhr, status, error) {
                // Manejar errores de la solicitud AJAX
                console.error(xhr.responseText);
                alert("Error al guardar los cambios. Por favor, inténtalo de nuevo.");
            }
        });
    });
});



            $(document).on("click", ".btnEliminar", function() {
            // Obtener el ID del campus a eliminar
            var idCampus = $(this).data('id');

            // Mostrar mensaje de confirmación antes de eliminar
            if (confirm("¿Estás seguro de eliminar este campus?")) {
                // Realizar la solicitud AJAX para eliminar los datos
                $.ajax({
                    type: "POST",
                    url: "../php/eliminarcampus.php", // Cambiar a la ruta de tu script PHP para eliminar datos en la base de datos
                    data: {
                        idCampus: idCampus
                    },
                    success: function(response) {
                        // Actualizar la página o cualquier otra acción que desees realizar después de eliminar el campus
                        location.reload();
                    }
                });
            }
        });
    

    </script>

</body>

</html>
