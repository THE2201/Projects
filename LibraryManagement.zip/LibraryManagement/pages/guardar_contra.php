<?php
session_start();
require('../php/connectionBD.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['newPassword'])) {
    // Obtén la nueva contraseña del formulario
    $newPassword = $_POST['newPassword'];

    // Obtén el nombre de usuario de la sesión
    $username = $_SESSION['username'];

    // Actualiza la contraseña en la base de datos
    $updateSQL = "UPDATE usuarios SET password = '$newPassword' WHERE usuario = '$username'";
    if ($Conn->query($updateSQL) === TRUE) {
        // La contraseña se actualizó correctamente
        echo "La contraseña se actualizó correctamente";
        header("Location: ../pages/inicio.php");
    } else {
        // Error al actualizar la contraseña
        echo "Error al actualizar la contraseña: " . $Conn->error;
    }
    $Conn->close();
}
?>