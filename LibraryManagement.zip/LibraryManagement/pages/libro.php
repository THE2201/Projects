<?php
require('../php/connectionBD.php');
session_start();
$usuario = $_SESSION['username'];

if (!isset($usuario)) {
    header('Location: inicio.php');
  }

$sqlPermisos = "SELECT p.editar, p.eliminar, P.agregar
                FROM usuarios u
                INNER JOIN rol r ON u.idRol = r.idRol
                INNER JOIN permisos p ON r.idPermiso = p.idPermiso
                WHERE u.usuario = '$usuario'";
$resultPermisos = $Conn->query($sqlPermisos);

if ($resultPermisos->num_rows > 0) {
    // Obtener los permisos del usuario
    $permisos = $resultPermisos->fetch_assoc();
} else {
    // Si no se encontraron permisos, se pueden establecer valores predeterminados o manejar el error según sea necesario
    // Por ejemplo, puedes asignar valores predeterminados para los permisos o mostrar un mensaje de error
    $permisos = array('editar' => 0, 'eliminar' => 0); // Valores predeterminados
    echo "No se encontraron permisos para el usuario.";
}

?>
<!DOCTYPE html>
<html lang="es" dir="ltr">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="#" />
    <title>Libros | Biblioteca</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <!--datables CSS básico-->
    <link rel="stylesheet" href="https://cdn.datatables.net/2.0.2/css/dataTables.dataTables.min.css">
    <!--datables estilo bootstrap 5 CSS-->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/css/bootstrap-select.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/2.0.2/css/dataTables.bootstrap5.css">
    <!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

</head>

<body>
    <header>

        <h4 class="text-center p-3 mb-2 bg-success text-white">Libros</h4>
    </header>

    <div class="container">
    <div class="col-lg-12">
        <?php
            if ($permisos['agregar'] == 1) {
                echo '<button id="btnNuevo" type="button" class="btn btn-success" data-toggle="modal" data-target="#modalCRUD">Nuevo</button><br><br>';
                $reporte_url = "reportes/reporte_libros.pdf";
                echo '<a href="../reportes/reporte_libros.php" target="_blank" class="btn btn-success">Ver Reporte</a>';
            } else {
                echo "<td></td>"; // Espacio vacío si no tiene permisos
            }
            ?>
        </div>
    </div>
    </div>
    <br>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table id="tablaLibros" class="table table-striped table-bordered table-condensed" style="width:100%">
                        <thead class="text-center">
                            <tr>
                                <th>ID</th>
                                <th>Campus</th>
                                <th>Sección</th>
                                <th>Genero</th>
                                <th>Titulo</th>
                                <th>Autor</th>
                                <th>Editorial</th>
                                <th>Idioma</th>
                                <th>Disponibles</th>
                                <th>Total</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <?php


// Crear una instancia de la clase Conexiong y conectarse a la base de datos
$connection = Conexiong::Conectarg();

$query = "SELECT libros.idLibros, libros.titulo, libros.autor, campus.campus AS nombre_campus, secciones.seccion AS nombre_seccion, generos.genero AS nombre_genero, editoriales.nombre AS nombre_editorial, libros.idioma, libros.disponible, libros.total
FROM libros
INNER JOIN campus ON libros.idCampus = campus.idCampus
INNER JOIN secciones ON libros.IdSeccion = secciones.idSeccion
INNER JOIN generos ON libros.IdGenero = generos.idGenero
INNER JOIN editoriales ON libros.ideditorial = editoriales.idEditorial
WHERE libros.estado = 'Activo';"; // Agregar esta condición para seleccionar solo los libros con estado activo

// Preparar la consulta SQL
$stmt = $connection->prepare($query);
// Ejecutar la consulta
$stmt->execute();
// Obtener los resultados
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($result) > 0) {
    foreach ($result as $row) {
        echo "<tr>";
        echo "<td>" . $row['idLibros'] . "</td>";
        echo "<td>" . $row['nombre_campus'] . "</td>";
        echo "<td>" . $row['nombre_seccion'] . "</td>";
        echo "<td>" . $row['nombre_genero'] . "</td>";
        echo "<td>" . $row['titulo'] . "</td>";
        echo "<td>" . $row['autor'] . "</td>";
        echo "<td>" . $row['nombre_editorial'] . "</td>";
        echo "<td>" . $row['idioma'] . "</td>";
        echo "<td>" . $row['disponible'] . "</td>";
        echo "<td>" . $row['total'] . "</td>";
        echo "<td>";
                                    
        if ($permisos['editar'] == 1 && $permisos['eliminar'] == 1) {
            echo "<button class='btn btn-primary btnEditar' data-id='".$row["idLibros"]."'>Editar</button>";
            echo "<button class='btn btn-danger btnBorrar' data-id='".$row["idLibros"]."'>Borrar</button>";
          echo "<button class='btn btn-success btnAgregar' data-id='".$row["idLibros"]."'>Agregar</button>";
        } elseif ($permisos['editar'] == 1 ) {
            echo "<button class='btn btn-primary btnEditar' data-id='".$row["idLibros"]."'>Editar</button>";
        } elseif ($permisos['eliminar'] == 1) {
            echo "<button class='btn btn-danger btnBorrar' data-id='".$row["idLibros"]."'>Borrar</button>";
        } else {
            echo "</td>"; // Espacio vacío si no tiene permisos
        }
        
        echo "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='4'>0 resultados</td></tr>";
}

// Consulta para obtener los campus desde la base de datos
$query_campus = "SELECT idCampus, campus FROM campus WHERE estado = 'Activo'";
$stmt_campus = $connection->prepare($query_campus);
$stmt_campus->execute();
$campus_data = $stmt_campus->fetchAll(PDO::FETCH_ASSOC);

// Consulta para obtener las secciones desde la base de datos
$query_seccion = "SELECT idSeccion, seccion FROM secciones WHERE estado = 'Activo'";
$stmt_seccion = $connection->prepare($query_seccion);
$stmt_seccion->execute();
$seccion_data = $stmt_seccion->fetchAll(PDO::FETCH_ASSOC);

// Consulta para obtener los géneros desde la base de datos
$query_genero = "SELECT idGenero, genero FROM generos WHERE estado = 'Activo'";
$stmt_genero = $connection->prepare($query_genero);
$stmt_genero->execute();
$genero_data = $stmt_genero->fetchAll(PDO::FETCH_ASSOC);

// Consulta para obtener las editoriales desde la base de datos
$query_editorial = "SELECT idEditorial, nombre FROM editoriales WHERE estado = 'Activo'";
$stmt_editorial = $connection->prepare($query_editorial);
$stmt_editorial->execute();
$editorial_data = $stmt_editorial->fetchAll(PDO::FETCH_ASSOC);

// Cerrar la conexión
$connection = null;
?>



<!-- SELECT * FROM libros WHERE estado = 'Activo'; -->

                        <tbody>
                            <!-- <?php
                                    //foreach($data as $dat) {
                                    //
                                    ?> -->
                            <!-- <tr>
                                <td><?php echo $dat['id'] ?></td>
                                <td><?php echo $dat['local'] ?></td>
                                <td><?php echo $dat['genero'] ?></td>
                                <td><?php echo $dat['titulo'] ?></td>
                                <td><?php echo $dat['autor'] ?></td>
                                <td><?php echo $dat['editorial'] ?></td>
                                <td><?php echo $dat['idioma'] ?></td>
                                <td><?php echo $dat['cantidad'] ?></td>
                                                             
                                <td></td>
                            </tr>
                            //<?php
                                // }
                                ?>-->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<!-- Modal para CRUD -->
<div class="modal fade" id="modalCRUD" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Agregar Libro</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="formLibros">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="campus" class="col-form-label">Campus:</label>
                        <select name="campus" id="campus" class="selectpicker form-control" data-style="btn-success">
                        <option value="">Seleccione un Campus</option>
                            <?php foreach ($campus_data as $campus) : ?>
                                <option value="<?php echo $campus['idCampus']; ?>"><?php echo $campus['campus']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="seccion" class="col-form-label">Seccion:</label>
                        <select name="seccion" id="seccion" class="form-control" >
                            <!-- Las opciones se cargarán dinámicamente mediante JavaScript -->
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="genero" class="col-form-label">Género:</label>
                        <select name="genero" id="genero" class="selectpicker form-control" data-style="btn-success">
                            <?php foreach ($genero_data as $genero) : ?>
                                <option value="<?php echo $genero['idGenero']; ?>"><?php echo $genero['genero']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="titulo" class="col-form-label">Título:</label>
                        <input type="text" class="form-control" id="titulo">
                    </div>
                    <div class="form-group">
                        <label for="autor" class="col-form-label">Autor:</label>
                        <input type="text" class="form-control" id="autor">
                    </div>
                    <div class="form-group">
                        <label for="editorial" class="col-form-label">Editorial:</label>
                        <select name="editorial" id="editorial" class="selectpicker form-control" data-style="btn-success">
                            <?php foreach ($editorial_data as $editorial) : ?>
                                <option value="<?php echo $editorial['idEditorial']; ?>"><?php echo $editorial['nombre']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="idioma" class="col-form-label">Idioma:</label>
                        <select name="idioma" id="idioma" class="selectpicker form-control" data-style="btn-success">
                            <option value="Espanol">Español</option>
                            <option value="Ingles">Inglés</option>
                            <option value="Frances">Francés</option>
                            <option value="Portugues">Portugués</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="cantidad" class="col-form-label">Cantidad:</label>
                        <input type="number" class="form-control" id="cantidad">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" id="btnGuardar" class="btn btn-dark">Guardar</button>
                </div>
            </form>
        </div>
    </div>
</div>


<!-- Modal para Editar -->
<div class="modal fade" id="modalEditar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Editar Libro</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="formEditarLibro">
                <div class="modal-body">
                    <!-- Aquí se mostrarán los campos para editar -->
                    <div class="form-group">
                        <label for="campus" class="col-form-label">Campus:</label>
                        <select name="edit_campus" id="edit_campus" class="form-control" data-style="btn-success">
                        <option value="">Seleccione un Campus</option>
                            <?php foreach ($campus_data as $campus) : ?>
                                <option value="<?php echo $campus['idCampus']; ?>"><?php echo $campus['campus']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="seccion" class="col-form-label">Seccion:</label>
                        <select name="edit_seccion" id="edit_seccion" class="form-control" >
                            <!-- Las opciones se cargarán dinámicamente mediante JavaScript -->
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="genero" class="col-form-label">Género:</label>
                        <select name="edit_genero" id="edit_genero" class="selectpicker form-control" data-style="btn-success">
                        <option value="">Seleccione un genero</option>
                        <?php
                                $sql=mysqli_query($Conn,"SELECT genero FROM generos WHERE estado ='Activo'");
                                while($row=mysqli_fetch_array($sql)){
                                    echo '<option value="' . $row["genero"] . '">' . $row["genero"] . '</option>';
                                }
                                ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="edit_titulo" class="col-form-label">Título:</label>
                        <input type="text" class="form-control" id="edit_titulo">
                    </div>
                    <div class="form-group">
                        <label for="edit_autor" class="col-form-label">Autor:</label>
                        <input type="text" class="form-control" id="edit_autor" name="edit_autor">
                    </div>
                    <div class="form-group">
                        <label for="editorial" class="col-form-label">Editorial:</label>
                        <select name="edit_editorial" id="edit_editorial" class="selectpicker form-control"  data-style="btn-success">
                            <?php foreach ($editorial_data as $editorial) : ?>
                                <option value="<?php echo $editorial['idEditorial']; ?>"><?php echo $editorial['nombre']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="edit_idioma" class="col-form-label">Idioma:</label>
                        <select name="edit_idioma" id="edit_idioma" class="selectpicker form-control" data-style="btn-success">
                            <option value="Espanol">Español</option>
                            <option value="Ingles">Inglés</option>
                            <option value="Frances">Francés</option>
                            <option value="Portugues">Portugués</option>
                        </select>
                    </div>
                    
                    <!-- Input oculto para guardar el ID del libro -->
                    <input type="hidden" id="edit_idLibro">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" id="btnGuardarEditar" class="btn btn-dark">Guardar Cambios</button>
                </div>
            </form>
        </div>
    </div>
</div>



<script>
$(document).ready(function () {
    tablaLibros = $("#tablaLibros").DataTable({
        // Configuración del DataTable
        "language": {
            "lengthMenu": "Mostrar _MENU_ registros",
            "zeroRecords": "No se encontraron resultados",
            "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
            "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
            "infoFiltered": "(filtrado de un total de _MAX_ registros)",
            "sSearch": "Buscar:",
            "oPaginate": {
                "sFirst": "Primero",
                "sLast": "Último",
                "sNext": "Siguiente",
                "sPrevious": "Anterior"
            },
            "sProcessing": "Procesando...",
        }
    });

    $("#btnNuevo").click(function () {
        // Código para manejar el clic en el botón de nuevo registro
        $("#formPersonas").trigger("reset");
        $(".modal-header").css("background-color", "#004e18");
        $(".modal-header").css("color", "white");
        $(".modal-title").text("Registro");
        $("#modalCRUD").modal("show");
        id = null;
        opcion = 1;
    });


    // Mostrar el modal de edición cuando se hace clic en el botón de editar
    $(document).on("click", ".btnEditar", function() {
        // Obtener los detalles del libro seleccionado
        var idLibro = $(this).closest("tr").find("td:first").text();
        var campus = $(this).closest("tr").find("td:nth-child(2)").text();
        var seccion = $(this).closest("tr").find("td:nth-child(3)").text();
        var genero = $(this).closest("tr").find("td:nth-child(4)").text();
        var titulo = $(this).closest("tr").find("td:nth-child(5)").text();
        var autor = $(this).closest("tr").find("td:nth-child(6)").text();
        var editorial = $(this).closest("tr").find("td:nth-child(7)").text();
        var idioma = $(this).closest("tr").find("td:nth-child(8)").text();
      
        
        // Asignar los detalles del libro al modal de edición
        $("#edit_idLibro").val(idLibro);
        $("#edit_campus").val(campus);
        $("#edit_seccion").val(seccion);
        $("#edit_genero").val(genero);
        $("#edit_titulo").val(titulo);
        $("#edit_autor").val(autor);
        $("#edit_editorial").val(editorial);
        $("#edit_idioma").val(idioma);
       
        
        // Mostrar el modal de edición
        $("#modalEditar").modal("show");
    });

    // Cargar opciones de campus cuando el modal de edición se muestra
    $('#modalEditar').on('shown.bs.modal', function () {
        $.ajax({
            url: '../php/get_campus.php',
            method: 'GET',
            success: function(response) {
                var campus = JSON.parse(response);
                $('#edit_campus').empty();
                $('#edit_campus').append('<option value="">Seleccione un campus</option>');
                $.each(campus, function(index, value) {
                    $('#edit_campus').append('<option value="' + value.idCampus + '">' + value.campus + '</option>');
                });
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
                alert("Error al cargar los campus. Por favor, inténtalo de nuevo.");
            }
        });
    });

    // Cargar opciones de sección según el campus seleccionado en el modal de edición
    $('#edit_campus').on('change', function() {
        var idCampus = $(this).val();
        $.ajax({
            url: '../php/get_secciones_por_campus.php',
            method: 'POST',
            data: { idCampus: idCampus },
            success: function(response) {
                var secciones = JSON.parse(response);
                $('#edit_seccion').empty();
                $('#edit_seccion').append('<option value="">Seleccione una sección</option>');
                $.each(secciones, function(index, value) {
                    $('#edit_seccion').append('<option value="' + value.idSeccion + '">' + value.seccion + '</option>');
                });
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
                alert("Error al cargar las secciones. Por favor, inténtalo de nuevo.");
            }
        });
    });

    $('#campus').on('change', function() {
        var idCampus = $(this).val();
        $.ajax({
            url: '../php/get_secciones_por_campus.php',
            method: 'POST',
            data: { idCampus: idCampus },
            success: function(response) {
                var secciones = JSON.parse(response);
                $('#seccion').empty();
                $('#seccion').append('<option value="">Seleccione una sección</option>');
                $.each(secciones, function(index, value) {
                    $('#seccion').append('<option value="' + value.idSeccion + '">' + value.seccion + '</option>');
                });
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
                alert("Error al cargar las secciones. Por favor, inténtalo de nuevo.");
            }
        });
    });

    // Escuchar el evento submit del formulario dentro del modal de edición
    $("#formEditarLibro").submit(function(event) {
        // Evitar que se recargue la página al enviar el formulario
        event.preventDefault();

        // Obtener los valores ingresados por el usuario
        var idLibro = $("#edit_idLibro").val();
        var campus = $("#edit_campus").val();
        var seccion = $("#edit_seccion").val();
        var genero = $("#edit_genero").val();
        var titulo = $("#edit_titulo").val();
        var autor = $("#edit_autor").val();
        var editorial = $("#edit_editorial").val();
        var idioma = $("#edit_idioma").val();
        

        // Realizar la solicitud AJAX para actualizar los datos del libro en la base de datos
        $.ajax({
            type: "POST",
            url: "../php/actualizar_libros.php", // Ruta de tu script PHP para actualizar los datos del libro en la base de datos
            data: {
                idLibro: idLibro,
                campus: campus,
                seccion: seccion,
                genero: genero,
                titulo: titulo,
                autor: autor,
                editorial: editorial,
                idioma: idioma
                
            },
            success: function(response) {
                // Mostrar mensaje de éxito o error
                alert(response);

                // Cerrar el modal después de guardar los datos
                $("#modalEditar").modal("hide");

                // Actualizar la página u otra acción necesaria
                location.reload();
            },
            error: function(xhr, status, error) {
                // Manejar errores de la solicitud AJAX
                console.error(xhr.responseText);
                alert("Error al actualizar los datos del libro. Por favor, inténtalo de nuevo.");
            }
        });
    });
});

$(document).ready(function() {
    // Escuchar el evento submit del formulario dentro del modal
    $("#formLibros").submit(function(event) {
        // Evitar que se recargue la página al enviar el formulario
        event.preventDefault();

        // Obtener los valores ingresados por el usuario
        var campus = $("#campus").val();
        var seccion = $("#seccion").val();
        var genero = $("#genero").val();
        var titulo = $("#titulo").val();
        var autor = $("#autor").val();
        var editorial = $("#editorial").val();
        var idioma = $("#idioma").val();
        var cantidad = $("#cantidad").val();

        // Validar campos vacíos
        if (campus === "" || genero === "" ||titulo === "" || seccion === "" ||autor === "" || editorial === "" || idioma === "" || cantidad === "") {
            alert("Todos los campos son obligatorios y no pueden estar vacíos.");
            return;
        }


        // Realizar la solicitud AJAX para guardar los datos en la base de datos
        $.ajax({
            type: "POST",
            url: "../php/guardarlibros.php", // Ruta de tu script PHP para guardar los datos en la base de datos
            data: {
                campus: campus,
                seccion: seccion,
                genero: genero,
                titulo: titulo,
                autor: autor,
                editorial: editorial,
                idioma: idioma,
                cantidad: cantidad
            },
            success: function(response) {
                // Mostrar mensaje de éxito o error
                alert("Se ha registrado correctamente el libro!");

                // Cerrar el modal después de guardar los datos
                $("#modalCRUD").modal("hide");

                // Actualizar la página u otra acción necesaria
                location.reload();
            },
            error: function(xhr, status, error) {
                // Manejar errores de la solicitud AJAX
                console.error(xhr.responseText);
                alert("Error al guardar los datos. Por favor, inténtalo de nuevo.");
            }
        });
    });
});

$(document).ready(function() {
    // Escuchar el evento click del botón de borrado
    $(document).on("click", ".btnBorrar", function() {
        // Obtener el ID del libro a eliminar
        var idLibros = $(this).closest("tr").find("td:first").text();

        // Mostrar mensaje de confirmación antes de eliminar el libro
        if (confirm("¿Estás seguro de eliminar este libro?")) {
            // Realizar la solicitud AJAX para eliminar el libro
            $.ajax({
                type: "POST",
                url: "../php/eliminarlibros.php", // Ruta de tu script PHP para eliminar el libro de la base de datos
                data: {
                    idLibros: idLibros
                },
                success: function(response) {
                    // Mostrar mensaje de éxito o error
                    alert(response);
                    // Recargar la página después de eliminar el libro
                    location.reload();
                },
                error: function(xhr, status, error) {
                    // Manejar errores de la solicitud AJAX
                    console.error(xhr.responseText);
                    alert("Error al eliminar el libro. Por favor, inténtalo de nuevo.");
                }
            });
        }
    });
});

  $(document).ready(function(){
    $('.btnAgregar').click(function(){
        var idLibros = $(this).data('id'); // Obtener el idLibros de la fila correspondiente
        
        var cantidad = prompt("Ingrese la cantidad a agregar:", "0"); // Solicitar al usuario que ingrese la cantidad
        
        // Verificar si se ingresó una cantidad válida
        if (cantidad !== null && !isNaN(cantidad.trim())) {
            // Realizar la solicitud AJAX solo si se ingresó una cantidad válida
            $.ajax({
                url: '../php/agregar_cant_libro.php',
                type: 'post',
                data: { idLibros: idLibros, cantidad: cantidad },
                success: function(response){
                    alert(response);
                   window.location.reload();   
                },
                error: function(xhr, status, error) {
                    alert("Error: " + xhr.responseText);
                }
            });
        } else {
            alert("Por favor, ingrese una cantidad válida.");
        }
    });
});
</script>



    <!-- jQuery, Popper.js, Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/js/bootstrap-select.min.js"></script>

    <!-- datatables JS -->
    <script src="https://cdn.datatables.net/2.0.2/js/dataTables.js"></script>
    
    



</body>

</html>
