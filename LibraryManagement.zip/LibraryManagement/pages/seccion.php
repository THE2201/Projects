<?php
require('../php/connectionBD.php');
session_start();
$usuario = $_SESSION['username'];
if (!isset($usuario)) {
    header('Location: inicio.php');
  }

$sqlPermisos = "SELECT p.editar, p.eliminar, P.agregar
                FROM usuarios u
                INNER JOIN rol r ON u.idRol = r.idRol
                INNER JOIN permisos p ON r.idPermiso = p.idPermiso
                WHERE u.usuario = '$usuario'";
$resultPermisos = $Conn->query($sqlPermisos);

if ($resultPermisos->num_rows > 0) {
    $permisos = $resultPermisos->fetch_assoc();
} else {
    $permisos = array('editar' => 0, 'eliminar' => 0); 
    echo "No se encontraron permisos para el usuario.";
}

$sql = "SELECT s.idSeccion, s.idCampus, s.seccion, s.descripcion, c.campus 
        FROM secciones s
        INNER JOIN campus c ON s.idCampus = c.idCampus
        WHERE s.estado = 'Activo'";
$result = $Conn->query($sql);


?>
<!DOCTYPE html>
<html lang="es" dir="ltr">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="#" />
    <title>Secciones | Biblioteca</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <!--datables CSS básico-->
    <link rel="stylesheet" href="https://cdn.datatables.net/2.0.2/css/dataTables.dataTables.min.css">
    <!--datables estilo bootstrap 5 CSS-->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/2.0.2/css/dataTables.bootstrap5.css">
</head>

<body>
    <header>
        <h4 class="text-center p-3 mb-2 bg-success text-white">Secciones</h4>
    </header>

    <div class="container">
        <div class="row"></div>
        <div class="col-lg-12">
        <?php
            if ($permisos['agregar'] == 1) {
                echo '<button id="btnNuevo" type="button" class="btn btn-success" data-toggle="modal" data-target="#modalCRUD">Nuevo</button>';
            } else {
                echo "<td></td>"; 
            }
            ?>
        </div>
    </div>
    </div>
    <br>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table id="tablaSec" class="table table-striped table-bordered table-condensed" style="width:100%">
                        <thead class="text-center">
                            <tr>
                                <th>ID</th>
                                <th>Campus</th>
                                <th>Sección</th>
                                <th>Descripción</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                                if ($result->num_rows > 0) {
                                    while($row = $result->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td>".$row["idSeccion"]."</td>";
                                        echo "<td>".$row["campus"]."</td>";
                                        echo "<td>".$row["seccion"]."</td>";
                                        echo "<td>".$row["descripcion"]."</td>";
                                        echo "<td>";
                                    
                                    if ($permisos['editar'] == 1 && $permisos['eliminar'] == 1) {
                                        echo "<button class='btn btn-primary btnEditar' data-id='".$row["idSeccion"]."'>Editar</button>";
                                        echo "<button class='btn btn-danger btnBorrar' data-id='".$row["idSeccion"]."'>Borrar</button>";
                                    } elseif ($permisos['editar'] == 1 ) {
                                        echo "<button class='btn btn-primary btnEditar' data-id='".$row["idSeccion"]."'>Editar</button>";
                                    } elseif ($permisos['eliminar'] == 1) {
                                        echo "<button class='btn btn-danger btnBorrar' data-id='".$row["idSeccion"]."'>Borrar</button>";
                                    } else {
                                        echo "</td>";
                                    }
                                    
                                    echo "</td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='7'>No se encontraron registros</td></tr>";
                                }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!--Modal para CRUD-->
    <div class="modal fade" id="modalCRUD" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="formNuevoRegistro" method="POST" action="../php/ins_Seccion.php">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="campus" class="col-form-label">Campus:</label>
                            <select class="form-control" id="campus" name="campus">
                                <?php
                                    $sql_campus = "SELECT * FROM campus";
                                    $result_campus = $Conn->query($sql_campus);
                                    if ($result_campus->num_rows > 0) {
                                        while($row_campus = $result_campus->fetch_assoc()) {
                                            echo "<option value='".$row_campus["idCampus"]."'>".$row_campus["campus"]."</option>";
                                        }
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="seccion" class="col-form-label">Sección:</label>
                            <input type="text" class="form-control" id="seccion" name="seccion">
                        </div>
                        <div class="form-group">
                            <label for="descripcion" class="col-form-label">Descripción:</label>
                            <input type="text" class="form-control" id="descripcion" name="descripcion">
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" id="btnGuardar" class="btn btn-dark">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal para editar registros -->
    <div class="modal fade" id="modalEditar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Editar Registro</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="formEditarRegistro" method="POST" action="../php/upd_seccion.php">
                    <div class="modal-body">
                        <input type="hidden" id="edit_idSeccion" name="edit_idSeccion">
                        <div class="form-group">
                            <label for="edit_seccion" class="col-form-label">Sección:</label>
                            <input type="text" class="form-control" id="edit_seccion" name="edit_seccion">
                        </div>
                        <div class="form-group">
                            <label for="edit_descripcion" class="col-form-label">Descripcion:</label>
                            <input type="text" class="form-control" id="edit_descripcion" name="edit_descripcion">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-dark" id="btnGuardarCambios">Guardar Cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- jQuery, Popper.js, Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>

    <!-- datatables JS -->
    <script src="https://cdn.datatables.net/2.0.2/js/dataTables.js"></script>
    <script type="text/javascript" src="../js/scriptLibros.js"></script>

    <!-- JavaScript para abrir el modal al hacer clic en Nuevo -->
    <script>
        $(document).ready(function() {
        $('#btnNuevo').click(function() {
            $('#modalCRUD').modal('show');
        });

        var tablaSec = $("#tablaSec").DataTable({
            "columnDefs": [{
                "data": null,
                
            }],
            "language": {
                "lengthMenu": "Mostrar _MENU_ registros",
                "zeroRecords": "No se encontraron resultados",
                "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
                "infoFiltered": "(filtrado de un total de _MAX_ registros)",
                "sSearch": "Buscar:",
                "oPaginate": {
                    "sFirst": "Primero",
                    "sLast": "Último",
                    "sNext": "Siguiente",
                    "sPrevious": "Anterior"
                },
                "sProcessing": "Procesando...",
            }
        });

        $('#tablaSec tbody').on('click', 'button.btnBorrar', function () {
            var idSeccion = $(this).attr('data-id');
            if (confirm("¿Estás seguro de que deseas borrar este registro?")) {
                $.ajax({
                    url: '../php/del_Seccion.php',
                    method: 'POST',
                    data: { idSeccion: idSeccion },
                    success: function (response) {
                        alert(response);
                        location.reload();
                    },
                    error: function (xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            }
        });

        $("#btnNuevo").click(function () {
            $("#formNuevoRegistro").trigger("reset");
            $(".modal-header").css("background-color", "#004e18");
            $(".modal-header").css("color", "white");
            $(".modal-title").text("Registro");
            $("#modalCRUD").modal("show");
            id = null;
            opcion = 1;
        });

        $('#tablaSec tbody').on('click', 'button.btnEditar', function () {
        var idSeccion = $(this).attr('data-id');
        
            $.ajax({
                url: '../php/obt_seccion.php',
                method: 'POST',
                data: { idSeccion: idSeccion }, 
                dataType: 'json',
                success: function (response) {
                    $('#edit_idSeccion').val(response.idSeccion);
                    $('#edit_seccion').val(response.seccion); 
                    $('#edit_descripcion').val(response.descripcion);
                    
                    $('#modalEditar').modal('show');
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });

        $('#formEditarRegistro').submit(function(e) {
            e.preventDefault();
            var seccion = $('#edit_seccion').val();
            var descripcion = $('#edit_descripcion').val();
            if (seccion.trim() === '' || descripcion.trim() === '') {
                alert('Por favor complete todos los campos.');
                return;
            }
            
            $.ajax({
                url: $(this).attr('action'),
                method: $(this).attr('method'),
                data: $(this).serialize(),
                success: function(response) {
                    alert(response);
                    $('#modalEditar').modal('hide');
                    location.reload();
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });

        $('#formNuevoRegistro').submit(function(e) {
            e.preventDefault();
            var campus = $('#campus').val();
            var seccion = $('#seccion').val();
            var descripcion = $('#descripcion').val();
            if (campus.trim() === '' || seccion.trim() === '' || descripcion.trim() === '') {
                alert('Por favor complete todos los campos.');
                return;
            }
            $(this).unbind('submit').submit();
        });
        
    });
    </script>

</body>
</html>
