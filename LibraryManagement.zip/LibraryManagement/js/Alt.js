//Alertas INICIO DE SESION


//Transacciones
function altExito() {
	Swal.fire({
		title: "Realizado",
		text: "Operacion completada con exito.",
		icon: "success",
		showConfirmButton: false,
		timer: 1000
	})
}
function altError(errC) {
	Swal.fire({
		title: "Error",
		text: "Error al intentar "+ errC,
		icon: "error",
		showConfirmButton: false,
		timer: 1000
	})
}

function One(user, activ) {
	Swal.fire({
		title: "Error al ejecutar",
		// text:
		html: "Error al  " + activ + " informacion de " + user
		// icon:
		// confirmButtonText:
		// footer:
		// width:
		// padding:
		// background:
		// grow:
		// backdrop:
		// timer:
		// timerProgressBar:
		// toast:
		// position:
		// allowOutsideClick:
		// allowEscapeKey:
		// allowEnterKey:
		// stopKeydownPropagation:

		// input:
		// inputPlaceholder:
		// inputValue:
		// inputOptions:

		//  customClass:
		// 	container:
		// 	popup:
		// 	header:
		// 	title:
		// 	closeButton:
		// 	icon:
		// 	image:
		// 	content:
		// 	input:
		// 	actions:
		// 	confirmButton:
		// 	cancelButton:
		// 	footer:	

		// showConfirmButton:
		// confirmButtonColor:
		// confirmButtonAriaLabel:

		// showCancelButton:
		// cancelButtonText:
		// cancelButtonColor:
		// cancelButtonAriaLabel:

		// buttonsStyling:
		// showCloseButton:
		// closeButtonAriaLabel:


		// imageUrl:
		// imageWidth:
		// imageHeight:
		// imageAlt:
	});
}

    
