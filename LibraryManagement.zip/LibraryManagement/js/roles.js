$(document).ready(function () {
    tablaRoles = $("#tablaRoles").DataTable({
        "columnDefs": [{
            "targets": -1,
            "data": null,
            "defaultContent": "<div class='text-center'><div class='btn-group'><button class='btn btn-primary btnEditar'>Editar</button><button class='btn btn-danger btnBorrar'>Borrar</button></div></div>"
        }],

        //Para cambiar el lenguaje a español
        "language": {
            "lengthMenu": "Mostrar _MENU_ registros",
            "zeroRecords": "No se encontraron resultados",
            "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
            "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
            "infoFiltered": "(filtrado de un total de _MAX_ registros)",
            "sSearch": "Buscar:",
            "oPaginate": {
                "sFirst": "Primero",
                "sLast": "Último",
                "sNext": "Siguiente",
                "sPrevious": "Anterior"
            },
            "sProcessing": "Procesando...",
        }
    });

    $("#btnNuevo").click(function () {
        $("#formRol").trigger("reset");
        $(".modal-header").css("background-color", "#004e18");
        $(".modal-header").css("color", "white");
        $(".modal-title").text("Nueva");
        $("#modalCRUD").modal("show");
        id = null;
        opcion = 1;
    });

    var fila; //capturar fila

    //boton editar
    $(document).on("click", ".btnEditar", function () {
        fila = $(this).closest("tr");
        id = parseInt(fila.find('td:eq(0)').text());
        permiso = parseInt(fila.find('td:eq(1)').text());
        nombre = fila.find('td:eq(2)').text();
        libros = parseInt(fila.find('td:eq(3)').text());
        mobiliario = parseInt(fila.find('td:eq(4)').text());
        prestamos = parseInt(fila.find('td:eq(5)').text());
        solicitantes = parseInt(fila.find('td:eq(6)').text());
        reportes = parseInt(fila.find('td:eq(7)').text());
        configuracion = parseInt(fila.find('td:eq(8)').text());

        $("#idPermiso").val(permiso);
        $("#nombre").val(nombre);
        $("#libro").val(libros);
        $("#mobiliario").val(mobiliario);
        $("#prestamos").val(prestamos);
        $("#solicitantes").val(solicitantes);
        $("#reportes").val(reportes);
        $("#configuracion").val(configuracion);
        
        opcion = 2;

        $(".modal-header").css("background-color", "#004e18");
        $(".modal-header").css("color", "white");
        $(".modal-title").text("Editar Registro");
        $("#modalCRUD").modal("show");

    });
    //botón BORRAR
    $(document).on("click", ".btnBorrar", function () {
        fila = $(this);
        id = parseInt($(this).closest("tr").find('td:eq(0)').text());
        opcion = 3; //borrar
        var respuesta = confirm("¿Está seguro de eliminar el registro: " + id + "?");
        if (respuesta) {
            $.ajax({
                url: '../pages/crudRoles.php',
                type: "POST",
                dataType: "json",
                data: { opcion: opcion, id: id },
                success: function () {
                    tablaRoles.row(fila.parents('tr')).remove().draw();
                    
                }
            });
        }
    });
    $("#formRol").submit(function (e) {
        e.preventDefault();
        permiso = $.trim($("#idPermiso").val());
        nombre = $.trim($("#nombre").val());
        libros = $.trim($("#libro").val());
        mobiliario = $.trim($("#mobiliario").val());
        prestamos = $.trim($("#prestamos").val());
        solicitantes = $.trim($("#solicitantes").val());
        reportes = $.trim($("#reportes").val());
        configuracion = $.trim($("#configuracion").val());
        $.ajax({
            url: '../pages/crudRoles.php',
            type: "POST",
            dataType: "json",
            data: { permiso: permiso, nombre: nombre, libros: libros, mobiliario: mobiliario, prestamos: prestamos, solicitantes: solicitantes, reportes: reportes, configuracion: configuracion, id: id, opcion: opcion },
            success: function (data) {
                console.log(data);
                id = data[0].id;
                permiso = data[0].permiso;                
                nombre = data[0].nombre;
                libros = data[0].libros;
                mobiliario = data[0].mobiliario;
                prestamos = data[0].prestamos;
                solicitantes = data[0].solicitantes;
                reportes = data[0].reportes;
                configuracion = data[0].configuracion;
                if (opcion == 1) { tablaRoles.row.add([id, permiso, nombre, libros, mobiliario, prestamos, solicitantes, reportes, configuracion]).draw(); }
                else { tablaRoles.row(fila).data([id, permiso, nombre, libros, mobiliario, prestamos, solicitantes, reportes, configuracion]).draw(); }
            }
        });
        $("#modalCRUD").modal("hide");

    });

});