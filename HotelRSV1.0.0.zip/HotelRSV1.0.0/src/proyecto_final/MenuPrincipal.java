package proyecto_final;

import Clases.*;
import Registros_Reservaciones.*;
import Componentes.MessageDialog;
import Conexion.conexionBD;
import chrriis.dj.nativeswing.swtimpl.NativeInterface;
import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Label;
import Reportes.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import Componentes.Notification;
import static Registros_Reservaciones.menuClienteReservaciones.tbCliente;
import Reportes.Principal_Reporte;
import Reservaciones.administracionRentasTransporte;
import javaswingdev.drawer.Drawer;
import javaswingdev.drawer.DrawerController;
import javaswingdev.drawer.DrawerItem;
import javaswingdev.drawer.EventDrawer;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class MenuPrincipal extends javax.swing.JFrame {

    private DrawerController desplazar;
    public static String Usuario, Identidad;

    Connection con = null;
    conexionBD conecta;
    String senteciaSQL;
    String senteciaSQL2;
    String senteciaSQL3;
    PreparedStatement ps = null;
    ResultSet rs = null;
    PreparedStatement ps2 = null;
    ResultSet rs2 = null;
    PreparedStatement ps3 = null;
    ResultSet rs3 = null;
    String SenSQL;
    PreparedStatement PS = null;
    ResultSet RS = null;
    Object datos[] = new Object[3];
    DefaultTableModel modelo;
    int cerrar = 0;
    public static int i = 0;

    public MenuPrincipal() {
        initComponents();
        this.setLocationRelativeTo(null);
        diseñotabla();
        centrarTabla();
        TUser.setText(Usuario);
        prgHabitaciones.setValue(50);

        try {
            cargar();
        } catch (Exception e) {
        }
        if (i == 1) {
            i = 2;
            System.out.println("1");
        }
        verificaciones();
        inicio();

    }

    public void conectarBD() {
        conecta = new conexionBD("proyecto_final");
        con = conecta.getConexion();
    }

    public void limpiar() {

        int fila = tbRegistros.getRowCount();
        for (int i = fila - 1; i >= 0; i--) {
            modelo.removeRow(i);
        }
    }

    public void cargar() throws IOException {
        conectarBD();
        try {

            ImageIcon foto;
            InputStream is;

            senteciaSQL = "SELECT * FROM usuario WHERE identidadEmpleado LIKE '" + Identidad + "'";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(senteciaSQL);

            if (rs.next()) {
                is = rs.getBinaryStream("FOTO");

                BufferedImage bi = ImageIO.read(is);
                foto = new ImageIcon(bi);

                Image img = foto.getImage();
                Image newimg = img.getScaledInstance(lblFoto.getWidth(), lblFoto.getHeight(), Image.SCALE_REPLICATE);

                ImageIcon newcon = new ImageIcon(newimg);

                lblFoto.setIcon(newcon);
            } else {
                JOptionPane.showMessageDialog(null, "REGISTRO NO ENCONTRADO", "INFORMACION", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void inicio() {

        String rol = "";

        try {
            conectarBD();

            senteciaSQL = "SELECT cargo FROM empleado WHERE identidad LIKE '" + Identidad + "'";
            ps = con.prepareStatement(senteciaSQL);
            rs = ps.executeQuery();

            while (rs.next()) {
                rol = rs.getString(1);

            }
            con.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos" + ex.getMessage());

        }
        if (rol.equals("Administrador")) {
            desplazar = Drawer.newDrawer(this)
                    .header(new Perfil())
                    .separator(5, new Color(173, 173, 173))//Crea una linea separadora
                    .drawerBackground(new Color(245, 245, 245))
                    .background(new Color(0, 153, 255))//Coloca color al fondo
                    .backgroundTransparent(0.3f)//Pone fondo con transparencia
                    .addChild(new DrawerItem("Administracion de Clientes").icon(new ImageIcon(getClass().getResource("/Img/registro.png"))).build())
                    .addChild(new DrawerItem("Administracion de Reservaciones").icon(new ImageIcon(getClass().getResource("/Img/Alquiler.png"))).build())
                    .addChild(new DrawerItem("Administracion de Empleados").icon(new ImageIcon(getClass().getResource("/Img/empleados.png"))).build())
                    .addChild(new DrawerItem("Administracion de Chofer").icon(new ImageIcon(getClass().getResource("/Img/chofer.png"))).build())
                    .addChild(new DrawerItem("Administracion Habitaciones").icon(new ImageIcon(getClass().getResource("/Img/habitaciones.png"))).build())
                    .addChild(new DrawerItem("Administracion Rentas de Transporte").icon(new ImageIcon(getClass().getResource("/Img/carro.png"))).build())
                    .addChild(new DrawerItem("Administracion Automovil").icon(new ImageIcon(getClass().getResource("/Img/vehiculo.png"))).build())
                    .addChild(new DrawerItem("Administracion de Usuarios").icon(new ImageIcon(getClass().getResource("/Img/Users.png"))).build())
                    .addChild(new DrawerItem("Reportes").icon(new ImageIcon(getClass().getResource("/Img/reporte.png"))).build())
                    .addChild(new DrawerItem("Ayuda").icon(new ImageIcon(getClass().getResource("/Img/ayuda.png"))).build())
                    .addChild(new DrawerItem("Contacto").icon(new ImageIcon(getClass().getResource("/Img/conctacto.png"))).build())
                    .event(new EventDrawer() {
                        @Override
                        public void selected(int i, DrawerItem di) {
                            //JOptionPane.showMessageDialog(null, "Selecciono" + i);
                            if (i == 0) {
                                menuCliente cliente = new menuCliente();
                                cliente.setVisible(true);
                            } else if (i == 1) {
                                Reservaciones Rv = new Reservaciones();
                                Rv.setVisible(true);

                            } else if (i == 2) {
                                menuEmpleado empleado = new menuEmpleado();
                                empleado.setVisible(true);
                            } else if (i == 3) {
                                menuChofer chofer = new menuChofer();
                                chofer.setVisible(true);
                            } else if (i == 4) {
                                menuHabitaciones habitacion = new menuHabitaciones();
                                habitacion.setVisible(true);

                            } else if (i == 5) {
                                administracionRentasTransporte admin = new administracionRentasTransporte();
                                admin.setVisible(true);
                            } else if (i == 6) {
                                Clases.menuAutomovil AutoM = new Clases.menuAutomovil();
                                AutoM.setVisible(true);

                            } else if (i == 7) {
                                menuUsuario user = new menuUsuario();
                                user.setVisible(true);
                            } else if (i == 8) {
                                Principal_Reporte reporte = new Principal_Reporte();
                                reporte.setVisible(true);

                            } else if (i == 9) {
                                Ayuda ayuda = new Ayuda();
                                ayuda.setVisible(true);

                            } else if (i == 10) {
                                IntegrantesGrupo integrantes = new IntegrantesGrupo();
                                integrantes.setVisible(true);
                            }

                        }
                    })
                    .build();
        } else if (rol.equals("Recepcionista")) {
            desplazar = Drawer.newDrawer(this)
                    .header(new Perfil())
                    .separator(5, new Color(173, 173, 173))//Crea una linea separadora
                    .drawerBackground(new Color(245, 245, 245))
                    .background(new Color(0, 153, 255))//Coloca color al fondo
                    .backgroundTransparent(0.3f)//Pone fondo con transparencia
                    .addChild(new DrawerItem("").icon(new ImageIcon(getClass().getResource(""))).build())
                    .addChild(new DrawerItem("").icon(new ImageIcon(getClass().getResource(""))).build())
                    .addChild(new DrawerItem("Administracion de Clientes").icon(new ImageIcon(getClass().getResource("/Img/registro.png"))).build())
                    .addChild(new DrawerItem("Administracion de Reservaciones").icon(new ImageIcon(getClass().getResource("/Img/Alquiler.png"))).build())
                    .addChild(new DrawerItem("Administracion Habitaciones").icon(new ImageIcon(getClass().getResource("/Img/habitaciones.png"))).build())
                    .addChild(new DrawerItem("Administracion Rentas de Transporte").icon(new ImageIcon(getClass().getResource("/Img/carro.png"))).build())
                    .addChild(new DrawerItem("Administracion Automovil").icon(new ImageIcon(getClass().getResource("/Img/vehiculo.png"))).build())
                    .addChild(new DrawerItem("Reportes").icon(new ImageIcon(getClass().getResource("/Img/reporte.png"))).build())
                    .addChild(new DrawerItem("Ayuda").icon(new ImageIcon(getClass().getResource("/Img/ayuda.png"))).build())
                    .addChild(new DrawerItem("Contacto").icon(new ImageIcon(getClass().getResource("/Img/conctacto.png"))).build())
                    .event(new EventDrawer() {
                        @Override
                        public void selected(int i, DrawerItem di) {
                            //JOptionPane.showMessageDialog(null, "Selecciono" + i);
                            if (i == 2) {
                                menuCliente cliente = new menuCliente();
                                cliente.setVisible(true);
                            } else if (i == 3) {
                                Reservaciones Rv = new Reservaciones();
                                Rv.setVisible(true);
                            } else if (i == 4) {
                                menuHabitaciones habitacion = new menuHabitaciones();
                                habitacion.setVisible(true);
                            } else if (i == 5) {
                                administracionRentasTransporte admin = new administracionRentasTransporte();
                                admin.setVisible(true);
                            } else if (i == 6) {
                                Clases.menuAutomovil AutoM = new Clases.menuAutomovil();
                                AutoM.setVisible(true);
                            } else if (i == 7) {
                                Principal_Reporte reporte = new Principal_Reporte();
                                reporte.setVisible(true);

                            } else if (i == 8) {
                                Ayuda ayuda = new Ayuda();
                                ayuda.setVisible(true);

                            } else if (i == 9) {
                                IntegrantesGrupo integrantes = new IntegrantesGrupo();
                                integrantes.setVisible(true);
                            }
                        }
                    })
                    .build();
        } else if (rol.equals("Supervisor")) {
            desplazar = Drawer.newDrawer(this)
                    .header(new Perfil())
                    .separator(5, new Color(173, 173, 173))//Crea una linea separadora
                    .drawerBackground(new Color(245, 245, 245))
                    .background(new Color(0, 153, 255))//Coloca color al fondo
                    .backgroundTransparent(0.3f)//Pone fondo con transparencia
                    .addChild(new DrawerItem("").icon(new ImageIcon(getClass().getResource(""))).build())
                    .addChild(new DrawerItem("").icon(new ImageIcon(getClass().getResource(""))).build())
                    .addChild(new DrawerItem("Administracion de Cliente").icon(new ImageIcon(getClass().getResource("/Img/registro.png"))).build())
                    .addChild(new DrawerItem("Administracion de Reservaciones").icon(new ImageIcon(getClass().getResource("/Img/Alquiler.png"))).build())
                    .addChild(new DrawerItem("Administracion Habitaciones").icon(new ImageIcon(getClass().getResource("/Img/habitaciones.png"))).build())
                    .addChild(new DrawerItem("Administracion Rentas de Transporte").icon(new ImageIcon(getClass().getResource("/Img/carro.png"))).build())
                    .addChild(new DrawerItem("Administracion Automovil").icon(new ImageIcon(getClass().getResource("/Img/vehiculo.png"))).build())
                    .addChild(new DrawerItem("Ayuda").icon(new ImageIcon(getClass().getResource("/Img/ayuda.png"))).build())
                    .addChild(new DrawerItem("Contacto").icon(new ImageIcon(getClass().getResource("/Img/conctacto.png"))).build())
                    .event(new EventDrawer() {
                        @Override
                        public void selected(int i, DrawerItem di) {
                            if (i == 2) {
                                menuCliente cliente = new menuCliente();
                                cliente.setVisible(true);
                            } else if (i == 3) {
                                Reservaciones Rv = new Reservaciones();
                                Rv.setVisible(true);
                            } else if (i == 4) {
                                menuHabitaciones habitacion = new menuHabitaciones();
                                habitacion.setVisible(true);
                            } else if (i == 5) {
                                administracionRentasTransporte admin = new administracionRentasTransporte();
                                admin.setVisible(true);
                            } else if (i == 6) {
                                Clases.menuAutomovil AutoM = new Clases.menuAutomovil();
                                AutoM.setVisible(true);
                            } else if (i == 7) {
                                Ayuda ayuda = new Ayuda();
                                ayuda.setVisible(true);

                            } else if (i == 8) {
                                IntegrantesGrupo integrantes = new IntegrantesGrupo();
                                integrantes.setVisible(true);
                            }
                        }
                    })
                    .build();
        }
    }

    public void verificaciones() {
        conectarBD();
        int cont = 0;
        senteciaSQL = "SELECT * FROM habitacion WHERE estado LIKE 'Activa' AND alquiler LIKE 'Disponible'";
        try {
            ps = con.prepareStatement(senteciaSQL);
            rs = ps.executeQuery();

            while (rs.next()) {
                cont += 1;
            }
            lbHabitacionDisp.setText(Integer.toString(cont));
            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
        }
        conectarBD();
        int cont2 = 0;
        senteciaSQL = "SELECT * FROM habitacion WHERE estado LIKE 'Activa' AND alquiler LIKE 'Ocupada'";
        try {
            ps = con.prepareStatement(senteciaSQL);
            rs = ps.executeQuery();

            while (rs.next()) {
                cont2++;
            }
            lbHabitacionRent.setText(Integer.toString(cont2));
            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
        }
        conectarBD();
        int cont3 = 0;
        senteciaSQL = "SELECT * FROM automovil WHERE estado LIKE 'Activo' AND alquiler LIKE 'Disponible'";
        try {
            ps = con.prepareStatement(senteciaSQL);
            rs = ps.executeQuery();

            while (rs.next()) {
                cont3++;
            }
            lbAutoAlq.setText(Integer.toString(cont3));
            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
        }
        conectarBD();
        int cont4 = 0;
        senteciaSQL = "SELECT * FROM automovil WHERE estado LIKE 'Activo' AND alquiler LIKE 'Ocupado'";
        try {
            ps = con.prepareStatement(senteciaSQL);
            rs = ps.executeQuery();

            while (rs.next()) {
                cont4++;
            }
            lbAutoOcu.setText(Integer.toString(cont4));
            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
        }
        conectarBD();
        int cont5 = 0;
        senteciaSQL = "SELECT * FROM cliente WHERE estado LIKE 'Activo'";
        try {
            ps = con.prepareStatement(senteciaSQL);
            rs = ps.executeQuery();

            while (rs.next()) {
                cont5++;
            }
            lbClientes.setText(Integer.toString(cont5));
            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
        }
        conectarBD();
        int cont6 = 0;
        String fecha = RealTime();
        senteciaSQL = "SELECT * FROM reservacion WHERE estado LIKE 'Activa' AND fechaIngreso='" + fecha + "' AND estado!='Cancelada'";
        try {
            ps = con.prepareStatement(senteciaSQL);
            rs = ps.executeQuery();

            while (rs.next()) {
                cont6++;
            }
            lbRentasHoy.setText(Integer.toString(cont6));
            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
        }

        conectarBD();
        int cont7 = 0;
        String nombre = "";
        String Habitacion = "";
        System.out.println("Fecha" + fecha);
        senteciaSQL = "SELECT  * FROM reservacion WHERE estado LIKE 'Activa' AND fechaIngreso='" + fecha + "'";

        try {
            ps = con.prepareStatement(senteciaSQL);
            rs = ps.executeQuery();
            modelo = (DefaultTableModel) tbRegistros.getModel();
            while (rs.next()) {
                System.out.println("prueb");
                cont7++;
                datos[0] = "Reservacion Habitacion";
                senteciaSQL2 = "SELECT * FROM cliente WHERE estado LIKE 'Activo' AND identidad LIKE '" + rs.getString(2) + "' ";
                try {
                    ps2 = con.prepareStatement(senteciaSQL2);
                    rs2 = ps2.executeQuery();
                    while (rs2.next()) {
                        nombre = rs2.getString(3);
                    }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
                }
                System.out.println("a" + Habitacion);
                senteciaSQL3 = "SELECT * FROM habitacion WHERE estado LIKE 'Activo' AND codHabitaciones ='" + rs.getString(5) + "'";
                try {
                    ps3 = con.prepareStatement(senteciaSQL3);
                    rs3 = ps3.executeQuery();
                    while (rs3.next()) {
                        Habitacion = rs3.getString(2) + " " + rs3.getString(3);
                        System.out.println("a2" + Habitacion);
                    }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
                }

                datos[2] = nombre + " Hizo una reservacion de una Habitacion " + Habitacion;
                datos[1] = Integer.toString(rs.getInt(1));
                modelo.addRow(datos);
            }
            tbRegistros.setModel(modelo);
            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
        }

    }

    public static String RealTime() {
        Date fecha = new Date();
        SimpleDateFormat formatFecha = new SimpleDateFormat("YYYY/MM/dd");
        SimpleDateFormat yx = new SimpleDateFormat("YYYY");
        SimpleDateFormat mx = new SimpleDateFormat("MM");
        SimpleDateFormat dx = new SimpleDateFormat("dd");
        return formatFecha.format(fecha);
    }

    public void diseñotabla() {
        tbRegistros.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tbRegistros.getTableHeader().setOpaque(false);
        tbRegistros.getTableHeader().setBackground(new Color(32, 136, 203));
        tbRegistros.getTableHeader().setForeground(new Color(255, 255, 255));
        tbRegistros.setRowHeight(25);
    }

    public void centrarTabla() {
        DefaultTableCellRenderer tcr = new DefaultTableCellRenderer();
        tcr.setHorizontalAlignment(SwingConstants.CENTER);
        tbRegistros.getColumnModel().getColumn(0).setCellRenderer(tcr);
        tbRegistros.getColumnModel().getColumn(1).setCellRenderer(tcr);
        tbRegistros.getColumnModel().getColumn(2).setCellRenderer(tcr);

        ((DefaultTableCellRenderer) tbRegistros.getTableHeader().getDefaultRenderer())
                .setHorizontalAlignment(SwingConstants.CENTER);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLayeredPane1 = new javax.swing.JLayeredPane();
        jPanel2 = new javax.swing.JPanel();
        fSGradientPanel8 = new LIB.FSGradientPanel();
        lbclientes5 = new javax.swing.JLabel();
        lbClientes = new javax.swing.JLabel();
        lbIcon5 = new javax.swing.JLabel();
        jProgressBar6 = new javax.swing.JProgressBar();
        fSGradientPanel2 = new LIB.FSGradientPanel();
        lbclientes6 = new javax.swing.JLabel();
        lbRentasHoy = new javax.swing.JLabel();
        lbIcon6 = new javax.swing.JLabel();
        jProgressBar7 = new javax.swing.JProgressBar();
        fSGradientPanel1 = new LIB.FSGradientPanel();
        lbclientes = new javax.swing.JLabel();
        lbHabitacionRent = new javax.swing.JLabel();
        lbIcon = new javax.swing.JLabel();
        jProgressBar4 = new javax.swing.JProgressBar();
        fSGradientPanel4 = new LIB.FSGradientPanel();
        lbclientes1 = new javax.swing.JLabel();
        lbAutoAlq = new javax.swing.JLabel();
        lbIcon1 = new javax.swing.JLabel();
        jProgressBar2 = new javax.swing.JProgressBar();
        fSGradientPanel7 = new LIB.FSGradientPanel();
        lbclientes4 = new javax.swing.JLabel();
        lbValues4 = new javax.swing.JLabel();
        lbIcon4 = new javax.swing.JLabel();
        lbPer4 = new javax.swing.JLabel();
        jProgressBar5 = new javax.swing.JProgressBar();
        fSGradientPanel5 = new LIB.FSGradientPanel();
        lbclientes2 = new javax.swing.JLabel();
        lbAutoOcu = new javax.swing.JLabel();
        lbIcon2 = new javax.swing.JLabel();
        jProgressBar3 = new javax.swing.JProgressBar();
        fSGradientPanel6 = new LIB.FSGradientPanel();
        lbclientes3 = new javax.swing.JLabel();
        lbHabitacionDisp = new javax.swing.JLabel();
        lbIcon3 = new javax.swing.JLabel();
        prgHabitaciones = new javax.swing.JProgressBar();
        jPanel1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbRegistros = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        lblFoto = new javax.swing.JLabel();
        MinimizeSys = new javax.swing.JButton();
        ExitSys = new javax.swing.JButton();
        CerrarS = new javax.swing.JButton();
        TUser = new javax.swing.JLabel();
        btnIngreso = new javax.swing.JButton();

        javax.swing.GroupLayout jLayeredPane1Layout = new javax.swing.GroupLayout(jLayeredPane1);
        jLayeredPane1.setLayout(jLayeredPane1Layout);
        jLayeredPane1Layout.setHorizontalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jLayeredPane1Layout.setVerticalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1000, 750));
        setUndecorated(true);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 255), 10));
        jPanel2.setMinimumSize(new java.awt.Dimension(1000, 750));
        jPanel2.setPreferredSize(new java.awt.Dimension(1000, 750));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        fSGradientPanel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 0, 204), 0));
        fSGradientPanel8.setFSEndColor(new java.awt.Color(255, 204, 51));
        fSGradientPanel8.setFSGradientFocus(200);
        fSGradientPanel8.setFSStartColor(new java.awt.Color(255, 153, 0));
        fSGradientPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbclientes5.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        lbclientes5.setForeground(new java.awt.Color(225, 225, 225));
        lbclientes5.setText("Clientes Registrados");
        fSGradientPanel8.add(lbclientes5, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 13, -1, -1));

        lbClientes.setFont(new java.awt.Font("sansserif", 0, 24)); // NOI18N
        lbClientes.setForeground(new java.awt.Color(225, 225, 225));
        lbClientes.setText("Num");
        fSGradientPanel8.add(lbClientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 43, -1, -1));

        lbIcon5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbIcon5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/perfil.png"))); // NOI18N
        fSGradientPanel8.add(lbIcon5, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 20, 70, 70));

        jProgressBar6.setBackground(new java.awt.Color(255, 255, 255));
        fSGradientPanel8.add(jProgressBar6, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 90, 200, 5));

        jPanel2.add(fSGradientPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 310, 340, 114));

        fSGradientPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 0, 204), 0));
        fSGradientPanel2.setFSEndColor(new java.awt.Color(102, 255, 102));
        fSGradientPanel2.setFSGradientFocus(200);
        fSGradientPanel2.setFSStartColor(new java.awt.Color(0, 204, 204));
        fSGradientPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbclientes6.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        lbclientes6.setForeground(new java.awt.Color(225, 225, 225));
        lbclientes6.setText("Cantidad Rentas de Hoy");
        fSGradientPanel2.add(lbclientes6, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 13, -1, -1));

        lbRentasHoy.setFont(new java.awt.Font("sansserif", 0, 24)); // NOI18N
        lbRentasHoy.setForeground(new java.awt.Color(225, 225, 225));
        lbRentasHoy.setText("Num");
        fSGradientPanel2.add(lbRentasHoy, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 43, -1, -1));

        lbIcon6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbIcon6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/habitacionesrentadas.png"))); // NOI18N
        fSGradientPanel2.add(lbIcon6, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 20, 70, 70));

        jProgressBar7.setBackground(new java.awt.Color(255, 255, 255));
        fSGradientPanel2.add(jProgressBar7, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 90, 200, 5));

        jPanel2.add(fSGradientPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 310, 340, 114));

        fSGradientPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 0, 204), 0));
        fSGradientPanel1.setFSEndColor(new java.awt.Color(153, 51, 0));
        fSGradientPanel1.setFSGradientFocus(200);
        fSGradientPanel1.setFSStartColor(new java.awt.Color(255, 204, 102));
        fSGradientPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbclientes.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        lbclientes.setForeground(new java.awt.Color(225, 225, 225));
        lbclientes.setText("Habitaciones Rentadas.");
        fSGradientPanel1.add(lbclientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 13, -1, -1));

        lbHabitacionRent.setFont(new java.awt.Font("sansserif", 0, 24)); // NOI18N
        lbHabitacionRent.setForeground(new java.awt.Color(225, 225, 225));
        lbHabitacionRent.setText("Num");
        fSGradientPanel1.add(lbHabitacionRent, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 43, -1, -1));

        lbIcon.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/puerta.png"))); // NOI18N
        fSGradientPanel1.add(lbIcon, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 20, 70, 70));

        jProgressBar4.setBackground(new java.awt.Color(255, 255, 255));
        fSGradientPanel1.add(jProgressBar4, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 90, 200, 5));

        jPanel2.add(fSGradientPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 50, 340, 114));

        fSGradientPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 0, 204), 0));
        fSGradientPanel4.setFSEndColor(new java.awt.Color(0, 102, 255));
        fSGradientPanel4.setFSGradientFocus(200);
        fSGradientPanel4.setFSStartColor(new java.awt.Color(102, 0, 204));
        fSGradientPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbclientes1.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        lbclientes1.setForeground(new java.awt.Color(225, 225, 225));
        lbclientes1.setText("Automoviles Disponibles.");
        fSGradientPanel4.add(lbclientes1, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 13, -1, -1));

        lbAutoAlq.setFont(new java.awt.Font("sansserif", 0, 24)); // NOI18N
        lbAutoAlq.setForeground(new java.awt.Color(225, 225, 225));
        lbAutoAlq.setText("Num");
        fSGradientPanel4.add(lbAutoAlq, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 43, -1, -1));

        lbIcon1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbIcon1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/carro1.png"))); // NOI18N
        fSGradientPanel4.add(lbIcon1, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 20, 70, 70));

        jProgressBar2.setBackground(new java.awt.Color(255, 255, 255));
        fSGradientPanel4.add(jProgressBar2, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 90, 200, 5));

        fSGradientPanel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 0, 204), 0));
        fSGradientPanel7.setFSEndColor(new java.awt.Color(0, 102, 255));
        fSGradientPanel7.setFSGradientFocus(200);
        fSGradientPanel7.setFSStartColor(new java.awt.Color(102, 0, 204));
        fSGradientPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbclientes4.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        lbclientes4.setForeground(new java.awt.Color(225, 225, 225));
        lbclientes4.setText("Automoviles Disponibles.");
        fSGradientPanel7.add(lbclientes4, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 13, -1, -1));

        lbValues4.setFont(new java.awt.Font("sansserif", 0, 24)); // NOI18N
        lbValues4.setForeground(new java.awt.Color(225, 225, 225));
        lbValues4.setText("Num");
        fSGradientPanel7.add(lbValues4, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 43, -1, -1));

        lbIcon4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbIcon4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/perfil.png"))); // NOI18N
        fSGradientPanel7.add(lbIcon4, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 20, 70, 70));

        lbPer4.setForeground(new java.awt.Color(255, 255, 255));
        lbPer4.setText("0%");
        fSGradientPanel7.add(lbPer4, new org.netbeans.lib.awtextra.AbsoluteConstraints(219, 81, -1, 20));

        jProgressBar5.setBackground(new java.awt.Color(255, 255, 255));
        fSGradientPanel7.add(jProgressBar5, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 90, 200, 5));

        fSGradientPanel4.add(fSGradientPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 210, 340, 114));

        jPanel2.add(fSGradientPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 180, 340, 114));

        fSGradientPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 0, 204), 0));
        fSGradientPanel5.setFSEndColor(new java.awt.Color(0, 102, 255));
        fSGradientPanel5.setFSGradientFocus(200);
        fSGradientPanel5.setFSStartColor(new java.awt.Color(102, 0, 204));
        fSGradientPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbclientes2.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        lbclientes2.setForeground(new java.awt.Color(225, 225, 225));
        lbclientes2.setText("Automoviles Ocupados.");
        fSGradientPanel5.add(lbclientes2, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 13, -1, -1));

        lbAutoOcu.setFont(new java.awt.Font("sansserif", 0, 24)); // NOI18N
        lbAutoOcu.setForeground(new java.awt.Color(225, 225, 225));
        lbAutoOcu.setText("Num");
        fSGradientPanel5.add(lbAutoOcu, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 43, -1, -1));

        lbIcon2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbIcon2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/carro2.png"))); // NOI18N
        fSGradientPanel5.add(lbIcon2, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 20, 70, 70));

        jProgressBar3.setBackground(new java.awt.Color(255, 255, 255));
        fSGradientPanel5.add(jProgressBar3, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 90, 200, 5));

        jPanel2.add(fSGradientPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 180, 340, 114));

        fSGradientPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 0, 204), 0));
        fSGradientPanel6.setFSEndColor(new java.awt.Color(255, 102, 255));
        fSGradientPanel6.setFSGradientFocus(200);
        fSGradientPanel6.setFSStartColor(new java.awt.Color(102, 0, 204));
        fSGradientPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbclientes3.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        lbclientes3.setForeground(new java.awt.Color(225, 225, 225));
        lbclientes3.setText("Habitaciones Disponibles");
        fSGradientPanel6.add(lbclientes3, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 13, -1, -1));

        lbHabitacionDisp.setFont(new java.awt.Font("sansserif", 0, 24)); // NOI18N
        lbHabitacionDisp.setForeground(new java.awt.Color(225, 225, 225));
        lbHabitacionDisp.setText("Num");
        fSGradientPanel6.add(lbHabitacionDisp, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 43, -1, -1));

        lbIcon3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbIcon3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/cama.png"))); // NOI18N
        fSGradientPanel6.add(lbIcon3, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 20, 70, 70));

        prgHabitaciones.setBackground(new java.awt.Color(255, 255, 255));
        prgHabitaciones.setValue(50);
        fSGradientPanel6.add(prgHabitaciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 90, 200, 5));

        jPanel2.add(fSGradientPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 50, 340, 114));

        jPanel1.setBackground(new java.awt.Color(217, 217, 217));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("sansserif", 1, 15)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(76, 76, 76));
        jLabel5.setText("Reservaciones Pendientes por Ingresar Hoy:");
        jLabel5.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 10, 1, 1));
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 5, 360, -1));

        tbRegistros.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        tbRegistros.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Categoria", "ID", "Descripcion"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Object.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tbRegistros.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tbRegistros.setGridColor(new java.awt.Color(204, 204, 204));
        tbRegistros.setShowGrid(true);
        tbRegistros.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbRegistrosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbRegistros);
        if (tbRegistros.getColumnModel().getColumnCount() > 0) {
            tbRegistros.getColumnModel().getColumn(0).setMinWidth(150);
            tbRegistros.getColumnModel().getColumn(0).setPreferredWidth(150);
            tbRegistros.getColumnModel().getColumn(0).setMaxWidth(200);
            tbRegistros.getColumnModel().getColumn(1).setMinWidth(50);
            tbRegistros.getColumnModel().getColumn(1).setPreferredWidth(50);
            tbRegistros.getColumnModel().getColumn(1).setMaxWidth(100);
        }

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 690, 260));

        jPanel2.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 440, 690, 290));

        jButton1.setBackground(new java.awt.Color(153, 204, 255));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/square (1).png"))); // NOI18N
        jButton1.setBorderPainted(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 60, 60));

        jPanel3.setBackground(new java.awt.Color(0, 153, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel20.setFont(new java.awt.Font("Roboto Black", 1, 20)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Software Hotel");
        jPanel3.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 5, 191, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/LogIc.png"))); // NOI18N
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 5, 30, 30));

        lblFoto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/user (1).png"))); // NOI18N
        jPanel3.add(lblFoto, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 0, 30, 40));

        MinimizeSys.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/BMin.png"))); // NOI18N
        MinimizeSys.setContentAreaFilled(false);
        MinimizeSys.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MinimizeSysActionPerformed(evt);
            }
        });
        jPanel3.add(MinimizeSys, new org.netbeans.lib.awtextra.AbsoluteConstraints(921, 7, 30, 26));

        ExitSys.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/BClose.png"))); // NOI18N
        ExitSys.setContentAreaFilled(false);
        ExitSys.setPreferredSize(new java.awt.Dimension(30, 30));
        ExitSys.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExitSysMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ExitSysMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ExitSysMouseExited(evt);
            }
        });
        ExitSys.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitSysActionPerformed(evt);
            }
        });
        jPanel3.add(ExitSys, new org.netbeans.lib.awtextra.AbsoluteConstraints(958, 7, 32, 26));

        CerrarS.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        CerrarS.setForeground(new java.awt.Color(51, 51, 51));
        CerrarS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/logout.png"))); // NOI18N
        CerrarS.setText("Logout");
        CerrarS.setContentAreaFilled(false);
        CerrarS.setDoubleBuffered(true);
        CerrarS.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        CerrarS.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        CerrarS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CerrarSActionPerformed(evt);
            }
        });
        jPanel3.add(CerrarS, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 0, 110, 40));

        TUser.setFont(new java.awt.Font("Roboto Black", 0, 14)); // NOI18N
        TUser.setForeground(new java.awt.Color(51, 51, 51));
        TUser.setText("Usuario");
        jPanel3.add(TUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 10, 70, 20));

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1000, 40));

        btnIngreso.setBackground(new java.awt.Color(204, 255, 255));
        btnIngreso.setFont(new java.awt.Font("Roboto Medium", 1, 14)); // NOI18N
        btnIngreso.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/eliminar (5).png"))); // NOI18N
        btnIngreso.setOpaque(true);
        btnIngreso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIngresoActionPerformed(evt);
            }
        });
        jPanel2.add(btnIngreso, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 440, -1, 60));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (desplazar.isShow()) {
            desplazar.hide();
        } else {
            desplazar.show();
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void tbRegistrosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbRegistrosMouseClicked

    }//GEN-LAST:event_tbRegistrosMouseClicked

    private void MinimizeSysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MinimizeSysActionPerformed
        // TODO add your handling code here:
        this.setExtendedState(ICONIFIED);
    }//GEN-LAST:event_MinimizeSysActionPerformed

    private void ExitSysMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseClicked

        //int Jop = JOptionPane.showConfirmDialog(null, "Salir del sistema", "Salir", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
        //if(Jop== JOptionPane.YES_OPTION){System.exit(0);} else if(Jop == JOptionPane.CANCEL_OPTION){}
    }//GEN-LAST:event_ExitSysMouseClicked

    private void ExitSysMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseEntered

    }//GEN-LAST:event_ExitSysMouseEntered

    private void ExitSysMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseExited

    }//GEN-LAST:event_ExitSysMouseExited

    private void ExitSysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitSysActionPerformed
        MessageDialog obj = new MessageDialog(this);
        obj.showMessage("Estas seguro que desea salir?", "Recuerda que puedes volver cuando quieras");

        if (obj.getMessageType() == MessageDialog.MessageType.OK) {
            this.dispose();
        } else {
            System.out.println("User click cancel");
        }
    }//GEN-LAST:event_ExitSysActionPerformed

    private void btnIngresoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIngresoActionPerformed
        int fila = tbRegistros.getSelectedRow();
        int cod = Integer.parseInt(tbRegistros.getValueAt(fila, 1).toString());
        MessageDialog obj = new MessageDialog(this);
        obj.showMessage("Confirmas que NO Ingreso", "Usted hace constar que el cliente no Hizo el respectivo ingreso al Hotel");

        if (obj.getMessageType() == MessageDialog.MessageType.OK) {

            try {

                conectarBD();
                senteciaSQL = "UPDATE reservacion SET estado='Cancelada' WHERE codReserva='" + cod + "'";
                ps = con.prepareStatement(senteciaSQL);
                ps.execute();
                con.close();
                Notification not = new Notification(this, Notification.Type.SUCCESS, Notification.Location.CENTER, "Registro Guardado con Exito");
                not.showNotification();
            } catch (SQLException ex) {
                Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No se pudo actualizar el dato " + ex);
                not.showNotification();
                System.out.println("Clases.registroAutomovil.acutualizar()" + ex);
            }
            int habitacion = 0;
            senteciaSQL = "SELECT  * FROM reservacion WHERE estado LIKE 'Cancelada' AND codReserva='" + cod + "'";
            int TipoVehiculo = 0;
            try {
                conectarBD();
                ps = con.prepareStatement(senteciaSQL);
                rs = ps.executeQuery();
                modelo = (DefaultTableModel) tbRegistros.getModel();
                while (rs.next()) {
                    habitacion = rs.getInt(5);
                    TipoVehiculo = rs.getInt(6);

                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
            }
            try {
                conectarBD();
                senteciaSQL = "UPDATE habitacion SET alquiler='Disponible' WHERE codHabitaciones='" + habitacion + "'";
                ps = con.prepareStatement(senteciaSQL);
                ps.execute();
                con.close();

            } catch (SQLException ex) {
                Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No se pudo actualizar el dato " + ex);
                not.showNotification();
            }

            Object auto = null;
            int codigo = 0;
            try {
                conectarBD();
                SenSQL = "SELECT * FROM tipoalquilervihiculo WHERE idTipo ='" + TipoVehiculo + "'";
                PS = con.prepareStatement(SenSQL);
                RS = PS.executeQuery();

                while (RS.next()) {
                    auto = RS.getString(3);
                }

                con.close();

            } catch (SQLException ex) {
                System.out.println("Error al contactar registro de habitaciones: " + ex.getMessage());
            }

            if (auto != null) {
                //*Servicio de AUTO Cuando es distinto a nulo
                codigo = Integer.parseInt(auto.toString());
                int id = 0;

                try {
                    conectarBD();
                    SenSQL = "SELECT * FROM alquilerauto WHERE idalquiler = '" + codigo + "'";
                    PS = con.prepareStatement(SenSQL);
                    RS = PS.executeQuery();

                    while (RS.next()) {
                        id = RS.getInt(4);

                    }

                    con.close();

                } catch (SQLException ex) {
                    System.out.println("Error al contactar precio de habitacion: " + ex.getMessage());
                }

                try {
                    conectarBD();
                    SenSQL = "UPDATE alquilerauto SET estado='Cancelado' WHERE idalquiler='" + codigo + "'";
                    PS = con.prepareStatement(SenSQL);

                    PS.execute();
                    con.close();

                } catch (SQLException ex) {
                    Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "Err: " + ex);
                    not.showNotification();
                }

                try {
                    conectarBD();
                    SenSQL = "UPDATE automovil SET alquiler='Disponible' WHERE idAutomovil= '" + id + "'";
                    PS = con.prepareStatement(SenSQL);

                    PS.execute();
                    con.close();

                } catch (SQLException ex) {
                    Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "Err: " + ex);
                    not.showNotification();
                }
            }
            limpiar();
            verificaciones();

        }
    }//GEN-LAST:event_btnIngresoActionPerformed


    private void CerrarSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CerrarSActionPerformed
        Login log = new Login();
        log.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_CerrarSActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        NativeInterface.open();
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CerrarS;
    private javax.swing.JButton ExitSys;
    private javax.swing.JButton MinimizeSys;
    private javax.swing.JLabel TUser;
    private javax.swing.JButton btnIngreso;
    private LIB.FSGradientPanel fSGradientPanel1;
    private LIB.FSGradientPanel fSGradientPanel2;
    private LIB.FSGradientPanel fSGradientPanel4;
    private LIB.FSGradientPanel fSGradientPanel5;
    private LIB.FSGradientPanel fSGradientPanel6;
    private LIB.FSGradientPanel fSGradientPanel7;
    private LIB.FSGradientPanel fSGradientPanel8;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JProgressBar jProgressBar2;
    private javax.swing.JProgressBar jProgressBar3;
    private javax.swing.JProgressBar jProgressBar4;
    private javax.swing.JProgressBar jProgressBar5;
    private javax.swing.JProgressBar jProgressBar6;
    private javax.swing.JProgressBar jProgressBar7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbAutoAlq;
    private javax.swing.JLabel lbAutoOcu;
    private javax.swing.JLabel lbClientes;
    private javax.swing.JLabel lbHabitacionDisp;
    private javax.swing.JLabel lbHabitacionRent;
    private javax.swing.JLabel lbIcon;
    private javax.swing.JLabel lbIcon1;
    private javax.swing.JLabel lbIcon2;
    private javax.swing.JLabel lbIcon3;
    private javax.swing.JLabel lbIcon4;
    private javax.swing.JLabel lbIcon5;
    private javax.swing.JLabel lbIcon6;
    private javax.swing.JLabel lbPer4;
    private javax.swing.JLabel lbRentasHoy;
    private javax.swing.JLabel lbValues4;
    private javax.swing.JLabel lbclientes;
    private javax.swing.JLabel lbclientes1;
    private javax.swing.JLabel lbclientes2;
    private javax.swing.JLabel lbclientes3;
    private javax.swing.JLabel lbclientes4;
    private javax.swing.JLabel lbclientes5;
    private javax.swing.JLabel lbclientes6;
    private javax.swing.JLabel lblFoto;
    private javax.swing.JProgressBar prgHabitaciones;
    private javax.swing.JTable tbRegistros;
    // End of variables declaration//GEN-END:variables
}
