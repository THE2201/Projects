
package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class conexionBD {
    Connection c=null;
    public conexionBD(String bd)
    {
        try {
            //DRIVER
            Class.forName("com.mysql.jdbc.Driver");
            //Definimos la BD
            String url="jdbc:mysql://localhost/"+bd;
            String user="root",pass="";
            //Conectamos la BD
            c=DriverManager.getConnection(url,user,pass);
            
        }catch(ClassNotFoundException ex) {
        }catch(SQLException ex) {
            System.out.print("No se Pudo conectar "+ex.getMessage());
        }
    }
    public Connection getConexion()
    {
        return c;
    }
    public static void main (String args[])
    {
        new conexionBD("proyecto_final");
    }
}
