package Clases;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Icon;
import javax.swing.JMenuItem;
import Conexion.conexionBD;
import java.awt.Font;
import Componentes.Notification;
import Componentes.MessageDialog;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.awt.Color;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import proyecto_final.Login;
import proyecto_final.MenuPrincipal;
import static proyecto_final.MenuPrincipal.Usuario;

public class menuHabitaciones extends javax.swing.JFrame {

    String usuario;
    String cod;
    private FileInputStream fis;
    private int longitudBytes;
    Connection con = null;
    conexionBD conecta;
    String senteciaSQL;
    PreparedStatement ps = null;
    ResultSet rs = null;
    DefaultTableModel modelo;
    Object datosHabitacion[] = new Object[5];
    TableRowSorter<TableModel> trsCliente;

    String[] titHabitacion = {"Codigo", "Categoria", "Descripcion", "Capacidad", "Precio"};
    int codigo = 0;
    String[][] datosHabitacionB;

    public menuHabitaciones() {
        initComponents();
        popumMenu();
        this.setLocationRelativeTo(null);
        diseñotabla();
    }

    public void conectarBD() {
        conecta = new conexionBD("proyecto_final");
        con = conecta.getConexion();
    }

    public void popumMenu() {
        JMenuItem open = new JMenuItem("Crear", getIcon("/img/crear.png", 25, 25));
        JMenuItem update = new JMenuItem("Actualizar", getIcon("/img/actualizar.png", 25, 25));
        JMenuItem delete = new JMenuItem("Eliminar", getIcon("/img/borrar.png", 25, 25));

        tbHabitaciones.setComponentPopupMenu(tableAutomovil);

        tableAutomovil.add(open);
        tableAutomovil.addSeparator();
        tableAutomovil.add(update);
        tableAutomovil.addSeparator();
        tableAutomovil.add(delete);
        tableAutomovil.addSeparator();

        open.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                registroHabitaciones.NUM = 1;
                registroHabitaciones.idHabitacion = "";
                registroHabitaciones.categoria = "";
                registroHabitaciones.descripcion = "";
                registroHabitaciones.capacidad = "";
                registroHabitaciones.precio = "";
                limpiar();
                llamar(1);

            }
        });
        update.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int fila = tbHabitaciones.getSelectedRow();
                if (fila >= 0) {
                    registroHabitaciones.NUM = 2;
                    fila = tbHabitaciones.getSelectedRow();
                    registroHabitaciones.idHabitacion = (tbHabitaciones.getValueAt(fila, 0).toString());
                    registroHabitaciones.categoria = (tbHabitaciones.getValueAt(fila, 1).toString());
                    registroHabitaciones.descripcion = (tbHabitaciones.getValueAt(fila, 2).toString());
                    registroHabitaciones.capacidad = (tbHabitaciones.getValueAt(fila, 3).toString());
                    registroHabitaciones.precio = (tbHabitaciones.getValueAt(fila, 4).toString());
                    limpiar();
                    llamar(1);
                } else {
                    notificacion();
                }
            }
        });

        delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                int fila = tbHabitaciones.getSelectedRow();
                if (fila >= 0) {
                    llamarConfirmacion();
                } else {
                    notificacion();
                }
            }
        });

    }

    public void notificacion() {
        Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.CENTER, "Debe Seleccionar Almenos un Dato en la Tabla Automovil");
        not.showNotification();
    }

    public void centrarTabla() {
        DefaultTableCellRenderer tcr = new DefaultTableCellRenderer();
        tcr.setHorizontalAlignment(SwingConstants.CENTER);
        tbHabitaciones.getColumnModel().getColumn(0).setCellRenderer(tcr);
        tbHabitaciones.getColumnModel().getColumn(1).setCellRenderer(tcr);
        tbHabitaciones.getColumnModel().getColumn(2).setCellRenderer(tcr);
        tbHabitaciones.getColumnModel().getColumn(3).setCellRenderer(tcr);
        tbHabitaciones.getColumnModel().getColumn(4).setCellRenderer(tcr);
        tbHabitaciones.getColumnModel().getColumn(5).setCellRenderer(tcr);
        tbHabitaciones.getColumnModel().getColumn(6).setCellRenderer(tcr);

        ((DefaultTableCellRenderer) tbHabitaciones.getTableHeader().getDefaultRenderer())
                .setHorizontalAlignment(SwingConstants.CENTER);
    }

    public void diseñotabla() {
        tbHabitaciones.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tbHabitaciones.getTableHeader().setOpaque(false);
        tbHabitaciones.getTableHeader().setBackground(new Color(32, 136, 203));
        tbHabitaciones.getTableHeader().setForeground(new Color(255, 255, 255));
        tbHabitaciones.setRowHeight(25);
    }

    public void limpiar() {
        int fila = tbHabitaciones.getRowCount();
        for (int i = fila - 1; i >= 0; i--) {
            modelo.removeRow(i);
            lblFoto.setIcon(null);
        }
        txtBuscarHabitacion.setText(null);
    }

    public void llamarConfirmacion() {
        MessageDialog obj = new MessageDialog(this);
        obj.showMessage("Estas seguro?", "Recuerda una vez eliminado no hay marcha atras");

        if (obj.getMessageType() == MessageDialog.MessageType.OK) {
            int fila = tbHabitaciones.getSelectedRow();
            System.out.println(tbHabitaciones.getValueAt(fila, 0).toString());
            try {
                conectarBD();
                //senteciaSQL = "DELETE FROM empleado WHERE identidad=" +txtCodigo.getText().trim();
                senteciaSQL = "UPDATE habitacion SET estado='Inactivo' WHERE codHabitaciones LIKE  '" + tbHabitaciones.getValueAt(fila, 0).toString() + "'";
                ps = con.prepareStatement(senteciaSQL);
                ps.execute();
                con.close();
                Notification not = new Notification(this, Notification.Type.SUCCESS, Notification.Location.TOP_CENTER, "Datos Eliminados Correctamente ");
                not.showNotification();
                limpiar();
                leerHabitacion();
                System.out.println(tbHabitaciones.getValueAt(fila, 0).toString());

            } catch (SQLException ex) {
                Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No se pudieron eliminar los datos " + ex);
                not.showNotification();
            }
        }

    }

    public void llamar(int num) {
        if (num == 1) {
            registroHabitaciones em = new registroHabitaciones();
            em.setVisible(true);
        }
    }

    public void cargar() throws IOException {
        try {
            String COD = Integer.toString(codigo);
            ImageIcon foto;
            InputStream is;

            senteciaSQL = "SELECT * FROM habitacion WHERE codHabitaciones LIKE '" + COD + "'";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(senteciaSQL);

            if (rs.next()) {
                is = rs.getBinaryStream("FOTO");

                BufferedImage bi = ImageIO.read(is);
                foto = new ImageIcon(bi);

                Image img = foto.getImage();
                Image newimg = img.getScaledInstance(lblFoto.getWidth(), lblFoto.getHeight(), Image.SCALE_REPLICATE);

                ImageIcon newcon = new ImageIcon(newimg);

                lblFoto.setIcon(newcon);
            } else {
                JOptionPane.showMessageDialog(null, "REGISTRO NO ENCONTRADO", "INFORMACION", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void leerHabitacion() {
        conectarBD();
        senteciaSQL = "SELECT * FROM habitacion WHERE estado LIKE 'Activa' AND alquiler LIKE 'Disponible' ";
        try {
            ps = con.prepareStatement(senteciaSQL);
            rs = ps.executeQuery();
            modelo = (DefaultTableModel) tbHabitaciones.getModel();
            while (rs.next()) {
                datosHabitacion[0] = (rs.getInt(1));
                datosHabitacion[1] = (rs.getString(2));
                datosHabitacion[2] = (rs.getString(3));
                datosHabitacion[3] = (rs.getString(5));
                datosHabitacion[4] = (rs.getDouble(6));
                modelo.addRow(datosHabitacion);
            }
            tbHabitaciones.setModel(modelo);
            //con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
        }

    }

    public Icon getIcon(String ruta, int widht, int height) {
        Icon icono = new ImageIcon(new ImageIcon(getClass().getResource(ruta)).getImage().getScaledInstance(widht, height, 0));
        return icono;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tableAutomovil = new javax.swing.JPopupMenu();
        jPanel2 = new javax.swing.JPanel();
        lblFoto = new javax.swing.JLabel();
        cbxHabitacion = new javax.swing.JComboBox<>();
        txtBuscarHabitacion = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbHabitaciones = new javax.swing.JTable();
        btnleer = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        btnLimpiar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        PUpper = new java.awt.Panel();
        ExitSys = new javax.swing.JButton();
        MinimizeSys = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        btnCrear = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 255), 10));
        jPanel2.setLayout(null);

        lblFoto.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel2.add(lblFoto);
        lblFoto.setBounds(740, 260, 240, 220);

        cbxHabitacion.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        cbxHabitacion.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Numero" }));
        jPanel2.add(cbxHabitacion);
        cbxHabitacion.setBounds(440, 180, 180, 30);

        txtBuscarHabitacion.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        txtBuscarHabitacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBuscarHabitacionActionPerformed(evt);
            }
        });
        txtBuscarHabitacion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarHabitacionKeyReleased(evt);
            }
        });
        jPanel2.add(txtBuscarHabitacion);
        txtBuscarHabitacion.setBounds(150, 180, 280, 30);

        tbHabitaciones.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        tbHabitaciones.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo", "Categoria", "Descripcion", "Capacidad", "Precio"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tbHabitaciones.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tbHabitaciones.setGridColor(new java.awt.Color(204, 204, 204));
        tbHabitaciones.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbHabitacionesMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                tbHabitacionesMouseExited(evt);
            }
        });
        jScrollPane1.setViewportView(tbHabitaciones);

        jPanel2.add(jScrollPane1);
        jScrollPane1.setBounds(20, 230, 710, 440);

        btnleer.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        btnleer.setForeground(new java.awt.Color(102, 102, 255));
        btnleer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/leer (3).png"))); // NOI18N
        btnleer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnleerMouseClicked(evt);
            }
        });
        btnleer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnleerActionPerformed(evt);
            }
        });
        jPanel2.add(btnleer);
        btnleer.setBounds(630, 170, 50, 50);

        btnActualizar.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        btnActualizar.setForeground(new java.awt.Color(102, 102, 255));
        btnActualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/actualizar (6).png"))); // NOI18N
        btnActualizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnActualizarMouseClicked(evt);
            }
        });
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });
        jPanel2.add(btnActualizar);
        btnActualizar.setBounds(750, 170, 50, 50);

        jLabel3.setFont(new java.awt.Font("Bodoni Bd BT", 0, 24)); // NOI18N
        jLabel3.setText("Buscar");
        jPanel2.add(jLabel3);
        jLabel3.setBounds(70, 180, 75, 20);

        jLabel1.setFont(new java.awt.Font("Corbel", 1, 36)); // NOI18N
        jLabel1.setText("REGISTROS DE HABITACIONES");
        jPanel2.add(jLabel1);
        jLabel1.setBounds(240, 90, 540, 60);

        btnLimpiar.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        btnLimpiar.setForeground(new java.awt.Color(102, 102, 255));
        btnLimpiar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/borrar2.png"))); // NOI18N
        btnLimpiar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnLimpiarMouseClicked(evt);
            }
        });
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });
        jPanel2.add(btnLimpiar);
        btnLimpiar.setBounds(870, 170, 50, 50);

        btnEliminar.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        btnEliminar.setForeground(new java.awt.Color(102, 102, 255));
        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/eliminar (1).png"))); // NOI18N
        btnEliminar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEliminarMouseClicked(evt);
            }
        });
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        jPanel2.add(btnEliminar);
        btnEliminar.setBounds(810, 170, 50, 50);

        jLabel5.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        jLabel5.setText("IMAGEN");
        jPanel2.add(jLabel5);
        jLabel5.setBounds(840, 240, 50, 16);

        PUpper.setBackground(new java.awt.Color(0, 153, 255));
        PUpper.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PUpperMousePressed(evt);
            }
        });
        PUpper.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                PUpperMouseDragged(evt);
            }
        });
        PUpper.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ExitSys.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/BClose.png"))); // NOI18N
        ExitSys.setContentAreaFilled(false);
        ExitSys.setPreferredSize(new java.awt.Dimension(30, 30));
        ExitSys.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExitSysMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ExitSysMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ExitSysMouseExited(evt);
            }
        });
        ExitSys.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitSysActionPerformed(evt);
            }
        });
        PUpper.add(ExitSys, new org.netbeans.lib.awtextra.AbsoluteConstraints(958, 7, 32, 26));

        MinimizeSys.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/BMin.png"))); // NOI18N
        MinimizeSys.setContentAreaFilled(false);
        MinimizeSys.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MinimizeSysActionPerformed(evt);
            }
        });
        PUpper.add(MinimizeSys, new org.netbeans.lib.awtextra.AbsoluteConstraints(921, 7, 30, 26));

        jLabel20.setFont(new java.awt.Font("Roboto Black", 0, 20)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Software Hotel");
        PUpper.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 7, 191, -1));
        PUpper.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(4, 13, -1, 26));
        PUpper.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 13, -1, 26));
        PUpper.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/LogIc.png"))); // NOI18N
        PUpper.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 7, 30, 30));

        jPanel2.add(PUpper);
        PUpper.setBounds(0, 0, 1000, 40);

        btnCrear.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        btnCrear.setForeground(new java.awt.Color(102, 102, 255));
        btnCrear.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/crear2.png"))); // NOI18N
        btnCrear.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnCrearMouseClicked(evt);
            }
        });
        btnCrear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCrearActionPerformed(evt);
            }
        });
        jPanel2.add(btnCrear);
        btnCrear.setBounds(690, 170, 50, 50);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 1000, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 742, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tbHabitacionesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbHabitacionesMouseClicked
        int fila = tbHabitaciones.getSelectedRow();
        codigo = Integer.parseInt(tbHabitaciones.getValueAt(fila, 0).toString());
        try {
            cargar();
        } catch (IOException ex) {
            Logger.getLogger(menuHabitaciones.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_tbHabitacionesMouseClicked

    private void txtBuscarHabitacionKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarHabitacionKeyReleased
        TableRowSorter<TableModel> trsCliente;
        int valor = 0;
        int conta = 0;
        String nomconsulta = cbxHabitacion.getSelectedItem().toString();

        String aux = "" + txtBuscarHabitacion.getText();
        try {
            conectarBD();
            if (nomconsulta.equals("Numero")) {
                senteciaSQL = ("SELECT COUNT(*) FROM habitacion WHERE UPPER(codHabitaciones) LIKE (UPPER('%" + txtBuscarHabitacion.getText() + "%'))  AND alquiler LIKE 'Disponible' AND estado LIKE 'Activa'");
                ps = con.prepareStatement(senteciaSQL);
                rs = ps.executeQuery();
            }

            if (rs.next()) {
                valor = rs.getInt(1);
            }

            datosHabitacionB = new String[valor][8];
            if (nomconsulta.equals("Numero")) {
                senteciaSQL = ("SELECT * FROM habitacion WHERE  UPPER(marca) LIKE (UPPER('%" + txtBuscarHabitacion.getText() + "%'))  AND alquiler LIKE 'Disponible' AND estado LIKE 'Activa'");
                ps = con.prepareStatement(senteciaSQL);
                rs = ps.executeQuery();
            }
            while (rs.next()) {
                datosHabitacionB[conta][0] = rs.getString("codHabitaciones");
                datosHabitacionB[conta][1] = rs.getString("marca");
                datosHabitacionB[conta][2] = rs.getString("modelo");
                datosHabitacionB[conta][3] = rs.getString("anio");
                datosHabitacionB[conta][4] = rs.getString("tipo");
                conta = conta + 1;
            }
            modelo = new DefaultTableModel(datosHabitacionB, titHabitacion) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            tbHabitaciones.setModel(modelo);
            trsCliente = new TableRowSorter<>(modelo);
            tbHabitaciones.setRowSorter(trsCliente);

        } catch (Exception e) {
        }
    }//GEN-LAST:event_txtBuscarHabitacionKeyReleased

    private void ExitSysMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseClicked

        //int Jop = JOptionPane.showConfirmDialog(null, "Salir del sistema", "Salir", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
        //if(Jop== JOptionPane.YES_OPTION){System.exit(0);} else if(Jop == JOptionPane.CANCEL_OPTION){}
    }//GEN-LAST:event_ExitSysMouseClicked

    private void ExitSysMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseEntered

    }//GEN-LAST:event_ExitSysMouseEntered

    private void ExitSysMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseExited

    }//GEN-LAST:event_ExitSysMouseExited

    private void ExitSysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitSysActionPerformed
        MessageDialog obj = new MessageDialog(this);
        obj.showMessage("Estas seguro que desea salir?", "Recuerda que puedes volver cuando quieras");

        if (obj.getMessageType() == MessageDialog.MessageType.OK) {
            this.dispose();           
        }
    }//GEN-LAST:event_ExitSysActionPerformed

    private void MinimizeSysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MinimizeSysActionPerformed
        // TODO add your handling code here:
        this.setExtendedState(ICONIFIED);
    }//GEN-LAST:event_MinimizeSysActionPerformed

    private void PUpperMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMousePressed
        // TODO add your handling code here:
        //        xMouse = evt.getX();
        //        yMouse = evt.getY();
    }//GEN-LAST:event_PUpperMousePressed

    private void PUpperMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMouseDragged
        // TODO add your handling code here
        //        int x = evt.getXOnScreen();
        //        int y = evt.getYOnScreen();
        //        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_PUpperMouseDragged

    private void btnLimpiarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLimpiarMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnLimpiarMouseClicked

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        limpiar();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnEliminarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliminarMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnEliminarMouseClicked

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int fila = tbHabitaciones.getSelectedRow();
        if (fila >= 0) {
            llamarConfirmacion();
        } else {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.CENTER, "Debe Seleccionar Almenos un Dato en la Tabla Automovil");
            not.showNotification();
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnleerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnleerMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnleerMouseClicked

    private void btnleerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnleerActionPerformed
        leerHabitacion();
    }//GEN-LAST:event_btnleerActionPerformed

    private void btnActualizarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnActualizarMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnActualizarMouseClicked

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
        int fila = tbHabitaciones.getSelectedRow();
        if (fila >= 0) {
            registroHabitaciones.NUM = 2;
            fila = tbHabitaciones.getSelectedRow();
            registroHabitaciones.idHabitacion = (tbHabitaciones.getValueAt(fila, 0).toString());
            registroHabitaciones.categoria = (tbHabitaciones.getValueAt(fila, 1).toString());
            registroHabitaciones.descripcion = (tbHabitaciones.getValueAt(fila, 2).toString());
            registroHabitaciones.capacidad = (tbHabitaciones.getValueAt(fila, 3).toString());
            registroHabitaciones.precio = (tbHabitaciones.getValueAt(fila, 4).toString());
            limpiar();
            llamar(1);
        } else {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.CENTER, "Debe Seleccionar Almenos un Dato en la Tabla Automovil");
            not.showNotification();
        }

    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnCrearMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCrearMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCrearMouseClicked

    private void btnCrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearActionPerformed

        registroHabitaciones.NUM = 1;
        registroHabitaciones.idHabitacion = "";
        registroHabitaciones.categoria = "";
        registroHabitaciones.descripcion = "";
        registroHabitaciones.capacidad = "";
        registroHabitaciones.precio = "";
        limpiar();
        llamar(1);


    }//GEN-LAST:event_btnCrearActionPerformed

    private void tbHabitacionesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbHabitacionesMouseExited
        lblFoto.setIcon(null);
    }//GEN-LAST:event_tbHabitacionesMouseExited

    private void txtBuscarHabitacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBuscarHabitacionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBuscarHabitacionActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(menuHabitaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(menuHabitaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(menuHabitaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(menuHabitaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menuHabitaciones().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ExitSys;
    private javax.swing.JButton MinimizeSys;
    private java.awt.Panel PUpper;
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnCrear;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnleer;
    private javax.swing.JComboBox<String> cbxHabitacion;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblFoto;
    private javax.swing.JPopupMenu tableAutomovil;
    private javax.swing.JTable tbHabitaciones;
    private javax.swing.JTextField txtBuscarHabitacion;
    // End of variables declaration//GEN-END:variables
}
