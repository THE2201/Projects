package Clases;

import Conexion.conexionBD;
import java.awt.Color;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import Componentes.Notification;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

public class registroEmpleado extends javax.swing.JFrame {

    public static String id;
    public static String edad;
    public static String Nombre;
    public static String Apellido;
    public static String Dirreccion;
    public static String Telefono;
    public static String Discapacidad;
    public static String Cargo;
    public static int NUM;

    String usuario;
    Connection con = null;
    conexionBD conecta;
    String senteciaSQL;
    PreparedStatement ps = null;
    private FileInputStream fis;
    private int longitudBytes;
    ResultSet rs = null;
    int centi = 0;
    DefaultTableModel modelo;
    Object datosEmpleados[] = new Object[8];
    private String Ruta = "";
    byte[] img;
    byte[] imagen;


    public registroEmpleado() {
        initComponents();
        txtCodigo.requestFocus();
        this.setLocationRelativeTo(null);
        txtCodigo.setText(id);
        txtNombre.setText(Nombre);
        txtEdad.setText(edad);
        txtApellido.setText(Apellido);
        txtDireccion.setText(Dirreccion);
        txtTel.setText(Telefono);
        comboCargo.setSelectedItem(Cargo);
        if (NUM == 2) {
            mostrarfoto();
        }

    }

    public void crearEmpleado() {

        String tipo = "";

        if (comboCargo.getSelectedIndex() == 0) {

            JOptionPane.showMessageDialog(null, "Seleccione el Cargo que dispondra");

        } else if (comboCargo.getSelectedIndex() == 1) {

            tipo = "Recepcionista";
            consultainsert(tipo);

        } else if (comboCargo.getSelectedIndex() == 2) {

            tipo = "Supervisor";
            consultainsert(tipo);

        } else if (comboCargo.getSelectedIndex() == 3) {

            tipo = "Conserje";
            consultainsert(tipo);

        } else if (comboCargo.getSelectedIndex() == 4) {

            tipo = "Agente de limpieza";
            consultainsert(tipo);

        } else if (comboCargo.getSelectedIndex() == 5) {

            tipo = "Administrador";
            consultainsert(tipo);

        } 

        this.setLocationRelativeTo(null);
    }

    public void consultainsert(String tipo) {
        try {

            conectarBD();
            senteciaSQL = "INSERT INTO empleado (identidad,edad,nombre,apellido,direccion,telefono,cargo,foto,estado) VALUES(?,?,?,?,?,?,?,?,?)";
            ps = con.prepareStatement(senteciaSQL);
            ps.setString(1, txtCodigo.getText());
            ps.setString(2, txtEdad.getText());
            ps.setString(3, txtNombre.getText());
            ps.setString(4, txtApellido.getText());
            ps.setString(5, txtDireccion.getText());
            ps.setString(6, txtTel.getText());
            ps.setString(7, tipo);
            ps.setBinaryStream(8, fis, longitudBytes);
            ps.setString(9, "Activo");
            ps.execute();
            con.close();
            Notification not = new Notification(this, Notification.Type.SUCCESS, Notification.Location.TOP_CENTER, "Datos de Empleados Guardados Correctamente");
            not.showNotification();
        } catch (SQLException ex) {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No Se pudo Crear el Empleado " + ex);
            not.showNotification();
        }

    }

    public void conectarBD() {
        conecta = new conexionBD("proyecto_final");
        con = conecta.getConexion();
    }

    public void agregarfoto() {
        conectarBD();
        lblFoto.setIcon(null);
        JFileChooser j = new JFileChooser();
        j.setFileSelectionMode(JFileChooser.FILES_ONLY);
        int estado = j.showOpenDialog(null);

        if (estado == JFileChooser.APPROVE_OPTION) {

            try {
                fis = new FileInputStream(j.getSelectedFile());
                this.longitudBytes = (int) j.getSelectedFile().length();
                try {
                    Image icono = ImageIO.read(j.getSelectedFile()).getScaledInstance(lblFoto.getWidth(), lblFoto.getHeight(), Image.SCALE_DEFAULT);

                    lblFoto.setIcon(new ImageIcon(icono));
                    lblFoto.updateUI();
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(rootPane, "imagen: " + ex);
                }
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            }
            centi = 1;
        }
    }

    public void mostrarfoto() {
        conectarBD();
        try {
            cargar();
        } catch (IOException ex) {
            Logger.getLogger(registroChofer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void cargar() throws IOException {
        try {

            ImageIcon foto;
            InputStream is;

            senteciaSQL = "SELECT * FROM empleado WHERE identidad LIKE '" + id + "'";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(senteciaSQL);

            if (rs.next()) {
                is = rs.getBinaryStream("FOTO");

                BufferedImage bi = ImageIO.read(is);
                foto = new ImageIcon(bi);

                Image img = foto.getImage();
                Image newimg = img.getScaledInstance(lblFoto.getWidth(), lblFoto.getHeight(), Image.SCALE_REPLICATE);

                ImageIcon newcon = new ImageIcon(newimg);

                lblFoto.setIcon(newcon);
            } else {
                JOptionPane.showMessageDialog(null, "REGISTRO NO ENCONTRADO", "INFORMACION", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void actualizarEmpleado() {

        String tipo = "";

        if (comboCargo.getSelectedIndex() == 0) {

            JOptionPane.showMessageDialog(null, "Seleccione el Cargo que dispondra");

        } else if (comboCargo.getSelectedIndex() == 1) {

            tipo = "Recepcionista";
            consultaacutualizar(tipo);

        } else if (comboCargo.getSelectedIndex() == 2) {

            tipo = "Supervisor";
            consultaacutualizar(tipo);

        } else if (comboCargo.getSelectedIndex() == 3) {

            tipo = "Conserje";
            consultaacutualizar(tipo);

        } else if (comboCargo.getSelectedIndex() == 4) {

            tipo = "Agente de limpieza";
            consultaacutualizar(tipo);

        } else if (comboCargo.getSelectedIndex() == 5) {

            tipo = "Administrador";
            consultaacutualizar(tipo);

        }

        this.setLocationRelativeTo(null);
    }

    public void consultaacutualizar(String tipo) {
        if (centi == 1) {
            try {
                conectarBD();
                senteciaSQL = "UPDATE empleado SET edad=?,nombre=?,apellido=?,direccion=?,telefono=?,cargo=? , foto=? WHERE identidad=?";
                ps = con.prepareStatement(senteciaSQL);
                ps.setString(1, txtEdad.getText());
                ps.setString(2, txtNombre.getText());
                ps.setString(3, txtApellido.getText());
                ps.setString(4, txtDireccion.getText());
                ps.setString(5, txtTel.getText());
                ps.setString(6, tipo);
                ps.setBinaryStream(7, fis, longitudBytes);
                ps.setString(8, txtCodigo.getText());
                ps.execute();
                con.close();
                Notification not = new Notification(this, Notification.Type.INFO, Notification.Location.TOP_CENTER, "Datos Actualizados Correctamente");
                not.showNotification();
            } catch (SQLException ex) {
                Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No se pudo actualizar el dato " + ex);
                not.showNotification();
            }
        } else {
            try {
                conectarBD();
                senteciaSQL = "UPDATE empleado SET edad=?,nombre=?,apellido=?,direccion=?,telefono=?,cargo=? WHERE identidad=?";
                ps = con.prepareStatement(senteciaSQL);
                ps.setString(1, txtEdad.getText());
                ps.setString(2, txtNombre.getText());
                ps.setString(3, txtApellido.getText());
                ps.setString(4, txtDireccion.getText());
                ps.setString(5, txtTel.getText());
                ps.setString(6, tipo);
                ps.setString(7, txtCodigo.getText());
                ps.execute();
                con.close();
                Notification not = new Notification(this, Notification.Type.INFO, Notification.Location.TOP_CENTER, "Datos Actualizados Correctamente");
                not.showNotification();
            } catch (SQLException ex) {
                Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No se pudo actualizar el dato " + ex);
                not.showNotification();
            }
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtEdad = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        txtApellido = new javax.swing.JTextField();
        txtDireccion = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtTel = new javax.swing.JFormattedTextField();
        comboCargo = new javax.swing.JComboBox<>();
        txtCodigo = new javax.swing.JFormattedTextField();
        jButton5 = new javax.swing.JButton();
        PUpper = new java.awt.Panel();
        ExitSys = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        imgmostrar = new javax.swing.JLabel();
        lblFoto = new javax.swing.JLabel();
        btnFoto = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 5));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(null);

        jLabel2.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel2.setText("Cargo");
        jPanel2.add(jLabel2);
        jLabel2.setBounds(10, 270, 60, 30);

        jLabel3.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel3.setText("Identidad");
        jPanel2.add(jLabel3);
        jLabel3.setBounds(0, 20, 80, 30);

        jLabel4.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel4.setText("Edad");
        jPanel2.add(jLabel4);
        jLabel4.setBounds(0, 140, 70, 30);

        jLabel5.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel5.setText("Nombre");
        jPanel2.add(jLabel5);
        jLabel5.setBounds(0, 60, 70, 30);

        jLabel6.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel6.setText("Apellido");
        jPanel2.add(jLabel6);
        jLabel6.setBounds(0, 100, 70, 30);

        jLabel7.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel7.setText("Dirreccion");
        jPanel2.add(jLabel7);
        jLabel7.setBounds(0, 180, 80, 30);

        txtEdad.setFont(new java.awt.Font("Roboto Light", 1, 16)); // NOI18N
        jPanel2.add(txtEdad);
        txtEdad.setBounds(90, 140, 250, 30);

        txtNombre.setFont(new java.awt.Font("Roboto Light", 1, 16)); // NOI18N
        jPanel2.add(txtNombre);
        txtNombre.setBounds(90, 60, 250, 30);

        txtApellido.setFont(new java.awt.Font("Roboto Light", 1, 16)); // NOI18N
        jPanel2.add(txtApellido);
        txtApellido.setBounds(90, 100, 250, 30);

        txtDireccion.setFont(new java.awt.Font("Roboto Light", 1, 16)); // NOI18N
        jPanel2.add(txtDireccion);
        txtDireccion.setBounds(90, 180, 250, 30);

        jLabel8.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel8.setText("Telefono");
        jPanel2.add(jLabel8);
        jLabel8.setBounds(0, 230, 80, 30);

        try {
            txtTel.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("(+504) #### - ####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtTel.setFont(new java.awt.Font("Roboto Light", 0, 16)); // NOI18N
        jPanel2.add(txtTel);
        txtTel.setBounds(90, 230, 250, 30);

        comboCargo.setFont(new java.awt.Font("Roboto Light", 0, 16)); // NOI18N
        comboCargo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione", "Recepcionista", "Supervisor", "Conserje", "Agente de limpieza", "Administrador" }));
        jPanel2.add(comboCargo);
        comboCargo.setBounds(90, 270, 250, 25);

        try {
            txtCodigo.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("#### - #### - #####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtCodigo.setFont(new java.awt.Font("Roboto Light", 0, 16)); // NOI18N
        jPanel2.add(txtCodigo);
        txtCodigo.setBounds(90, 20, 250, 30);

        jPanel1.add(jPanel2);
        jPanel2.setBounds(20, 50, 360, 310);

        jButton5.setBackground(new java.awt.Color(0, 255, 153));
        jButton5.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(102, 102, 255));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/guardar (2).png"))); // NOI18N
        jButton5.setText("GUARDAR");
        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton5MouseClicked(evt);
            }
        });
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton5);
        jButton5.setBounds(220, 370, 220, 50);

        PUpper.setBackground(new java.awt.Color(0, 102, 102));
        PUpper.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PUpperMousePressed(evt);
            }
        });
        PUpper.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                PUpperMouseDragged(evt);
            }
        });
        PUpper.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ExitSys.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/BClose.png"))); // NOI18N
        ExitSys.setContentAreaFilled(false);
        ExitSys.setPreferredSize(new java.awt.Dimension(30, 30));
        ExitSys.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExitSysMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ExitSysMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ExitSysMouseExited(evt);
            }
        });
        ExitSys.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitSysActionPerformed(evt);
            }
        });
        PUpper.add(ExitSys, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 10, 32, 26));

        jLabel20.setFont(new java.awt.Font("Roboto Black", 1, 20)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Registro Empleado");
        PUpper.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 5, 191, -1));
        PUpper.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(4, 13, -1, 26));
        PUpper.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 13, -1, 26));
        PUpper.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/LogIc.png"))); // NOI18N
        PUpper.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 5, 30, 30));

        jPanel1.add(PUpper);
        PUpper.setBounds(0, 0, 650, 39);
        jPanel1.add(imgmostrar);
        imgmostrar.setBounds(150, 356, 110, 30);

        lblFoto.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.add(lblFoto);
        lblFoto.setBounds(410, 70, 180, 130);

        btnFoto.setBackground(new java.awt.Color(0, 204, 204));
        btnFoto.setForeground(new java.awt.Color(0, 51, 102));
        btnFoto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/agregarfoto (1).png"))); // NOI18N
        btnFoto.setText("Agregar Foto");
        btnFoto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnFotoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnFotoMouseExited(evt);
            }
        });
        btnFoto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFotoActionPerformed(evt);
            }
        });
        jPanel1.add(btnFoto);
        btnFoto.setBounds(410, 210, 180, 50);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 655, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 458, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void PUpperMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMouseDragged
        // TODO add your handling code here
        //        int x = evt.getXOnScreen();
        //        int y = evt.getYOnScreen();
        //        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_PUpperMouseDragged

    private void PUpperMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMousePressed
        // TODO add your handling code here:
        //        xMouse = evt.getX();
        //        yMouse = evt.getY();
    }//GEN-LAST:event_PUpperMousePressed

    private void ExitSysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitSysActionPerformed

        this.dispose();

    }//GEN-LAST:event_ExitSysActionPerformed

    private void ExitSysMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseExited

    }//GEN-LAST:event_ExitSysMouseExited

    private void ExitSysMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseEntered

    }//GEN-LAST:event_ExitSysMouseEntered

    private void ExitSysMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseClicked

        //int Jop = JOptionPane.showConfirmDialog(null, "Salir del sistema", "Salir", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
        //if(Jop== JOptionPane.YES_OPTION){System.exit(0);} else if(Jop == JOptionPane.CANCEL_OPTION){}
    }//GEN-LAST:event_ExitSysMouseClicked

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        if (txtCodigo.getText().equals("     -      -      ") || txtTel.getText().equals("(+504)      -     ") || txtCodigo.getText().isEmpty() || txtNombre.getText().isEmpty() || txtDireccion.getText().isEmpty() || txtApellido.getText().isEmpty() || txtEdad.getText().isEmpty() || txtTel.getText().isEmpty() || comboCargo.getSelectedIndex() == 0 || lblFoto.getIcon() == null) {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "Datos Incompletos, Favor llenar todos los campos");
            not.showNotification();
        } else {
            if (NUM == 1) {
                crearEmpleado();
                this.dispose();
            } else if (NUM == 2) {
                actualizarEmpleado();
                this.dispose();
            }
        }

    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5MouseClicked

    private void btnFotoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFotoMouseEntered

    }//GEN-LAST:event_btnFotoMouseEntered

    private void btnFotoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFotoMouseExited

    }//GEN-LAST:event_btnFotoMouseExited

    private void btnFotoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFotoActionPerformed
        agregarfoto();
    }//GEN-LAST:event_btnFotoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(registroEmpleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(registroEmpleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(registroEmpleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(registroEmpleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new registroEmpleado().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ExitSys;
    private java.awt.Panel PUpper;
    private javax.swing.JButton btnFoto;
    private javax.swing.JComboBox<String> comboCargo;
    private javax.swing.JLabel imgmostrar;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lblFoto;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JFormattedTextField txtCodigo;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtEdad;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JFormattedTextField txtTel;
    // End of variables declaration//GEN-END:variables
}
