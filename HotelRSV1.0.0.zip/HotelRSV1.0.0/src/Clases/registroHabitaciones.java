package Clases;

import Conexion.conexionBD;
import java.awt.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import Componentes.Notification;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Statement;

public class registroHabitaciones extends javax.swing.JFrame {

    public static String idHabitacion;
    public static String categoria;
    public static String descripcion;
    public static String capacidad;
    public static String precio;
    public static int NUM;

    private FileInputStream fis;
    private int longitudBytes;

    String usuario;
    String cod;
    Connection con = null;
    conexionBD conecta;
    String senteciaSQL;
    PreparedStatement ps = null;

    ResultSet rs = null;
    DefaultTableModel modelo;
    Object datosEmpleados[] = new Object[8];

    public registroHabitaciones() {
        initComponents();
        txtCodigo.requestFocus();
        this.setLocationRelativeTo(null);
        txtCodigo.setText(idHabitacion);
        cbxCategoria.setSelectedItem(categoria);
        txtdescripcion.setText(descripcion);
        txtCapacidad.setText(capacidad);
        txtprecio.setText(precio);
        txtCodigo.setEditable(false);
        if (NUM == 1) {
            txtCodigo.setText("0");
        } else if(NUM==2){
            cargarfoto();
        }
    }

    public void conectarBD() {
        conecta = new conexionBD("proyecto_final");
        con = conecta.getConexion();
    }
    public void InsertarHabitaciones() {

        String tipo;
        if (cbxCategoria.getSelectedIndex() == 0) {

            JOptionPane.showMessageDialog(null, "Seleccione la categoria");

        } else if (cbxCategoria.getSelectedIndex() == 1) {

            tipo = "Suite";
            agregarHabitaciones(tipo);

        } else if (cbxCategoria.getSelectedIndex() == 2) {

            tipo = "Preimun";

            agregarHabitaciones(tipo);

        } else if (cbxCategoria.getSelectedIndex() == 3) {

            tipo = "Regular";

            agregarHabitaciones(tipo);

        }
        this.setLocationRelativeTo(null);
        
    }
    public void ActualizarHabitaciones() {

        String tipo;
        if (cbxCategoria.getSelectedIndex() == 0) {

            JOptionPane.showMessageDialog(null, "Seleccione la categoria");

        } else if (cbxCategoria.getSelectedIndex() == 1) {

            tipo = "Suite";
            acutualizar(tipo);

        } else if (cbxCategoria.getSelectedIndex() == 2) {

            tipo = "Preimun";

            acutualizar(tipo);

        } else if (cbxCategoria.getSelectedIndex() == 3) {

            tipo = "Regular";

            acutualizar(tipo);

        }
        this.setLocationRelativeTo(null);
        
    }    
    public void cargarfoto() {
        conectarBD();
        try {
            cargar();
        } catch (IOException ex) {
            Logger.getLogger(registroHabitaciones.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void cargar() throws IOException {
        try {
            String COD = txtCodigo.getText();
            ImageIcon foto;
            InputStream is;

            senteciaSQL = "SELECT * FROM habitacion WHERE codHabitaciones LIKE '" + idHabitacion + "'";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(senteciaSQL);

            if (rs.next()) {

                is = rs.getBinaryStream("foto");

                BufferedImage bi = ImageIO.read(is);
                foto = new ImageIcon(bi);

                Image img = foto.getImage();
                Image newimg = img.getScaledInstance(lblFoto.getWidth(), lblFoto.getHeight(), Image.SCALE_REPLICATE);

                ImageIcon newcon = new ImageIcon(newimg);

                lblFoto.setIcon(newcon);
            } else {
                JOptionPane.showMessageDialog(null, "REGISTRO NO ENCONTRADO", "INFORMACION", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void agregarfoto() {
        conectarBD();
        lblFoto.setIcon(null);
        JFileChooser j = new JFileChooser();
        j.setFileSelectionMode(JFileChooser.FILES_ONLY);
        int estado = j.showOpenDialog(null);

        if (estado == JFileChooser.APPROVE_OPTION) {

            try {
                fis = new FileInputStream(j.getSelectedFile());
                this.longitudBytes = (int) j.getSelectedFile().length();
                try {
                    Image icono = ImageIO.read(j.getSelectedFile()).getScaledInstance(lblFoto.getWidth(), lblFoto.getHeight(), Image.SCALE_DEFAULT);

                    lblFoto.setIcon(new ImageIcon(icono));
                    lblFoto.updateUI();
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(rootPane, "imagen: " + ex);
                }
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            }
        }
    }

    public void agregarHabitaciones( String tipo) {

        try {
            conectarBD();
            senteciaSQL = "INSERT INTO habitacion (codHabitaciones,categoria,descripcion,foto,capacidad,precio,alquiler,estado) VALUES(?,?,?,?,?,?,?,?)";
            ps = con.prepareStatement(senteciaSQL);
            ps.setInt(1, Integer.parseInt(txtCodigo.getText()));
            ps.setString(2, tipo);
            ps.setString(3, txtdescripcion.getText());
            ps.setBinaryStream(4, fis, longitudBytes);
            ps.setInt(5, Integer.parseInt(txtCapacidad.getText()));
            ps.setString(6, txtprecio.getText());            
            ps.setString(7, "disponible");
            ps.setString(8, "Activo");
            ps.execute();
            Notification not = new Notification(this, Notification.Type.SUCCESS, Notification.Location.TOP_CENTER, "Datos de Empleados Guardados Correctamente");
            not.showNotification();
            
            //con.close();
        } catch (SQLException ex) {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No Se pudo Crear el Empleado " + ex);
            not.showNotification();
            System.out.println("p"+ex);
        }
    }

    public void acutualizar(String tipo) {
        try {
            conectarBD();
            senteciaSQL = "UPDATE habitacion SET categoria=?,descripcion=?,foto=?,capacidad=?,precio=? WHERE codHabitaciones=?";
            ps = con.prepareStatement(senteciaSQL);
            ps.setString(1, tipo);
            ps.setString(2, txtdescripcion.getText());
            ps.setBinaryStream(3, fis, longitudBytes);
            ps.setInt(4, Integer.parseInt(txtCapacidad.getText()));
            ps.setString(5, txtprecio.getText());
            ps.setString(6, txtCodigo.getText());
            ps.execute();
            //con.close();
            Notification not = new Notification(this, Notification.Type.INFO, Notification.Location.TOP_CENTER, "Datos Actualizados Correctamente");
            not.showNotification();
        } catch (SQLException ex) {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No se pudo actualizar el dato " + ex);
            not.showNotification();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtprecio = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtCapacidad = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        lblFoto = new javax.swing.JLabel();
        txtCodigo = new javax.swing.JTextField();
        PUpper = new java.awt.Panel();
        ExitSys = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        btnFoto = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtdescripcion = new javax.swing.JTextArea();
        cbxCategoria = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 5));
        jPanel2.setForeground(new java.awt.Color(0, 102, 102));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Roboto Medium", 1, 16)); // NOI18N
        jLabel3.setText("COD");
        jLabel3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 80, 70, 30));

        jLabel4.setFont(new java.awt.Font("Roboto Medium", 1, 16)); // NOI18N
        jLabel4.setText("Capacidad");
        jLabel4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 80, 30));

        jLabel6.setFont(new java.awt.Font("Roboto Medium", 1, 16)); // NOI18N
        jLabel6.setText("Precio");
        jLabel6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 290, 70, 30));

        txtprecio.setFont(new java.awt.Font("Roboto Light", 1, 16)); // NOI18N
        jPanel2.add(txtprecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 290, 250, 30));

        jLabel5.setFont(new java.awt.Font("Roboto Medium", 1, 16)); // NOI18N
        jLabel5.setText("Categoria");
        jLabel5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 80, 30));

        txtCapacidad.setFont(new java.awt.Font("Roboto Light", 1, 16)); // NOI18N
        jPanel2.add(txtCapacidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 250, 250, 30));

        jLabel8.setFont(new java.awt.Font("Roboto Medium", 1, 16)); // NOI18N
        jLabel8.setText("Descripcion");
        jLabel8.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 90, 30));

        lblFoto.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel2.add(lblFoto, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 80, 250, 170));

        txtCodigo.setFont(new java.awt.Font("Roboto Light", 1, 16)); // NOI18N
        jPanel2.add(txtCodigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 80, 250, 30));

        PUpper.setBackground(new java.awt.Color(0, 102, 102));
        PUpper.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PUpperMousePressed(evt);
            }
        });
        PUpper.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                PUpperMouseDragged(evt);
            }
        });
        PUpper.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ExitSys.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/BClose.png"))); // NOI18N
        ExitSys.setContentAreaFilled(false);
        ExitSys.setPreferredSize(new java.awt.Dimension(30, 30));
        ExitSys.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExitSysMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ExitSysMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ExitSysMouseExited(evt);
            }
        });
        ExitSys.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitSysActionPerformed(evt);
            }
        });
        PUpper.add(ExitSys, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 10, 32, 26));

        jLabel20.setFont(new java.awt.Font("Roboto Black", 0, 20)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Software Hotel");
        PUpper.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 7, 191, -1));
        PUpper.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(4, 13, -1, 26));
        PUpper.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 13, -1, 26));
        PUpper.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/LogIc.png"))); // NOI18N
        PUpper.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 7, 30, 30));

        jPanel2.add(PUpper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 664, -1));

        jButton5.setBackground(new java.awt.Color(0, 255, 153));
        jButton5.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(102, 102, 255));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/guardar (2).png"))); // NOI18N
        jButton5.setText("GUARDAR");
        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton5MouseClicked(evt);
            }
        });
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 400, -1, -1));

        btnFoto.setBackground(new java.awt.Color(0, 204, 204));
        btnFoto.setForeground(new java.awt.Color(0, 51, 102));
        btnFoto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/agregarfoto (1).png"))); // NOI18N
        btnFoto.setText("Agregar Foto");
        btnFoto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnFotoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnFotoMouseExited(evt);
            }
        });
        btnFoto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFotoActionPerformed(evt);
            }
        });
        jPanel2.add(btnFoto, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 260, -1, -1));

        txtdescripcion.setColumns(20);
        txtdescripcion.setFont(new java.awt.Font("Roboto Light", 0, 16)); // NOI18N
        txtdescripcion.setRows(5);
        jScrollPane1.setViewportView(txtdescripcion);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 170, 250, 70));

        cbxCategoria.setFont(new java.awt.Font("Roboto Light", 0, 16)); // NOI18N
        cbxCategoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione", "Suite", "Preimun", "Regular" }));
        jPanel2.add(cbxCategoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 130, 250, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 479, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ExitSysMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseClicked

        //int Jop = JOptionPane.showConfirmDialog(null, "Salir del sistema", "Salir", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
        //if(Jop== JOptionPane.YES_OPTION){System.exit(0);} else if(Jop == JOptionPane.CANCEL_OPTION){}
    }//GEN-LAST:event_ExitSysMouseClicked

    private void ExitSysMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseEntered

    }//GEN-LAST:event_ExitSysMouseEntered

    private void ExitSysMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseExited

    }//GEN-LAST:event_ExitSysMouseExited

    private void ExitSysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitSysActionPerformed
        this.dispose();
    }//GEN-LAST:event_ExitSysActionPerformed

    private void PUpperMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMousePressed
        // TODO add your handling code here:
        //        xMouse = evt.getX();
        //        yMouse = evt.getY();
    }//GEN-LAST:event_PUpperMousePressed

    private void PUpperMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMouseDragged
        // TODO add your handling code here
        //        int x = evt.getXOnScreen();
        //        int y = evt.getYOnScreen();
        //        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_PUpperMouseDragged

    private void jButton5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5MouseClicked

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        if (txtCodigo.getText().isEmpty() ||txtCapacidad.getText().isEmpty()||cbxCategoria.getSelectedIndex() == 0||txtdescripcion.getText().isEmpty()||txtprecio.getText().isEmpty()||lblFoto.getIcon() == null) {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "Datos Incompletos, Favor llenar todos los campos");
            not.showNotification();
            lblFoto.setIcon(null);
        } else {
            if (NUM == 1) {
                InsertarHabitaciones();
                this.dispose();
            } else if (NUM == 2) {
                ActualizarHabitaciones();
                this.dispose();
            }
        }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void btnFotoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFotoMouseEntered

    }//GEN-LAST:event_btnFotoMouseEntered

    private void btnFotoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFotoMouseExited

    }//GEN-LAST:event_btnFotoMouseExited

    private void btnFotoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFotoActionPerformed
        agregarfoto();
    }//GEN-LAST:event_btnFotoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(registroHabitaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(registroHabitaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(registroHabitaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(registroHabitaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new registroHabitaciones().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ExitSys;
    private java.awt.Panel PUpper;
    private javax.swing.JButton btnFoto;
    private javax.swing.JComboBox<String> cbxCategoria;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblFoto;
    private javax.swing.JTextField txtCapacidad;
    private javax.swing.JTextField txtCodigo;
    private javax.swing.JTextArea txtdescripcion;
    private javax.swing.JTextField txtprecio;
    // End of variables declaration//GEN-END:variables
}
