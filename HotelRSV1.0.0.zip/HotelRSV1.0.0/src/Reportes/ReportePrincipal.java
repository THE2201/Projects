package Reportes;

import java.util.*;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;
import Conexion.conexionBD;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
import static proyecto_final.MenuPrincipal.RealTime;

public class ReportePrincipal extends javax.swing.JPanel {

    Connection con = null;
    conexionBD conecta;
    String sentenciaSQL;
    PreparedStatement ps = null;
    ResultSet rs = null;
    String senteciaSQL;
    int nombre = 0;
    String fechaActual = "", mesActual = "", anioActual = "";
    String FXX = RealTime();
    char[] f = FXX.toCharArray();
    String Dof1 = String.valueOf(f[0]), Dof2 = String.valueOf(f[1]);
    String Mof1 = String.valueOf(f[3]), Mof2 = String.valueOf(f[4]);
    String Yof1 = String.valueOf(f[6]), Yof2 = String.valueOf(f[7]), Yof3 = String.valueOf(f[8]), Yof4 = String.valueOf(f[9]);
    String SDay = Dof1 + Dof2, SMonth = Mof1 + Mof2, SYear = Yof1 + Yof2 + Yof3 + Yof4;

    public ReportePrincipal() {
        initComponents();
        verificaciones();

    }

    public void conectarBD() {
        conecta = new conexionBD("proyecto_final");
        con = conecta.getConexion();
    }

    public static String RealTime() {
        Date fecha = new Date();
        SimpleDateFormat formatFecha = new SimpleDateFormat("dd/MM/YYYY");
        SimpleDateFormat dx = new SimpleDateFormat("dd");
        SimpleDateFormat mx = new SimpleDateFormat("MM");
        SimpleDateFormat yx = new SimpleDateFormat("YYYY");
        return formatFecha.format(fecha);
    }

    public void conectarDB() {
        conecta = new conexionBD("proyecto_final");
        con = conecta.getConexion();
    }

    public void llamarReportes(String nombre) {
        try {
            conectarDB();
            JasperReport reporte = null;
            //RUTA DEL ARCHIVO
            URL urlMaestro = getClass().getResource(nombre);
            //LLAMADO DEL ARCHIVO
            reporte = (JasperReport) JRLoader.loadObject(urlMaestro);
            //LLENADO DEL REPORTE
            JasperPrint jprint = JasperFillManager.fillReport(reporte, null, con);
            //VISTA DEL REPORTE
            JasperViewer view = new JasperViewer(jprint, false);
            //TITULO (OPCIONAL)
            view.setTitle("REPORTE DE CLIENTES");
            //CIERRE DEL REPORTE
            view.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            view.setVisible(true);
            con.close();

        } catch (JRException ex) {
            System.out.print(ex);
        } catch (SQLException ex) {

        }

    }

    public void busqueda() {

        nombre = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el Numero de Habitacion a Buscar"));
        try {
            conectarDB();

            Map parametro = new HashMap();
            parametro.put("codigo", nombre);
            JasperReport reporte = null;
            //Ruta del Archivo
            URL urlMaestro = getClass().getResource("habitacion.jasper");
            //Llamado del Archivo
            reporte = (JasperReport) JRLoader.loadObject(urlMaestro);
            JasperPrint jprint = JasperFillManager.fillReport(reporte, parametro, con);
            //Vista del Reporte
            JasperViewer view = new JasperViewer(jprint, false);
            //Titulo Opcional
            view.setTitle("Reporte Habitacion");
            view.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            view.setVisible(true);
            con.close();
        } catch (JRException ex) {
            System.out.println("Error" + ex);
        } catch (SQLException ex) {
            Logger.getLogger(ReportePrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void verificaciones() {
        conectarBD();

        double diario = 0, total = 0;
        senteciaSQL = "SELECT  * FROM reservacion WHERE estado !='Cancelado' AND fechaIngreso='" + SYear + "/" + SMonth + "/" + SDay + "'";

        try {
            ps = con.prepareStatement(senteciaSQL);
            rs = ps.executeQuery();

            while (rs.next()) {
                diario = (diario + rs.getDouble(7));

            }
            con.close();
            btndiario.setText(String.valueOf(diario + " Lps."));
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
        }
        double mensual = 0, totalmen = 0;
        String fechaMesFin = "";
        if (SMonth.equals("1") || SMonth.equals("3") || SMonth.equals("5") || SMonth.equals("7") || SMonth.equals("8") || SMonth.equals("10") || SMonth.equals("12")) {
            fechaMesFin = SYear + "/" + SMonth + "/" + "31";
        } else if (SMonth.equals("2")) {
            fechaMesFin = SYear + "/" + SMonth + "/" + "28";
        } else {
            fechaMesFin = SYear + "/" + SMonth + "/" + "30";
        }

        String fechaMesInicio = SYear + "/" + SMonth + "/" + "1";

        conectarBD();
        senteciaSQL = "SELECT  * FROM reservacion WHERE estado !='Cancelado' AND fechaIngreso>'" + fechaMesInicio + "' AND fechaIngreso<'" + fechaMesFin + "'";

        try {
            ps = con.prepareStatement(senteciaSQL);
            rs = ps.executeQuery();

            while (rs.next()) {
                mensual = (mensual + rs.getDouble(7));
            }
            con.close();
            btnmenusal.setText(String.valueOf(mensual + " Lps."));
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
        }

        conectarBD();
        double anual = 0;
        senteciaSQL = "SELECT  * FROM reservacion WHERE estado !='Cancelado' AND fechaIngreso>='" + SYear + "/01/01' AND fechaIngreso<='" + SYear + "/12/31'";

        try {
            ps = con.prepareStatement(senteciaSQL);
            rs = ps.executeQuery();

            while (rs.next()) {
                anual = (anual + rs.getDouble(7));
            }
            con.close();
            btnAnual.setText(String.valueOf(anual + " Lps."));
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
        }
//        senteciaSQL = "SELECT GETDATE()";
//        Object fechas=null;
//        try {
//            ps = con.prepareStatement(senteciaSQL);
//            rs = ps.executeQuery();
//
//            while (rs.next()) {
//                fechas=rs.getDate(1);
//            }
//            con.close();
//            System.out.println("prueba"+fechas);
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
//        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        PUpper = new java.awt.Panel();
        jLabel20 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        btnTabla = new javax.swing.JButton();
        btnNombre = new javax.swing.JButton();
        btnVentas = new javax.swing.JButton();
        btnClientes = new javax.swing.JButton();
        fSGradientPanel6 = new LIB.FSGradientPanel();
        lbclientes3 = new javax.swing.JLabel();
        btnmenusal = new javax.swing.JLabel();
        lbIcon3 = new javax.swing.JLabel();
        fSGradientPanel7 = new LIB.FSGradientPanel();
        lbclientes4 = new javax.swing.JLabel();
        btnAnual = new javax.swing.JLabel();
        lbIcon4 = new javax.swing.JLabel();
        fSGradientPanel8 = new LIB.FSGradientPanel();
        lbclientes5 = new javax.swing.JLabel();
        btndiario = new javax.swing.JLabel();
        lbIcon5 = new javax.swing.JLabel();
        btnHabitacion = new javax.swing.JButton();
        btnTabla1 = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));
        setMaximumSize(new java.awt.Dimension(750, 650));
        setName(""); // NOI18N
        setPreferredSize(new java.awt.Dimension(750, 650));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));
        jPanel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("REPORTE DE TOTAL VENTAS");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(277, 30, 466, -1));

        add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(-2, 39, 1000, 100));

        PUpper.setBackground(new java.awt.Color(0, 153, 255));
        PUpper.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PUpperMousePressed(evt);
            }
        });
        PUpper.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                PUpperMouseDragged(evt);
            }
        });
        PUpper.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel20.setFont(new java.awt.Font("Roboto Black", 0, 20)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Software Hotel");
        PUpper.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 7, 191, -1));
        PUpper.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(4, 13, -1, 26));
        PUpper.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 13, -1, 26));
        PUpper.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/LogIc.png"))); // NOI18N
        PUpper.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 7, 30, 30));

        add(PUpper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1000, 40));

        btnTabla.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/vehiculo.png"))); // NOI18N
        btnTabla.setText("REPORTE AUTOS");
        btnTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTablaActionPerformed(evt);
            }
        });
        add(btnTabla, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 560, 200, 70));

        btnNombre.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/empleados.png"))); // NOI18N
        btnNombre.setText("REPORTE EMPLEADOS");
        btnNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNombreActionPerformed(evt);
            }
        });
        add(btnNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 560, -1, 70));

        btnVentas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/chofer.png"))); // NOI18N
        btnVentas.setText("REPORTES CHOFERES");
        btnVentas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVentasActionPerformed(evt);
            }
        });
        add(btnVentas, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 560, 210, 70));

        btnClientes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/user (1).png"))); // NOI18N
        btnClientes.setText("REPORTES CLIENTES");
        btnClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClientesActionPerformed(evt);
            }
        });
        add(btnClientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 470, 200, 70));

        fSGradientPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 0, 204), 0));
        fSGradientPanel6.setFSEndColor(new java.awt.Color(204, 255, 204));
        fSGradientPanel6.setFSGradientFocus(200);
        fSGradientPanel6.setFSStartColor(new java.awt.Color(255, 255, 204));
        fSGradientPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbclientes3.setFont(new java.awt.Font("Roboto Black", 1, 18)); // NOI18N
        lbclientes3.setForeground(new java.awt.Color(102, 0, 204));
        lbclientes3.setText("Total Ventas  Mensual");
        fSGradientPanel6.add(lbclientes3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, -1, -1));

        btnmenusal.setFont(new java.awt.Font("sansserif", 0, 24)); // NOI18N
        btnmenusal.setForeground(new java.awt.Color(0, 0, 153));
        btnmenusal.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnmenusal.setText("Num");
        btnmenusal.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        fSGradientPanel6.add(btnmenusal, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 50, 180, -1));

        lbIcon3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbIcon3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/calendario.png"))); // NOI18N
        fSGradientPanel6.add(lbIcon3, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 20, 70, 70));

        add(fSGradientPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 160, 340, 114));

        fSGradientPanel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 0, 204), 0));
        fSGradientPanel7.setFSEndColor(new java.awt.Color(204, 255, 255));
        fSGradientPanel7.setFSGradientFocus(200);
        fSGradientPanel7.setFSStartColor(new java.awt.Color(255, 153, 153));
        fSGradientPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbclientes4.setFont(new java.awt.Font("Roboto Black", 1, 18)); // NOI18N
        lbclientes4.setForeground(new java.awt.Color(102, 0, 204));
        lbclientes4.setText("Total Ventas Anual");
        fSGradientPanel7.add(lbclientes4, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, -1, -1));

        btnAnual.setFont(new java.awt.Font("sansserif", 0, 24)); // NOI18N
        btnAnual.setForeground(new java.awt.Color(0, 0, 153));
        btnAnual.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnAnual.setText("Num");
        fSGradientPanel7.add(btnAnual, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, 210, -1));

        lbIcon4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbIcon4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/calendario.png"))); // NOI18N
        fSGradientPanel7.add(lbIcon4, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 20, 70, 70));

        add(fSGradientPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 320, 340, 114));

        fSGradientPanel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 0, 204), 0));
        fSGradientPanel8.setFSEndColor(new java.awt.Color(204, 255, 204));
        fSGradientPanel8.setFSGradientFocus(200);
        fSGradientPanel8.setFSStartColor(new java.awt.Color(255, 204, 255));
        fSGradientPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbclientes5.setFont(new java.awt.Font("Roboto Black", 1, 18)); // NOI18N
        lbclientes5.setForeground(new java.awt.Color(102, 0, 204));
        lbclientes5.setText("Total Ventas Diarias");
        fSGradientPanel8.add(lbclientes5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, -1, -1));

        btndiario.setFont(new java.awt.Font("sansserif", 0, 24)); // NOI18N
        btndiario.setForeground(new java.awt.Color(0, 0, 153));
        btndiario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btndiario.setText("Num");
        fSGradientPanel8.add(btndiario, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 200, -1));

        lbIcon5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbIcon5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/calendario.png"))); // NOI18N
        fSGradientPanel8.add(lbIcon5, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 20, 70, 70));

        add(fSGradientPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 160, 340, 114));

        btnHabitacion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/habitaciones.png"))); // NOI18N
        btnHabitacion.setText("REPORTE HABITACION");
        btnHabitacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHabitacionActionPerformed(evt);
            }
        });
        add(btnHabitacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 470, 210, 70));

        btnTabla1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/registro.png"))); // NOI18N
        btnTabla1.setText("REPORTE RENTAS");
        btnTabla1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTabla1ActionPerformed(evt);
            }
        });
        add(btnTabla1, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 470, 200, 70));
    }// </editor-fold>//GEN-END:initComponents

    private void PUpperMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMouseDragged
        // TODO add your handling code here
        //        int x = evt.getXOnScreen();
        //        int y = evt.getYOnScreen();
        //        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_PUpperMouseDragged

    private void PUpperMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMousePressed
        // TODO add your handling code here:
        //        xMouse = evt.getX();
        //        yMouse = evt.getY();
    }//GEN-LAST:event_PUpperMousePressed

    private void btnVentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVentasActionPerformed
        llamarReportes("reporteChofer.jasper");
    }//GEN-LAST:event_btnVentasActionPerformed

    private void btnTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTablaActionPerformed
        llamarReportes("Autos.jasper");
    }//GEN-LAST:event_btnTablaActionPerformed

    private void btnNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNombreActionPerformed
        llamarReportes("empleados.jasper");
    }//GEN-LAST:event_btnNombreActionPerformed

    private void btnClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClientesActionPerformed
        llamarReportes("cliente.jasper");

    }//GEN-LAST:event_btnClientesActionPerformed

    private void btnHabitacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHabitacionActionPerformed
        busqueda();

    }//GEN-LAST:event_btnHabitacionActionPerformed

    private void btnTabla1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTabla1ActionPerformed
        llamarReportes("Grafica.jasper");
    }//GEN-LAST:event_btnTabla1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Panel PUpper;
    private javax.swing.JLabel btnAnual;
    private javax.swing.JButton btnClientes;
    private javax.swing.JButton btnHabitacion;
    private javax.swing.JButton btnNombre;
    private javax.swing.JButton btnTabla;
    private javax.swing.JButton btnTabla1;
    private javax.swing.JButton btnVentas;
    private javax.swing.JLabel btndiario;
    private javax.swing.JLabel btnmenusal;
    private LIB.FSGradientPanel fSGradientPanel6;
    private LIB.FSGradientPanel fSGradientPanel7;
    private LIB.FSGradientPanel fSGradientPanel8;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lbIcon3;
    private javax.swing.JLabel lbIcon4;
    private javax.swing.JLabel lbIcon5;
    private javax.swing.JLabel lbclientes3;
    private javax.swing.JLabel lbclientes4;
    private javax.swing.JLabel lbclientes5;
    // End of variables declaration//GEN-END:variables

    private void ReportePorFechasPDF(java.sql.Date f1, java.sql.Date f2) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
