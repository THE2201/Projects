package Reportes;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.HeadlessException;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.net.URL;
import java.util.*;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;
import Conexion.conexionBD;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ReportePorFecha extends javax.swing.JPanel {

    Connection con = null;
    conexionBD conecta;
    String sentenciaSQL;
    PreparedStatement ps = null;
    ResultSet rs = null;
    String encontrado;
    Date fechasSQL;
    Date fechaI, fechaF;//VARIABLE DONDE GUARDAMOS LO QUE OBTENEMOS DEL JDATECHOOSER
    long fe1, fe2;//VARIABLE DODE ALMACENAMOS EL TAMANO EN BYTES
    java.sql.Date f1, f2;//VARIABLE DONDE LA CONVERTIMOS A FECHA SQL
     //CREAMOS UNA TABLA TIPO PDF CON EL NUMERO DE COLUMNAS QUE NECESITAMOS
    PdfPTable tabla = new PdfPTable(11);

    //CREAMOS UN DOCUMENTO DONDE SE AGREGARA EL LOGO, EL ENCABEZADO Y LA TABLA PDF
    Document reporte = new Document();

    DefaultTableModel modelo;
    Object datosFecha[] = new Object[11];

    public ReportePorFecha() {
        initComponents();
    }

    public void fechaSQL() {
        fechaI = jdcFecha1.getDate();//OBTENEMOS LA FECHA DEL JDATECHOOSER
        fechaF = jdcFecha2.getDate();
        fe1 = fechaI.getTime();//getTime() AYUDA A ASIGNAR  UNA FECHA Y HORA A OTRO OBJETO DATE        
        fe2 = fechaF.getTime();
        f1 = new java.sql.Date(fe1);//CONVERTIMOS A FECHA SQL
        f2 = new java.sql.Date(fe2);    
    }

   public void conectarBD() {
        conecta = new conexionBD("proyecto_final");
        con = conecta.getConexion();
    }

    public void reportePorFechas() {      
        encontrado = "NO";
        try {
            conectarBD();
            sentenciaSQL = "SELECT * FROM reservacion WHERE fechaIngreso BETWEEN ' " + f1 + " 'and ' " + f2 + " ' ";
            ps = con.prepareStatement(sentenciaSQL);
            rs = ps.executeQuery();
            modelo = (DefaultTableModel) tblDatos.getModel();
            while (rs.next()) {
                datosFecha[0] = (rs.getInt("codreserva"));
                datosFecha[1] = (rs.getString("identidadCliente"));
                datosFecha[2] = (rs.getDate("fechaIngreso"));
                datosFecha[3] = (rs.getDate("fechasalida"));
                datosFecha[4] = (rs.getInt("codHabitacion"));
                datosFecha[5] = (rs.getInt("rentaVehiculo"  ));
                datosFecha[6] = (rs.getDouble("total"));
                datosFecha[7] = (rs.getString("TPago"));
                datosFecha[8] = (rs.getString("Tarjeta"));
                datosFecha[9] = (rs.getString("Venc"));
                datosFecha[10] = (rs.getString("estado"));
                modelo.addRow(datosFecha);
                encontrado = "SI";
                System.out.print(encontrado);
                System.out.print("codreserva");
            }         
            if (encontrado.equals("NO")) {
                JOptionPane.showMessageDialog(null, "REGISTROS NO ENCONTRADOS", "ATENCION!", JOptionPane.ERROR_MESSAGE);
            }
            tblDatos.setModel(modelo);
            con.close();
        } catch (HeadlessException | SQLException y) {
        }
    }

    //LIMPIA LA TABLA
    public void limpiarTabla() {
        int fila = tblDatos.getRowCount();
        for (int i = fila - 1; i >= 0; i--) {
            modelo.removeRow(i);
        }
    }
    
     public void crearReportePDF() {

        try {
            //RUTA DE LA CARPETA DE USUARIO
            String ruta = System.getProperty("user.home");

            //AGREGO LA RUTA DEL DIRECTORIO PRINCIPAL MAS LA RUTA Y CARPETA DONDE QUIERO QUE ME 
            //APAREZCA EL PDF Y LE COLOCO EL NOMBRE QUE QUIERO QUE LLEVE EL DOCUMENTO, EN ESTE CASO TUVE QUE CREAR
            //UNA CARPETA EN EL ESCRITORIO QUE SE LLAMA REPORTES Y AHI MANDO A CREAR EL Reporte_PorFechas.pdf
            PdfWriter.getInstance(reporte, new FileOutputStream(ruta + "/Desktop/REPORTES/Reporte_PorFechasR.pdf"));

            //IMAGEN DEL ENCABEZADO (COLOCAMOS LA RUTA DE NUESTRA IMAGEN Y EL NOMBRE DE LA IMAGEN CON SU EXTENSION)
            Image logo = Image.getInstance("src/img/Encabezado.png");
            //Users\Delmer\OneDrive\Escritorio\REPORTES\PruebaDeFechas\src\imgs

            //MEDIDA DE LA IMAGEN DEL ENCABEZADO (LARGO Y ALTO)
            logo.scaleToFit(350, 200);

            //ALINEACION DEL ENCABEZADO
            logo.setAlignment(Chunk.ALIGN_CENTER);

            //DAMOS FORMATO AL TEXTO DEL ENCABEZADO
            Paragraph encabezado = new Paragraph();
            encabezado.setAlignment(Element.ALIGN_CENTER);//ALINEACION
            encabezado.setFont(FontFactory.getFont("Arial", 24, Font.BOLD, BaseColor.RED));//TIPO DE FUENTE, FORMATO Y COLOR
             encabezado.add("\n   RESERVACION\n");//TEXTO QUE APARECERÁ
            encabezado.setFont(FontFactory.getFont("Arial", 16, Font.BOLD, BaseColor.BLACK));
            encabezado.add("\n  REPORTE POR FECHAS DE RESERVACION\n\n\n");

            //AGREGAMOS LAS CELDAS A LA TABLA
            tabla.addCell("COD");
            tabla.addCell("ID");  
            tabla.addCell("FECHI"); 
            tabla.addCell("FECHS"); 
            tabla.addCell("CODH"); 
            tabla.addCell("RENTAV"); 
            tabla.addCell("TOTAL"); 
            tabla.addCell("TPAGO"); 
            tabla.addCell("TAR"); 
            tabla.addCell("VENC");    
            tabla.addCell("EST"); 

            //ABRIMOS EL DOCUMENTO
            reporte.open();
            //AGREGAMOS AL DOCUMENTO, EL LOGO (IMAGEN) Y ENCABEZADO
            reporte.add(logo);
            reporte.add(encabezado);
            //LLAMAMOS AL METODO BUSCAR EN LA BASE DE DATOS LOS REGISTROS QUE TENEMOS
            BuscarEnBD(f1,f2);
            //ABRIMOS EL PDF UNA VEZ QUE HA SIDO CREADO
            Lector lec=new Lector();
            lec.setVisible(true);

        } catch (DocumentException | FileNotFoundException e) {
            System.out.print("ERROR " + e);
        } catch (IOException e) {
            System.out.print("ERROR " + e);
        }
    }

    public void BuscarEnBD( java.sql.Date fechaIngreso,  java.sql.Date fechasalida) {
        try {
            conectarBD();
            sentenciaSQL = "SELECT * FROM reservacion WHERE fechaIngreso BETWEEN ' " + fechaIngreso + " 'and ' " + fechasalida + " ' ";
            ps = con.prepareStatement(sentenciaSQL);
            rs = ps.executeQuery();         

            //HACE EL RECORRIDO EN LA TABLA DE LA BD Y LOS VA AGREGANDO A LA TABLA DEL PDF
            if (rs.next()) {
                do {
                    tabla.addCell(rs.getString(1));//AQUI IRÁ EL NUMERO SEGUN LA POSICION DEL CAMPO EN SU TABLA DE LA BD
                    tabla.addCell(rs.getString(2));
                    tabla.addCell(rs.getString(3));
                    tabla.addCell(rs.getString(4));
                    tabla.addCell(rs.getString(5));
                    tabla.addCell(rs.getString(6));
                    tabla.addCell(rs.getString(7));
                    tabla.addCell(rs.getString(8));
                    tabla.addCell(rs.getString(9));
                    tabla.addCell(rs.getString(10));
                    tabla.addCell(rs.getString(11));
                   
                } while (rs.next());
                reporte.add(tabla);//AGREGAMOS AL DOCUMENTO LA TABLA QUE YA ESTÁ LLENA CON LOS DATOS OBTENIDOS DE LA BD                                 
                encontrado = "SI";
                if (encontrado.equals("NO")) {
                    JOptionPane.showMessageDialog(null, "CODIGO RESERVACION NO ENCONTRADO", "ATENCION!", JOptionPane.ERROR_MESSAGE);
                }
                reporte.close();//CERRAMOS EL DOCUMENTO
                JOptionPane.showMessageDialog(null, "REPORTE HA SIDO CREADO!", "ATENCION", 1);
                con.close();//CERRAMOS LA CONEXION
            }
        } catch (DocumentException | HeadlessException | SQLException x) {
            System.out.print("ERROR " + x);
        }
    }

    public void abrirReporte() {
        try {
            //RUTA DEL DIRECTORIO
            String ruta = System.getProperty("user.home");
            //AGREGAMOS LA RUTA DONDE DEBE IR A BUSCAR EL PDF PARA ABRIRLO
            Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + ruta + "/Desktop/REPORTES/Reporte_PorFechasR.pdf");
            System.out.println("REPORTE VISUALIZADO");
        } catch (IOException e) {
        }
    }
    
     public void reportePorFechasiReport() {       
         try {
            conectarBD();//CONECTAMOS  A LA BD
           
            Map parametro = new HashMap();
            parametro.put("fechaIngreso",f1);
            parametro.put("fechasalida",f2);
          
            JasperReport reporte = null;
            //RUTA DEL ARCHIVO
            URL urlMaestro = getClass().getResource("reportePorFechas.jasper");
            //LLAMADO DEL ARCHIVO
            reporte = (JasperReport) JRLoader.loadObject(urlMaestro);
            //LLENADO DEL REPORTE
            JasperPrint jprint = JasperFillManager.fillReport(reporte,parametro, con);
            //VISTA DEL REPORTE
            JasperViewer view = new JasperViewer(jprint, false);
            //TITULO (OPCIONAL)
            view.setTitle("REPORTE POR FECHAS DE RESERVACION");
            //CIERRE DEL REPORTE
            view.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            view.setVisible(true);
            con.close();
        } catch (JRException e) {
            System.out.print(e);
        } catch (SQLException ex) {
           
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tblDatos = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jdcFecha1 = new com.toedter.calendar.JDateChooser();
        botLimpiar = new javax.swing.JButton();
        botObtenerFecha = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jdcFecha2 = new com.toedter.calendar.JDateChooser();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        PUpper = new java.awt.Panel();
        jLabel20 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        setMaximumSize(new java.awt.Dimension(750, 650));
        setName(""); // NOI18N
        setPreferredSize(new java.awt.Dimension(750, 650));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tblDatos.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        tblDatos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CODIGO", "IDCLIENTE", "FECHAINGRESO", "FECHASALIDA", "CODHABITACION", "RENTAVEHICULO", "TOTAL", "TPAGO", "TARJETA", "VENCIMIENTO", "ESTADO"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, true, true, true, true, true, true, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblDatos.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tblDatos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblDatosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblDatos);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, 980, 440));

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));
        jPanel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("REPORTE DE FECHAS RESERVACION");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(232, 232, 232)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 466, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(296, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel4)
                .addContainerGap(37, Short.MAX_VALUE))
        );

        add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(-2, 39, 1000, 100));

        jLabel1.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel1.setText("FECHA INICIAL");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 170, 89, 19));

        jdcFecha1.setDateFormatString("dd-MM-yyyy");
        add(jdcFecha1, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 170, 186, -1));

        botLimpiar.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        botLimpiar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/borrador.png"))); // NOI18N
        botLimpiar.setText("LIMPIAR");
        botLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botLimpiarActionPerformed(evt);
            }
        });
        add(botLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 160, 151, -1));

        botObtenerFecha.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/mostrar.png"))); // NOI18N
        botObtenerFecha.setText("GENERAR");
        botObtenerFecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botObtenerFechaActionPerformed(evt);
            }
        });
        add(botObtenerFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 160, 142, -1));

        jLabel2.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel2.setText("FECHA FINAL");
        add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 220, -1, 19));
        add(jdcFecha2, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 220, 186, -1));

        jButton1.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/descargar-pdf.png"))); // NOI18N
        jButton1.setText("PDF");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 220, 142, 40));

        jButton2.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/reporte_1.png"))); // NOI18N
        jButton2.setText("iREPORT");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 220, 151, -1));

        PUpper.setBackground(new java.awt.Color(0, 153, 255));
        PUpper.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PUpperMousePressed(evt);
            }
        });
        PUpper.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                PUpperMouseDragged(evt);
            }
        });
        PUpper.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel20.setFont(new java.awt.Font("Roboto Black", 0, 20)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Software Hotel");
        PUpper.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 7, 191, -1));
        PUpper.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(4, 13, -1, 26));
        PUpper.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 13, -1, 26));
        PUpper.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/LogIc.png"))); // NOI18N
        PUpper.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 7, 30, 30));

        add(PUpper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1000, 40));
    }// </editor-fold>//GEN-END:initComponents

    private void tblDatosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblDatosMouseClicked
       

    }//GEN-LAST:event_tblDatosMouseClicked

    private void botLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botLimpiarActionPerformed
     limpiarTabla();
    }//GEN-LAST:event_botLimpiarActionPerformed

    private void botObtenerFechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botObtenerFechaActionPerformed
        if(jdcFecha1.getDate()==null || jdcFecha2.getDate()==null)
        {
        JOptionPane.showMessageDialog(null, "NO SE PUEDE GENERAR, CAMPO VACIOS", "ATENCION", JOptionPane.ERROR_MESSAGE);
        }else{
        fechaSQL();
        reportePorFechas();
        System.out.print(f1);
        System.out.print(f2);
        }
    }//GEN-LAST:event_botObtenerFechaActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    if(jdcFecha1.getDate()==null || jdcFecha2.getDate()==null)
        {
        JOptionPane.showMessageDialog(null, "NO SE PUEDE MOSTRAR PDF, CAMPO VACIO", "ALERTA", JOptionPane.ERROR_MESSAGE);
        }else{
        crearReportePDF();
    }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       if(jdcFecha1.getDate()==null || jdcFecha2.getDate()==null)
        {
        JOptionPane.showMessageDialog(null, "NO SE PUEDE MOSTRAR REPORTE, CAMPO VACIO", "ATENCION!", JOptionPane.ERROR_MESSAGE);
        }else{
        reportePorFechasiReport();
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void PUpperMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMouseDragged
        // TODO add your handling code here
        //        int x = evt.getXOnScreen();
        //        int y = evt.getYOnScreen();
        //        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_PUpperMouseDragged

    private void PUpperMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMousePressed
        // TODO add your handling code here:
        //        xMouse = evt.getX();
        //        yMouse = evt.getY();
    }//GEN-LAST:event_PUpperMousePressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Panel PUpper;
    private javax.swing.JButton botLimpiar;
    private javax.swing.JButton botObtenerFecha;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private com.toedter.calendar.JDateChooser jdcFecha1;
    private com.toedter.calendar.JDateChooser jdcFecha2;
    private javax.swing.JTable tblDatos;
    // End of variables declaration//GEN-END:variables

    private void ReportePorFechasPDF(java.sql.Date f1, java.sql.Date f2) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
