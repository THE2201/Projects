package Reservaciones;

import Conexion.conexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import Componentes.Notification;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author jairo
 */
public class frameRentaAuto extends javax.swing.JFrame {

    public static int NUM = 0;
    public static String idAlquiler;
    public static String apellido;
    public static String Nombre;
    public static String idCliente;

    public static String Vigenciar;
    public static String marca;
    public static String modelo;
    public static String idAuto;
    public static String total;

    String usuario;
    double totalDis = 0;
    Connection con = null;
    conexionBD conecta;
    String senteciaSQL;
    String senteciaSQL2;
    PreparedStatement ps = null;
    ResultSet rs = null;

    String[][] datosViajesB;

    public frameRentaAuto() {
        initComponents();
        if (Vigenciar.equals("Si")) {
            Rvigente.setSelected(true);
        } else {
            Rvencinda.setSelected(true);
        }
        if (NUM == 2) {
            llenarCliente();
            llenarauto();
            
        } else {
            txtNombre.setText(Nombre);
            txtApellido.setText(apellido);
            txtMarca.setText(marca);
            txtModelo.setText(modelo);
            txtidRentaAuto.setText("0");
        }
        txtidRentaAuto.requestFocus();
        this.setLocationRelativeTo(null);
        txtidRentaAuto.setText(idAlquiler);
        txtIdCliente.setText(idCliente);

        txtTotal.setText(total);
        txtIdAuto.setText(idAuto);

        txtidRentaAuto.setEditable(false);

        txtNombre.setEditable(false);
        txtApellido.setEditable(false);
        txtDiscapacidad.setEditable(false);
        txtMarca.setEditable(false);
        txtModelo.setEditable(false);
        txtTotal.setEditable(false);
    }

    public void conectarBD() {
        conecta = new conexionBD("proyecto_final");
        con = conecta.getConexion();
    }

    public void registro() {

        Boolean tipo = false;
        if (Rvigente.isSelected()) {

            tipo = true;
            crearRegistroAuto(tipo);

        }
        this.setLocationRelativeTo(null);
    }

    public void crearRegistroAuto(boolean tipo) {
        try {

            conectarBD();
            senteciaSQL = "INSERT INTO alquilerauto (idalquiler,documentacion,identidadCliente,idAutomovil,total,estado) VALUES(?,?,?,?,?,?)";

            ps = con.prepareStatement(senteciaSQL);
            ps.setInt(1, 0);
            ps.setBoolean(2, tipo);
            ps.setString(3, txtIdCliente.getText());
            ps.setString(4, txtIdAuto.getText());
            ps.setString(5, txtTotal.getText());
            ps.setString(6, "Activo");
            ps.execute();
            con.close();
            Notification not = new Notification(this, Notification.Type.SUCCESS, Notification.Location.TOP_CENTER, "Datos de usuario Guardados Correctamente");
            not.showNotification();
        } catch (SQLException ex) {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No Se pudo Crear el usuario " + ex);
            not.showNotification();
            System.out.println("not1 = " + ex);
        }
        int id = 0;
        conectarBD();
        senteciaSQL = "SELECT * FROM alquilerauto WHERE estado LIKE 'Activo' AND identidadCliente LIKE '" + txtIdCliente.getText() + "'";
        try {
            ps = con.prepareStatement(senteciaSQL);
            rs = ps.executeQuery();

            while (rs.next()) {
                id = rs.getInt(1);
            }

            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
        }
        try {

            conectarBD();
            senteciaSQL = "INSERT INTO tipoalquilervihiculo (idTipo,tipo,idAlquilerAuto,idRentaVehivulo,idAlquilerChofer ) VALUES(?,?,?,?,?)";

            ps = con.prepareStatement(senteciaSQL);
            ps.setInt(1, 0);
            ps.setString(2, "Alquiler Auto");
            ps.setInt(3, id);
            ps.setString(4, null);
            ps.setString(5, null);
            ps.execute();
            con.close();
        } catch (SQLException ex) {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No Se pudo Crear el usuario " + ex);
            not.showNotification();
            System.out.println("not2 = " + ex);
        }
        try {

            conectarBD();
            senteciaSQL = "UPDATE automovil SET alquiler='Ocupado' WHERE idAutomovil='" + txtIdAuto.getText() + "'";
            ps = con.prepareStatement(senteciaSQL);
            ps.execute();
            con.close();
        } catch (SQLException ex) {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No se pudo actualizar el dato " + ex);
            not.showNotification();
        }
    }

    public void llenarCliente() {
        conectarBD();
        senteciaSQL = "SELECT * FROM cliente WHERE identidad LIKE '" + idCliente + "'";
        System.out.println("this = " + idCliente);
        try {
            ps = con.prepareStatement(senteciaSQL);
            rs = ps.executeQuery();
            while (rs.next()) {
                txtNombre.setText(rs.getString(3));
                txtApellido.setText(rs.getString(4));
                if (rs.getBoolean(7) == true) {
                    txtDiscapacidad.setText("SI");
                } else {
                    txtDiscapacidad.setText("NO");
                }
            }

            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
            System.out.println("not = " + ex);
        }
    }

    public void llenarauto() {
        conectarBD();
        senteciaSQL = "SELECT * FROM automovil WHERE idAutomovil LIKE '" + idAuto + "'";
        System.out.println("this = " + idAuto);
        try {
            ps = con.prepareStatement(senteciaSQL);
            rs = ps.executeQuery();
            while (rs.next()) {
                txtMarca.setText(rs.getString(2));
                txtModelo.setText(rs.getString(3));
            }
            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
        }

    }

    public void actualizar() {

        Boolean tipo;
        if (Rvigente.isSelected()) {

            tipo = true;
            actualizarRegistrosAuto(tipo);

        }
        this.setLocationRelativeTo(null);
    }

    public void actualizarRegistrosAuto(boolean tipo) {
        try {
            conectarBD();
            senteciaSQL = "UPDATE alquilerauto SET documentacion=?,identidadCliente=?,idAutomovil=?,total=? WHERE idalquiler=?";
            ps = con.prepareStatement(senteciaSQL);
            ps.setBoolean(1, tipo);
            ps.setString(2, txtIdCliente.getText());
            ps.setString(3, txtIdAuto.getText());
            ps.setString(4, txtTotal.getText());
            ps.setInt(5, Integer.parseInt(txtidRentaAuto.getText()));
            ps.execute();
            con.close();
            Notification not = new Notification(this, Notification.Type.SUCCESS, Notification.Location.TOP_CENTER, "Datos de usuario Guardados Correctamente");
            not.showNotification();
        } catch (SQLException ex) {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No se pudo actualizar el dato " + ex);
            not.showNotification();
            System.out.println("not = " + ex);
        }
        try {

            conectarBD();
            senteciaSQL = "UPDATE automovil SET alquiler='Disponible' WHERE idAutomovil='" + idAuto + "'";
            ps = con.prepareStatement(senteciaSQL);
            ps.execute();
            con.close();
        } catch (SQLException ex) {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No se pudo actualizar el dato " + ex);
            not.showNotification();
        }
        try {

            conectarBD();
            senteciaSQL = "UPDATE automovil SET alquiler='Ocupado' WHERE idAutomovil='" + txtIdAuto.getText() + "'";
            ps = con.prepareStatement(senteciaSQL);
            ps.execute();
            con.close();
        } catch (SQLException ex) {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No se pudo actualizar el dato " + ex);
            not.showNotification();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grupo = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtModelo = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtIdCliente = new javax.swing.JFormattedTextField();
        jLabel12 = new javax.swing.JLabel();
        Rvencinda = new javax.swing.JRadioButton();
        Rvigente = new javax.swing.JRadioButton();
        txtTotal = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        txtApellido = new javax.swing.JTextField();
        txtMarca = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtidRentaAuto = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        txtDiscapacidad = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        txtIdAuto = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jButton3 = new javax.swing.JButton();
        PUpper = new java.awt.Panel();
        ExitSys = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51), 5));
        jPanel1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(null);

        jLabel2.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel2.setText("Total");
        jPanel2.add(jLabel2);
        jLabel2.setBounds(40, 400, 50, 30);

        jLabel3.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel3.setText("ID Auto");
        jPanel2.add(jLabel3);
        jLabel3.setBounds(30, 20, 80, 30);

        jLabel4.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel4.setText("Modelo");
        jPanel2.add(jLabel4);
        jLabel4.setBounds(40, 360, 60, 30);

        txtModelo.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        jPanel2.add(txtModelo);
        txtModelo.setBounds(130, 360, 250, 30);

        jLabel5.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel5.setText("Vigencia de Licencia");
        jPanel2.add(jLabel5);
        jLabel5.setBounds(20, 65, 160, 30);

        try {
            txtIdCliente.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("#### - #### - #####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtIdCliente.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        txtIdCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtIdClienteKeyReleased(evt);
            }
        });
        jPanel2.add(txtIdCliente);
        txtIdCliente.setBounds(130, 120, 250, 30);

        jLabel12.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel12.setText("Identidad");
        jPanel2.add(jLabel12);
        jLabel12.setBounds(30, 120, 80, 30);

        grupo.add(Rvencinda);
        Rvencinda.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        Rvencinda.setText("Vencida");
        jPanel2.add(Rvencinda);
        Rvencinda.setBounds(290, 70, 101, 21);

        grupo.add(Rvigente);
        Rvigente.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        Rvigente.setText("Vigente");
        jPanel2.add(Rvigente);
        Rvigente.setBounds(200, 70, 80, 21);

        txtTotal.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        txtTotal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtTotalMouseClicked(evt);
            }
        });
        jPanel2.add(txtTotal);
        txtTotal.setBounds(130, 400, 250, 30);

        txtNombre.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        jPanel2.add(txtNombre);
        txtNombre.setBounds(130, 160, 250, 30);

        txtApellido.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        jPanel2.add(txtApellido);
        txtApellido.setBounds(130, 200, 250, 30);

        txtMarca.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        jPanel2.add(txtMarca);
        txtMarca.setBounds(130, 320, 250, 30);

        jLabel6.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel6.setText("ID Automovil");
        jPanel2.add(jLabel6);
        jLabel6.setBounds(10, 280, 110, 30);

        jLabel7.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel7.setText("Discapacidad");
        jPanel2.add(jLabel7);
        jLabel7.setBounds(10, 240, 110, 30);

        jLabel8.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel8.setText("Nombre");
        jPanel2.add(jLabel8);
        jLabel8.setBounds(40, 160, 70, 30);

        jLabel11.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel11.setText("Marca");
        jPanel2.add(jLabel11);
        jLabel11.setBounds(40, 320, 60, 30);

        txtidRentaAuto.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        jPanel2.add(txtidRentaAuto);
        txtidRentaAuto.setBounds(130, 20, 250, 30);

        jLabel13.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel13.setText("Apellido");
        jPanel2.add(jLabel13);
        jLabel13.setBounds(40, 200, 70, 30);

        txtDiscapacidad.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        jPanel2.add(txtDiscapacidad);
        txtDiscapacidad.setBounds(130, 240, 250, 30);

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Transport.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1);
        jButton1.setBounds(390, 280, 50, 40);

        txtIdAuto.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        jPanel2.add(txtIdAuto);
        txtIdAuto.setBounds(130, 280, 250, 30);

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cliente.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2);
        jButton2.setBounds(390, 130, 50, 50);

        jPanel1.add(jPanel2);
        jPanel2.setBounds(10, 60, 450, 430);
        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(730, -10, 2, 2);

        jButton3.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/guardar (2).png"))); // NOI18N
        jButton3.setText("Guardar");
        jButton3.setBorderPainted(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3);
        jButton3.setBounds(150, 510, 200, 50);

        PUpper.setBackground(new java.awt.Color(0, 51, 51));
        PUpper.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PUpperMousePressed(evt);
            }
        });
        PUpper.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                PUpperMouseDragged(evt);
            }
        });
        PUpper.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ExitSys.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/BClose.png"))); // NOI18N
        ExitSys.setContentAreaFilled(false);
        ExitSys.setPreferredSize(new java.awt.Dimension(30, 30));
        ExitSys.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExitSysMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ExitSysMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ExitSysMouseExited(evt);
            }
        });
        ExitSys.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitSysActionPerformed(evt);
            }
        });
        PUpper.add(ExitSys, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 7, 32, 26));

        jLabel20.setFont(new java.awt.Font("Roboto Black", 0, 20)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Software Hotel");
        PUpper.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 7, 191, -1));
        PUpper.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(4, 13, -1, 26));
        PUpper.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 13, -1, 26));
        PUpper.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/LogIc.png"))); // NOI18N
        PUpper.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 7, 30, 30));

        jPanel1.add(PUpper);
        PUpper.setBounds(0, 0, 470, 39);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 468, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 579, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if (txtIdCliente.getText().isEmpty() || txtIdCliente.getText().equals("     -      -      ") || txtIdAuto.getText().isEmpty() || txtTotal.getText().isEmpty() || Rvencinda.isSelected()) {

            if (Rvencinda.isSelected()) {
                Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No puedes alquilar un auto con licencia vencida");
                not.showNotification();
            } else {
                Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "Datos Incompletos, Favor llenar todos los campos");
                not.showNotification();
            }
        } else {

            int cod = 0;
            String identidad = txtIdCliente.getText();
            conectarBD();
            senteciaSQL = "SELECT * FROM alquilerauto WHERE identidadCliente LIKE '" + identidad + "'";
            try {
                ps = con.prepareStatement(senteciaSQL);
                rs = ps.executeQuery();

                while (rs.next()) {
                    cod = 1;
                }
                con.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
            }
            if (cod == 1 && NUM == 1) {
                Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "Este Cliente ya tiene un Auto Alquilado Actualmente");
                not.showNotification();
            } else {
                if (NUM == 1) {

                    registro();
                    this.dispose();

                } else if (NUM == 2) {
                    actualizar();
                    this.dispose();
                }
            }

        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void ExitSysMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseClicked

    }//GEN-LAST:event_ExitSysMouseClicked

    private void ExitSysMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseEntered

    }//GEN-LAST:event_ExitSysMouseEntered

    private void ExitSysMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseExited

    }//GEN-LAST:event_ExitSysMouseExited

    private void ExitSysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitSysActionPerformed
        this.dispose();
    }//GEN-LAST:event_ExitSysActionPerformed

    private void PUpperMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMousePressed
        // TODO add your handling code here:
        //        xMouse = evt.getX();
        //        yMouse = evt.getY();
    }//GEN-LAST:event_PUpperMousePressed

    private void PUpperMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMouseDragged
        // TODO add your handling code here
        //        int x = evt.getXOnScreen();
        //        int y = evt.getYOnScreen();
        //        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_PUpperMouseDragged

    private void txtIdClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdClienteKeyReleased
        int valor = 0;
        int conta = 0;
        String nomconsulta = "Identidad";
        try {
            conectarBD();
            if (nomconsulta.equals("Identidad")) {
                senteciaSQL = ("SELECT COUNT(*) FROM cliente WHERE UPPER(identidad) LIKE (UPPER('%" + txtIdCliente.getText() + "%')) AND estado='Activo'");
                ps = con.prepareStatement(senteciaSQL);
                rs = ps.executeQuery();
            }

            if (rs.next()) {
                valor = rs.getInt(1);
            }

            datosViajesB = new String[valor][8];
            if (nomconsulta.equals("Identidad")) {
                senteciaSQL = ("SELECT * FROM cliente WHERE  UPPER(identidad) LIKE (UPPER('%" + txtIdCliente.getText() + "%')) AND estado='Activo'");
                ps = con.prepareStatement(senteciaSQL);
                rs = ps.executeQuery();
            }
            while (rs.next()) {
                txtNombre.setText(rs.getString(3));
                txtApellido.setText(rs.getString(4));
                txtDiscapacidad.setText(rs.getString(7));
            }

        } catch (Exception e) {
        }
    }//GEN-LAST:event_txtIdClienteKeyReleased

    private void txtTotalMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTotalMouseClicked
        if (txtDiscapacidad.getText().isEmpty()) {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "INGRESE DATOS DE CLIENTE");
            not.showNotification();
        } else if (txtDiscapacidad.equals("SI")) {
            totalDis = 700 * 0.10;
            total = Double.toString(totalDis);
            txtTotal.setText(total);
        } else {
            totalDis = 700 * 0.35;
            total = Double.toString(totalDis);
            txtTotal.setText(total);
        }
    }//GEN-LAST:event_txtTotalMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        SeleccionAutomovil em = new SeleccionAutomovil();
        em.setVisible(true);

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        SeleccionClientes em = new SeleccionClientes();
        em.setVisible(true);
        SeleccionClientes.condicion = 3;
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frameRentaAuto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frameRentaAuto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frameRentaAuto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frameRentaAuto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frameRentaAuto().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ExitSys;
    private java.awt.Panel PUpper;
    private javax.swing.JRadioButton Rvencinda;
    private javax.swing.JRadioButton Rvigente;
    private javax.swing.ButtonGroup grupo;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    public static javax.swing.JTextField txtApellido;
    public static javax.swing.JTextField txtDiscapacidad;
    public static javax.swing.JTextField txtIdAuto;
    public static javax.swing.JFormattedTextField txtIdCliente;
    public static javax.swing.JTextField txtMarca;
    public static javax.swing.JTextField txtModelo;
    public static javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtTotal;
    private javax.swing.JTextField txtidRentaAuto;
    // End of variables declaration//GEN-END:variables
}
