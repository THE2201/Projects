package Reservaciones;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import Conexion.conexionBD;
import java.awt.Color;
import java.awt.Font;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import Componentes.Notification;
import Componentes.MessageDialog;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import proyecto_final.Login;

/*@author A.S. */
public class administracionRentasTransporte extends javax.swing.JFrame {

    String usuario;
    Connection con = null;
    conexionBD conecta;
    String senteciaSQL;
    PreparedStatement ps = null;
    ResultSet rs = null;
    DefaultTableModel modelo;
    Object datosViajes[] = new Object[6];
    Object datosChofer[] = new Object[5];
    Object datosAutos[] = new Object[5];

    TableRowSorter<TableModel> trsViajes;
    TableRowSorter<TableModel> trsChofer;
    TableRowSorter<TableModel> trsAutos;

    String[] titViajes = {"Identidad", "Hora", "Id Cliente", "Nombre Aerolinea", "Direccion", "Costo"};
    String[] titChofer = {"Id Viaje", "Id Chofer", "Id Cliente", "Dias", "Total"};
    String[] titAutos = {"Id Alquiler", "Licencia", "id Cliente", "Id Automovil", "Total"};

    String[][] datosViajesB;
    String[][] datosChoferB;
    String[][] datosAutosB;

    public administracionRentasTransporte() {
        initComponents();
        setLocationRelativeTo(null);
        popumMenuViajes();
        popumMenuChofers();
        popumMenuAutos();
        this.setLocationRelativeTo(null);
        centrarTabla();
        diseñotabla();

    }

    public void conectarBD() {
        conecta = new conexionBD("proyecto_final");
        con = conecta.getConexion();
    }

    public void popumMenuViajes() {
        JMenuItem open = new JMenuItem("Crear", getIcon("/img/crear.png", 25, 25));
        JMenuItem update = new JMenuItem("Actualizar", getIcon("/img/actualizar.png", 25, 25));
        JMenuItem delete = new JMenuItem("Eliminar", getIcon("/img/borrar.png", 25, 25));

        tbViajes.setComponentPopupMenu(tablaviajes);

        tablaviajes.add(open);
        tablaviajes.addSeparator();
        tablaviajes.add(update);
        tablaviajes.addSeparator();
        tablaviajes.add(delete);
        tablaviajes.addSeparator();

        open.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                frameRentaViajes.NUM = 1;
                frameRentaViajes.idAerpuerto = "";
                frameRentaViajes.hora = "";
                frameRentaViajes.idCliente = "";
                frameRentaViajes.nombreA = "";
                frameRentaViajes.DireccionAerolinea = "";
                frameRentaViajes.costo = "";

                limpiarViajes();
                llamarViajes(1);

            }
        });
        update.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int fila = tbViajes.getSelectedRow();
                if (fila >= 0) {
                    frameRentaViajes.NUM = 2;
                    fila = tbViajes.getSelectedRow();
                    frameRentaViajes.idAerpuerto = (tbViajes.getValueAt(fila, 0).toString());
                    frameRentaViajes.hora = (tbViajes.getValueAt(fila, 1).toString());
                    frameRentaViajes.idCliente = (tbViajes.getValueAt(fila, 2).toString());
                    frameRentaViajes.nombreA = (tbViajes.getValueAt(fila, 3).toString());
                    frameRentaViajes.DireccionAerolinea = (tbViajes.getValueAt(fila, 4).toString());
                    frameRentaViajes.costo = (tbViajes.getValueAt(fila, 5).toString());
                    limpiarViajes();
                    llamarViajes(1);
                } else {
                    notificacion();
                }
            }
        });

        delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int fila = tbViajes.getSelectedRow();
                if (fila >= 0) {
                    llamarConfirmacionViajes();
                } else {
                    notificacion();
                }
            }
        });

    }

    public void notificacion() {
        Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.CENTER, "Debe Seleccionar Almenos un Dato en la Tabla");
        not.showNotification();
    }

    public void centrarTabla() {
        DefaultTableCellRenderer tcr = new DefaultTableCellRenderer();
        tcr.setHorizontalAlignment(SwingConstants.CENTER);
        tbViajes.getColumnModel().getColumn(0).setCellRenderer(tcr);
        tbViajes.getColumnModel().getColumn(1).setCellRenderer(tcr);
        tbViajes.getColumnModel().getColumn(2).setCellRenderer(tcr);
        tbViajes.getColumnModel().getColumn(3).setCellRenderer(tcr);
        tbViajes.getColumnModel().getColumn(4).setCellRenderer(tcr);
        tbViajes.getColumnModel().getColumn(5).setCellRenderer(tcr);

        tbChofer.getColumnModel().getColumn(0).setCellRenderer(tcr);
        tbChofer.getColumnModel().getColumn(1).setCellRenderer(tcr);
        tbChofer.getColumnModel().getColumn(2).setCellRenderer(tcr);
        tbChofer.getColumnModel().getColumn(3).setCellRenderer(tcr);
        tbChofer.getColumnModel().getColumn(4).setCellRenderer(tcr);

        tbAutos.getColumnModel().getColumn(0).setCellRenderer(tcr);
        tbAutos.getColumnModel().getColumn(1).setCellRenderer(tcr);
        tbAutos.getColumnModel().getColumn(2).setCellRenderer(tcr);
        tbAutos.getColumnModel().getColumn(3).setCellRenderer(tcr);
        tbAutos.getColumnModel().getColumn(4).setCellRenderer(tcr);

        ((DefaultTableCellRenderer) tbChofer.getTableHeader().getDefaultRenderer())
                .setHorizontalAlignment(SwingConstants.CENTER);

        ((DefaultTableCellRenderer) tbViajes.getTableHeader().getDefaultRenderer())
                .setHorizontalAlignment(SwingConstants.CENTER);

        ((DefaultTableCellRenderer) tbAutos.getTableHeader().getDefaultRenderer())
                .setHorizontalAlignment(SwingConstants.CENTER);
    }

    public void diseñotabla() {
        tbViajes.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tbViajes.getTableHeader().setOpaque(false);
        tbViajes.getTableHeader().setBackground(new Color(32, 136, 203));
        tbViajes.getTableHeader().setForeground(new Color(255, 255, 255));
        tbViajes.setRowHeight(25);

        tbChofer.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tbChofer.getTableHeader().setOpaque(false);
        tbChofer.getTableHeader().setBackground(new Color(32, 136, 203));
        tbChofer.getTableHeader().setForeground(new Color(255, 255, 255));
        tbChofer.setRowHeight(25);

        tbAutos.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tbAutos.getTableHeader().setOpaque(false);
        tbAutos.getTableHeader().setBackground(new Color(32, 136, 203));
        tbAutos.getTableHeader().setForeground(new Color(255, 255, 255));
        tbAutos.setRowHeight(25);
    }

    public void limpiarViajes() {
        int fila = tbViajes.getRowCount();
        for (int i = fila - 1; i >= 0; i--) {
            modelo.removeRow(i);
        }
    }

    public void llamarConfirmacionViajes() {

        MessageDialog obj = new MessageDialog(this);
        obj.showMessage("Estas seguro?", "Recuerda una vez eliminado no hay marcha atras");

        if (obj.getMessageType() == MessageDialog.MessageType.OK) {
            int fila = tbViajes.getSelectedRow();
            try {
                conectarBD();
                //senteciaSQL = "DELETE FROM empleado WHERE identidad=" +txtCodigo.getText().trim();
                senteciaSQL = "UPDATE viaje_aeropuerto SET estado='Inactivo' WHERE idviaje LIKE  '" + tbViajes.getValueAt(fila, 0).toString() + "'";
                ps = con.prepareStatement(senteciaSQL);
                ps.execute();
                con.close();
                Notification not = new Notification(this, Notification.Type.SUCCESS, Notification.Location.TOP_CENTER, "Datos Eliminados Correctamente ");
                not.showNotification();
                limpiarViajes();
                leerViajes();

            } catch (SQLException ex) {
                Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No se pudieron eliminar los datos " + ex);
                not.showNotification();
            }
        } else {
            System.out.println("User click cancel");
        }

    }

    public void llamarViajes(int num) {
        if (num == 1) {
            frameRentaViajes em = new frameRentaViajes();
            em.setVisible(true);
        }
    }

    public void leerViajes() {
        conectarBD();
        senteciaSQL = "SELECT * FROM viaje_aeropuerto WHERE estado LIKE 'Activo'";
        try {
            ps = con.prepareStatement(senteciaSQL);
            rs = ps.executeQuery();
            modelo = (DefaultTableModel) tbViajes.getModel();
            while (rs.next()) {
                datosViajes[0] = (rs.getInt(1));
                datosViajes[1] = (rs.getString(2));
                datosViajes[2] = (rs.getString(3));
                datosViajes[3] = (rs.getString(4));
                datosViajes[4] = (rs.getString(5));
                datosViajes[5] = (rs.getDouble(6));
                modelo.addRow(datosViajes);
            }
            tbViajes.setModel(modelo);
            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
        }

    }

    public Icon getIcon(String ruta, int widht, int height) {
        Icon icono = new ImageIcon(new ImageIcon(getClass().getResource(ruta)).getImage().getScaledInstance(widht, height, 0));
        return icono;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //CHOFER
    public void popumMenuChofers() {
        JMenuItem open = new JMenuItem("Crear", getIcon("/img/crear.png", 25, 25));
        JMenuItem update = new JMenuItem("Actualizar", getIcon("/img/actualizar.png", 25, 25));
        JMenuItem delete = new JMenuItem("Eliminar", getIcon("/img/borrar.png", 25, 25));

        tbChofer.setComponentPopupMenu(tablachofer);

        tablachofer.add(open);
        tablachofer.addSeparator();
        tablachofer.add(update);
        tablachofer.addSeparator();
        tablachofer.add(delete);
        tablachofer.addSeparator();

        open.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                frameRentaChofer.NUM = 1;
                frameRentaChofer.idAlquiler = "";
                frameRentaChofer.idchofer = "";
                frameRentaChofer.idCliente = "";
                frameRentaChofer.dias = "";
                frameRentaChofer.costo = "";

                limpiarChofer();
                llamarChofer(1);

            }
        });
        update.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int fila = tbChofer.getSelectedRow();
                if (fila >= 0) {
                    frameRentaChofer.NUM = 2;
                    fila = tbChofer.getSelectedRow();
                    frameRentaChofer.idAlquiler = (tbChofer.getValueAt(fila, 0).toString());
                    frameRentaChofer.idchofer = (tbChofer.getValueAt(fila, 1).toString());
                    frameRentaChofer.idCliente = (tbChofer.getValueAt(fila, 2).toString());
                    frameRentaChofer.dias = (tbChofer.getValueAt(fila, 3).toString());
                    frameRentaChofer.costo = (tbChofer.getValueAt(fila, 4).toString());
                    limpiarChofer();
                    llamarChofer(1);
                } else {
                    notificacion();
                }
            }
        });

        delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int fila = tbChofer.getSelectedRow();
                if (fila >= 0) {
                    llamarConfirmacionChofer();
                } else {
                    notificacion();
                }
            }
        });

    }

    public void limpiarChofer() {
        int fila = tbChofer.getRowCount();
        for (int i = fila - 1; i >= 0; i--) {
            modelo.removeRow(i);
        }
    }

    public void llamarConfirmacionChofer() {

        MessageDialog obj = new MessageDialog(this);
        obj.showMessage("Estas seguro?", "Recuerda una vez eliminado no hay marcha atras");

        if (obj.getMessageType() == MessageDialog.MessageType.OK) {
            int fila = tbChofer.getSelectedRow();
            System.out.println(tbChofer.getValueAt(fila, 0).toString());
            try {
                conectarBD();
                //senteciaSQL = "DELETE FROM empleado WHERE identidad=" +txtCodigo.getText().trim();
                senteciaSQL = "UPDATE alquilerchofer SET estado='Inactivo' WHERE idalquiler LIKE  '" + tbChofer.getValueAt(fila, 0).toString() + "'";
                ps = con.prepareStatement(senteciaSQL);
                ps.execute();
                con.close();
                Notification not = new Notification(this, Notification.Type.SUCCESS, Notification.Location.TOP_CENTER, "Datos Eliminados Correctamente ");
                not.showNotification();
                limpiarChofer();
                leerChofer();

            } catch (SQLException ex) {
                Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No se pudieron eliminar los datos " + ex);
                not.showNotification();
            }
        } else {
            System.out.println("User click cancel");
        }

    }

    public void llamarChofer(int num) {
        if (num == 1) {
            frameRentaChofer am = new frameRentaChofer();
            am.setVisible(true);
        }
    }

    public void leerChofer() {
        conectarBD();
        senteciaSQL = "SELECT * FROM alquilerchofer WHERE estado LIKE 'Activo'";
        try {
            ps = con.prepareStatement(senteciaSQL);
            rs = ps.executeQuery();
            modelo = (DefaultTableModel) tbChofer.getModel();
            while (rs.next()) {
                datosChofer[0] = (rs.getInt(1));
                datosChofer[1] = (rs.getString(2));
                datosChofer[2] = (rs.getString(3));
                datosChofer[3] = (rs.getInt(4));
                datosChofer[4] = (rs.getDouble(5));
                modelo.addRow(datosChofer);
            }
            tbChofer.setModel(modelo);
            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
        }

    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //AUTO
    public void popumMenuAutos() {
        JMenuItem open = new JMenuItem("Crear", getIcon("/img/crear.png", 25, 25));
        JMenuItem update = new JMenuItem("Actualizar", getIcon("/img/actualizar.png", 25, 25));
        JMenuItem delete = new JMenuItem("Eliminar", getIcon("/img/borrar.png", 25, 25));

        tbAutos.setComponentPopupMenu(tablaautos);

        tablaautos.add(open);
        tablaautos.addSeparator();
        tablaautos.add(update);
        tablaautos.addSeparator();
        tablaautos.add(delete);
        tablaautos.addSeparator();

        open.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                frameRentaAuto.NUM = 1;
                frameRentaAuto.idAlquiler = "";
                frameRentaAuto.Vigenciar = "";
                frameRentaAuto.idCliente = "";
                frameRentaAuto.idAuto = "";
                frameRentaAuto.total = "";

                limpiarAuto();
                llamarAuto(1);

            }
        });
        update.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int fila = tbAutos.getSelectedRow();
                if (fila >= 0) {
                    frameRentaAuto.NUM = 2;
                    fila = tbAutos.getSelectedRow();
                    frameRentaAuto.idAlquiler = (tbAutos.getValueAt(fila, 0).toString());
                    frameRentaAuto.Vigenciar = (tbAutos.getValueAt(fila, 1).toString());
                    frameRentaAuto.idCliente = (tbAutos.getValueAt(fila, 2).toString());
                    frameRentaAuto.idAuto = (tbAutos.getValueAt(fila, 3).toString());
                    frameRentaAuto.total = (tbAutos.getValueAt(fila, 4).toString());
                    limpiarAuto();
                    llamarAuto(1);
                } else {
                    notificacion();
                }
            }
        });

        delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int fila = tbAutos.getSelectedRow();
                if (fila >= 0) {
                    llamarConfirmacionAuto();
                } else {
                    notificacion();
                }
            }
        });

    }

    public void limpiarAuto() {
        int fila = tbAutos.getRowCount();
        for (int i = fila - 1; i >= 0; i--) {
            modelo.removeRow(i);
        }
    }

    public void llamarConfirmacionAuto() {

        MessageDialog obj = new MessageDialog(this);
        obj.showMessage("Estas seguro?", "Recuerda una vez eliminado no hay marcha atras");

        if (obj.getMessageType() == MessageDialog.MessageType.OK) {
            int fila = tbAutos.getSelectedRow();
            System.out.println(tbAutos.getValueAt(fila, 0).toString());
            try {
                conectarBD();
                //senteciaSQL = "DELETE FROM empleado WHERE identidad=" +txtCodigo.getText().trim();
                senteciaSQL = "UPDATE alquilerauto SET estado='Inactivo' WHERE idalquiler LIKE  '" + tbAutos.getValueAt(fila, 0).toString() + "'";
                ps = con.prepareStatement(senteciaSQL);
                ps.execute();
                con.close();
                Notification not = new Notification(this, Notification.Type.SUCCESS, Notification.Location.TOP_CENTER, "Datos Eliminados Correctamente ");
                not.showNotification();
                limpiarAuto();
                leerAuto();

            } catch (SQLException ex) {
                Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No se pudieron eliminar los datos " + ex);
                not.showNotification();
            }
        } else {
            System.out.println("User click cancel");
        }

    }

    public void llamarAuto(int num) {
        if (num == 1) {
            frameRentaAuto au = new frameRentaAuto();
            au.setVisible(true);
        }
    }

    public void leerAuto() {
        conectarBD();
        senteciaSQL = "SELECT * FROM alquilerauto WHERE estado LIKE 'Activo'";
        try {
            ps = con.prepareStatement(senteciaSQL);
            rs = ps.executeQuery();
            modelo = (DefaultTableModel) tbAutos.getModel();
            while (rs.next()) {
                datosAutos[0] = (rs.getInt(1));
                if (rs.getBoolean(2) == true) {
                    datosAutos[1] = "Si";
                } else {
                    datosAutos[1] = "No";
                }
                datosAutos[2] = (rs.getString(3));
                datosAutos[3] = (rs.getInt(4));
                datosAutos[4] = (rs.getDouble(5));

                modelo.addRow(datosAutos);
            }
            tbAutos.setModel(modelo);
            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tablaviajes = new javax.swing.JPopupMenu();
        tablachofer = new javax.swing.JPopupMenu();
        tablaautos = new javax.swing.JPopupMenu();
        TabbedP = new javax.swing.JTabbedPane();
        Viaje = new java.awt.Panel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbViajes = new javax.swing.JTable();
        jPanel6 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        txtBuscarCliente = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        cbxCliente = new javax.swing.JComboBox<>();
        btnleer = new javax.swing.JButton();
        btnagregar = new javax.swing.JButton();
        btnactualizar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        bntLimpiar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        Chofer = new java.awt.Panel();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbChofer = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btnleer1 = new javax.swing.JButton();
        txtBuscarCliente1 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        cbxCliente1 = new javax.swing.JComboBox<>();
        btnleer4 = new javax.swing.JButton();
        btnactualizar1 = new javax.swing.JButton();
        btnEliminar1 = new javax.swing.JButton();
        bntLimpiar1 = new javax.swing.JButton();
        Auto = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbAutos = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        btnleer6 = new javax.swing.JButton();
        txtBuscarCliente2 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        cbxCliente2 = new javax.swing.JComboBox<>();
        btnleer7 = new javax.swing.JButton();
        btnactualizar2 = new javax.swing.JButton();
        btnEliminar2 = new javax.swing.JButton();
        bntLimpiar2 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        MinimizeSys = new javax.swing.JButton();
        ExitSys = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Reservaciones");
        setFocusCycleRoot(false);
        setMinimumSize(new java.awt.Dimension(1000, 800));
        setName("ResForm"); // NOI18N
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TabbedP.setBackground(new java.awt.Color(102, 102, 102));
        TabbedP.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N

        Viaje.setBackground(new java.awt.Color(255, 255, 255));
        Viaje.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(null);

        tbViajes.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        tbViajes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id Viaje", "Hora", "Id Cliente", "Nombre de Aerolinea", "Dirreccion", "Costo"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Double.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tbViajes.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tbViajes.setGridColor(new java.awt.Color(204, 204, 204));
        tbViajes.setShowGrid(true);
        tbViajes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbViajesMouseClicked(evt);
            }
        });
        tbViajes.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tbViajesKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(tbViajes);

        jPanel2.add(jScrollPane1);
        jScrollPane1.setBounds(0, 0, 960, 460);

        Viaje.add(jPanel2);
        jPanel2.setBounds(22, 240, 960, 460);

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 255), 10));
        jPanel6.setLayout(null);

        jLabel3.setFont(new java.awt.Font("Bodoni Bd BT", 0, 24)); // NOI18N
        jLabel3.setText("Buscar");
        jPanel6.add(jLabel3);
        jLabel3.setBounds(90, 150, 80, 38);

        txtBuscarCliente.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        txtBuscarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBuscarClienteActionPerformed(evt);
            }
        });
        txtBuscarCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarClienteKeyReleased(evt);
            }
        });
        jPanel6.add(txtBuscarCliente);
        txtBuscarCliente.setBounds(180, 160, 294, 30);

        jLabel1.setFont(new java.awt.Font("Corbel", 1, 36)); // NOI18N
        jLabel1.setText("RENTA DE VIAJES");
        jPanel6.add(jLabel1);
        jLabel1.setBounds(380, 60, 299, 60);

        cbxCliente.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        cbxCliente.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Identidad" }));
        jPanel6.add(cbxCliente);
        cbxCliente.setBounds(490, 160, 140, 30);

        btnleer.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        btnleer.setForeground(new java.awt.Color(102, 102, 255));
        btnleer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/leer (3).png"))); // NOI18N
        btnleer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnleerMouseClicked(evt);
            }
        });
        btnleer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnleerActionPerformed(evt);
            }
        });
        jPanel6.add(btnleer);
        btnleer.setBounds(640, 150, 50, 50);

        btnagregar.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        btnagregar.setForeground(new java.awt.Color(102, 102, 255));
        btnagregar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/crear2.png"))); // NOI18N
        btnagregar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnagregarMouseClicked(evt);
            }
        });
        btnagregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnagregarActionPerformed(evt);
            }
        });
        jPanel6.add(btnagregar);
        btnagregar.setBounds(700, 150, 50, 50);

        btnactualizar.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        btnactualizar.setForeground(new java.awt.Color(102, 102, 255));
        btnactualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/actualizar (6).png"))); // NOI18N
        btnactualizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnactualizarMouseClicked(evt);
            }
        });
        btnactualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnactualizarActionPerformed(evt);
            }
        });
        jPanel6.add(btnactualizar);
        btnactualizar.setBounds(760, 150, 50, 50);

        btnEliminar.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        btnEliminar.setForeground(new java.awt.Color(102, 102, 255));
        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/eliminar (1).png"))); // NOI18N
        btnEliminar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEliminarMouseClicked(evt);
            }
        });
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        jPanel6.add(btnEliminar);
        btnEliminar.setBounds(820, 150, 50, 50);

        bntLimpiar.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        bntLimpiar.setForeground(new java.awt.Color(102, 102, 255));
        bntLimpiar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/borrar2.png"))); // NOI18N
        bntLimpiar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bntLimpiarMouseClicked(evt);
            }
        });
        bntLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntLimpiarActionPerformed(evt);
            }
        });
        jPanel6.add(bntLimpiar);
        bntLimpiar.setBounds(880, 150, 50, 50);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/viaje.jpeg"))); // NOI18N
        jPanel6.add(jLabel2);
        jLabel2.setBounds(690, 20, 160, 128);

        Viaje.add(jPanel6);
        jPanel6.setBounds(0, 0, 1000, 740);

        TabbedP.addTab("     Viaje Areropuerto         ", Viaje);

        Chofer.setBackground(new java.awt.Color(102, 102, 102));
        Chofer.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        Chofer.setLayout(null);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 255), 10));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(null);

        tbChofer.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        tbChofer.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Alquiler", "ID Chofer", "ID Cliente", "Dias", "Total"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tbChofer.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tbChofer.setGridColor(new java.awt.Color(204, 204, 204));
        tbChofer.setShowGrid(true);
        tbChofer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbChoferMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbChofer);

        jPanel3.add(jScrollPane2);
        jScrollPane2.setBounds(10, 0, 950, 480);

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 221, 970, 490));

        jLabel4.setFont(new java.awt.Font("Corbel", 1, 36)); // NOI18N
        jLabel4.setText("RENTAS DE CHOFERES");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 70, 380, 60));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/conductor.png"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 20, 140, 110));

        btnleer1.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        btnleer1.setForeground(new java.awt.Color(102, 102, 255));
        btnleer1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/leer (3).png"))); // NOI18N
        btnleer1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnleer1MouseClicked(evt);
            }
        });
        btnleer1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnleer1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnleer1, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 160, 50, 50));

        txtBuscarCliente1.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        txtBuscarCliente1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarCliente1KeyReleased(evt);
            }
        });
        jPanel1.add(txtBuscarCliente1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 170, 294, -1));

        jLabel6.setFont(new java.awt.Font("Bodoni Bd BT", 0, 24)); // NOI18N
        jLabel6.setText("Buscar");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 160, 80, 38));

        cbxCliente1.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        cbxCliente1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Identidad Cliente", "Identidad Chofer" }));
        jPanel1.add(cbxCliente1, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 170, 190, 30));

        btnleer4.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        btnleer4.setForeground(new java.awt.Color(102, 102, 255));
        btnleer4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/crear2.png"))); // NOI18N
        btnleer4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnleer4MouseClicked(evt);
            }
        });
        btnleer4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnleer4ActionPerformed(evt);
            }
        });
        jPanel1.add(btnleer4, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 160, 50, 50));

        btnactualizar1.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        btnactualizar1.setForeground(new java.awt.Color(102, 102, 255));
        btnactualizar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/actualizar (6).png"))); // NOI18N
        btnactualizar1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnactualizar1MouseClicked(evt);
            }
        });
        btnactualizar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnactualizar1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnactualizar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 160, 50, 50));

        btnEliminar1.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        btnEliminar1.setForeground(new java.awt.Color(102, 102, 255));
        btnEliminar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/eliminar (1).png"))); // NOI18N
        btnEliminar1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEliminar1MouseClicked(evt);
            }
        });
        btnEliminar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminar1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnEliminar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 160, 50, 50));

        bntLimpiar1.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        bntLimpiar1.setForeground(new java.awt.Color(102, 102, 255));
        bntLimpiar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/borrar2.png"))); // NOI18N
        bntLimpiar1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bntLimpiar1MouseClicked(evt);
            }
        });
        bntLimpiar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntLimpiar1ActionPerformed(evt);
            }
        });
        jPanel1.add(bntLimpiar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 160, 50, 50));

        Chofer.add(jPanel1);
        jPanel1.setBounds(0, 0, 1000, 730);

        TabbedP.addTab("     Alquiler de Chofer     ", Chofer);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 255), 10));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setLayout(null);

        tbAutos.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        tbAutos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Alquiler", "Licencia", "ID Cliente", "ID Automovil", "Total"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Double.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tbAutos.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tbAutos.setGridColor(new java.awt.Color(204, 204, 204));
        tbAutos.setShowGrid(true);
        tbAutos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbAutosMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tbAutos);

        jPanel5.add(jScrollPane3);
        jScrollPane3.setBounds(10, 0, 950, 480);

        jPanel4.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 221, 970, 490));

        jLabel7.setFont(new java.awt.Font("Corbel", 1, 36)); // NOI18N
        jLabel7.setText("RENTAS DE AUTOS");
        jPanel4.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 60, 330, 60));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/carr.png"))); // NOI18N
        jPanel4.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 30, 150, 110));

        btnleer6.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        btnleer6.setForeground(new java.awt.Color(102, 102, 255));
        btnleer6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/leer (3).png"))); // NOI18N
        btnleer6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnleer6MouseClicked(evt);
            }
        });
        btnleer6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnleer6ActionPerformed(evt);
            }
        });
        jPanel4.add(btnleer6, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 160, 50, 50));

        txtBuscarCliente2.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        txtBuscarCliente2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarCliente2KeyReleased(evt);
            }
        });
        jPanel4.add(txtBuscarCliente2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 170, 294, -1));

        jLabel9.setFont(new java.awt.Font("Bodoni Bd BT", 0, 24)); // NOI18N
        jLabel9.setText("Buscar");
        jPanel4.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 160, 80, 38));

        cbxCliente2.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        cbxCliente2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Identidad" }));
        jPanel4.add(cbxCliente2, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 170, 140, 30));

        btnleer7.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        btnleer7.setForeground(new java.awt.Color(102, 102, 255));
        btnleer7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/crear2.png"))); // NOI18N
        btnleer7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnleer7MouseClicked(evt);
            }
        });
        btnleer7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnleer7ActionPerformed(evt);
            }
        });
        jPanel4.add(btnleer7, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 160, 50, 50));

        btnactualizar2.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        btnactualizar2.setForeground(new java.awt.Color(102, 102, 255));
        btnactualizar2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/actualizar (6).png"))); // NOI18N
        btnactualizar2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnactualizar2MouseClicked(evt);
            }
        });
        btnactualizar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnactualizar2ActionPerformed(evt);
            }
        });
        jPanel4.add(btnactualizar2, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 160, 50, 50));

        btnEliminar2.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        btnEliminar2.setForeground(new java.awt.Color(102, 102, 255));
        btnEliminar2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/eliminar (1).png"))); // NOI18N
        btnEliminar2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEliminar2MouseClicked(evt);
            }
        });
        btnEliminar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminar2ActionPerformed(evt);
            }
        });
        jPanel4.add(btnEliminar2, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 160, 50, 50));

        bntLimpiar2.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        bntLimpiar2.setForeground(new java.awt.Color(102, 102, 255));
        bntLimpiar2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/borrar2.png"))); // NOI18N
        bntLimpiar2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bntLimpiar2MouseClicked(evt);
            }
        });
        bntLimpiar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntLimpiar2ActionPerformed(evt);
            }
        });
        jPanel4.add(bntLimpiar2, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 160, 50, 50));

        javax.swing.GroupLayout AutoLayout = new javax.swing.GroupLayout(Auto);
        Auto.setLayout(AutoLayout);
        AutoLayout.setHorizontalGroup(
            AutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AutoLayout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 1000, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        AutoLayout.setVerticalGroup(
            AutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AutoLayout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 724, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 3, Short.MAX_VALUE))
        );

        TabbedP.addTab("     Alquiler de Automovil     ", Auto);

        getContentPane().add(TabbedP, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 1000, 760));

        jPanel7.setBackground(new java.awt.Color(0, 153, 255));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel20.setFont(new java.awt.Font("Roboto Black", 1, 20)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Software Hotel");
        jPanel7.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 5, 191, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/LogIc.png"))); // NOI18N
        jPanel7.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 5, 30, 30));

        MinimizeSys.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/BMin.png"))); // NOI18N
        MinimizeSys.setContentAreaFilled(false);
        MinimizeSys.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MinimizeSysActionPerformed(evt);
            }
        });
        jPanel7.add(MinimizeSys, new org.netbeans.lib.awtextra.AbsoluteConstraints(921, 7, 30, 26));

        ExitSys.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/BClose.png"))); // NOI18N
        ExitSys.setContentAreaFilled(false);
        ExitSys.setPreferredSize(new java.awt.Dimension(30, 30));
        ExitSys.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExitSysMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ExitSysMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ExitSysMouseExited(evt);
            }
        });
        ExitSys.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitSysActionPerformed(evt);
            }
        });
        jPanel7.add(ExitSys, new org.netbeans.lib.awtextra.AbsoluteConstraints(958, 7, 32, 26));

        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1000, 40));

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void btnEliminar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminar2ActionPerformed
        int fila = tbAutos.getSelectedRow();
        if (fila >= 0) {
            llamarConfirmacionAuto();
        } else {
            notificacion();
        }
    }//GEN-LAST:event_btnEliminar2ActionPerformed

    private void btnEliminar2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliminar2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnEliminar2MouseClicked

    private void btnactualizar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnactualizar2ActionPerformed
        int fila = tbAutos.getSelectedRow();
        if (fila >= 0) {
            frameRentaAuto.NUM = 2;
            frameRentaAuto.idAlquiler = (tbAutos.getValueAt(fila, 0).toString());
            frameRentaAuto.Vigenciar = (tbAutos.getValueAt(fila, 1).toString());
            frameRentaAuto.idCliente = (tbAutos.getValueAt(fila, 2).toString());
            frameRentaAuto.idAuto = (tbAutos.getValueAt(fila, 3).toString());
            frameRentaAuto.total = (tbAutos.getValueAt(fila, 4).toString());
            limpiarAuto();
            llamarAuto(1);
        } else {
            notificacion();
        }
    }//GEN-LAST:event_btnactualizar2ActionPerformed

    private void btnactualizar2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnactualizar2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnactualizar2MouseClicked

    private void btnleer7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnleer7ActionPerformed

        frameRentaAuto.NUM = 1;
        frameRentaAuto.idAlquiler = "";
        frameRentaAuto.Vigenciar = "";
        frameRentaAuto.idCliente = "";
        frameRentaAuto.idAuto = "";
        frameRentaAuto.total = "";

        limpiarAuto();
        llamarAuto(1);


    }//GEN-LAST:event_btnleer7ActionPerformed

    private void btnleer7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnleer7MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnleer7MouseClicked

    private void txtBuscarCliente2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarCliente2KeyReleased
        TableRowSorter<TableModel> trsCliente;
        int valor = 0;
        int conta = 0;
        String nomconsulta = cbxCliente2.getSelectedItem().toString();

        String aux = "" + txtBuscarCliente.getText();
        try {
            conectarBD();
            if (nomconsulta.equals("Identidad")) {
                senteciaSQL = ("SELECT COUNT(*) FROM alquilerauto WHERE UPPER(identidadCliente) LIKE (UPPER('%" + txtBuscarCliente.getText() + "%')) AND estado='Activo'");
                ps = con.prepareStatement(senteciaSQL);
                rs = ps.executeQuery();
            }

            if (rs.next()) {
                valor = rs.getInt(1);
            }

            datosAutosB = new String[valor][5];
            if (nomconsulta.equals("Identidad")) {
                senteciaSQL = ("SELECT * FROM alquilerauto WHERE  UPPER(identidadCliente) LIKE (UPPER('%" + txtBuscarCliente.getText() + "%')) AND estado='Activo'");
                ps = con.prepareStatement(senteciaSQL);
                rs = ps.executeQuery();
            }
            while (rs.next()) {
                datosAutosB[conta][0] = rs.getString("idalquiler");
                if (rs.getBoolean("documentacion") == true) {
                    datosAutosB[conta][1] = ("SI");
                } else {
                    datosAutosB[conta][1] = ("NO");
                }
                datosAutosB[conta][2] = rs.getString("identidadCliente");
                datosAutosB[conta][3] = rs.getString("idAutomovil");
                datosAutosB[conta][4] = rs.getString("total");
                conta = conta + 1;
            }
            modelo = new DefaultTableModel(datosAutosB, titAutos) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };

            tbAutos.setModel(modelo);
            trsCliente = new TableRowSorter<>(modelo);
            tbAutos.setRowSorter(trsCliente);
            centrarTabla();
            diseñotabla();
        } catch (Exception e) {
        }
    }//GEN-LAST:event_txtBuscarCliente2KeyReleased

    private void btnleer6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnleer6ActionPerformed
        limpiarAuto();
        leerAuto();
    }//GEN-LAST:event_btnleer6ActionPerformed

    private void btnleer6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnleer6MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnleer6MouseClicked

    private void tbAutosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbAutosMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tbAutosMouseClicked

    private void btnEliminar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminar1ActionPerformed
        int fila = tbChofer.getSelectedRow();
        if (fila >= 0) {
            llamarConfirmacionChofer();
        } else {
            notificacion();
        }
    }//GEN-LAST:event_btnEliminar1ActionPerformed

    private void btnEliminar1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliminar1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnEliminar1MouseClicked

    private void btnactualizar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnactualizar1ActionPerformed
        int fila = tbChofer.getSelectedRow();
        if (fila >= 0) {
            frameRentaChofer.NUM = 2;
            fila = tbChofer.getSelectedRow();
            frameRentaChofer.idAlquiler = (tbChofer.getValueAt(fila, 0).toString());
            frameRentaChofer.idchofer = (tbChofer.getValueAt(fila, 1).toString());
            frameRentaChofer.idCliente = (tbChofer.getValueAt(fila, 2).toString());
            frameRentaChofer.dias = (tbChofer.getValueAt(fila, 3).toString());
            frameRentaChofer.costo = (tbChofer.getValueAt(fila, 4).toString());
            limpiarChofer();
            llamarChofer(1);
        } else {
            notificacion();
        }
    }//GEN-LAST:event_btnactualizar1ActionPerformed

    private void btnactualizar1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnactualizar1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnactualizar1MouseClicked

    private void btnleer4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnleer4ActionPerformed

        frameRentaChofer.NUM = 1;
        frameRentaChofer.idAlquiler = "";
        frameRentaChofer.idchofer = "";
        frameRentaChofer.idCliente = "";
        frameRentaChofer.dias = "";
        frameRentaChofer.costo = "";

        limpiarChofer();
        llamarChofer(1);


    }//GEN-LAST:event_btnleer4ActionPerformed

    private void btnleer4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnleer4MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnleer4MouseClicked

    private void txtBuscarCliente1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarCliente1KeyReleased

        TableRowSorter<TableModel> trsCliente;
        int valor = 0;
        int conta = 0;
        String nomconsulta = cbxCliente1.getSelectedItem().toString();

        String aux = "" + txtBuscarCliente.getText();
        try {
            conectarBD();
            if (nomconsulta.equals("Identidad Cliente")) {
                senteciaSQL = ("SELECT COUNT(*) FROM alquilerchofer WHERE UPPER(identidadCliente) LIKE (UPPER('%" + txtBuscarCliente.getText() + "%')) AND estado LIKE 'Activo'");
                ps = con.prepareStatement(senteciaSQL);
                rs = ps.executeQuery();
            } else if (nomconsulta.equals("Identidad Chofer")) {
                senteciaSQL = ("SELECT COUNT(*) FROM alquilerchofer WHERE UPPER(identidadChofer) LIKE (UPPER('%" + txtBuscarCliente.getText() + "%')) AND estado LIKE 'Activo'");
                ps = con.prepareStatement(senteciaSQL);
                rs = ps.executeQuery();
            }

            if (rs.next()) {
                valor = rs.getInt(1);
            }

            datosChoferB = new String[valor][5];
            if (nomconsulta.equals("Identidad Cliente")) {
                senteciaSQL = ("SELECT * FROM alquilerchofer WHERE  UPPER(identidadCliente) LIKE (UPPER('%" + txtBuscarCliente.getText() + "%')) AND estado LIKE 'Activo'");
                ps = con.prepareStatement(senteciaSQL);
                rs = ps.executeQuery();
            } else if (nomconsulta.equals("Identidad Chofer")) {
                senteciaSQL = ("SELECT COUNT(*) FROM alquilerchofer WHERE UPPER(identidadChofer) LIKE (UPPER('%" + txtBuscarCliente.getText() + "%')) AND estado LIKE 'Activo'");
                ps = con.prepareStatement(senteciaSQL);
                rs = ps.executeQuery();
            }
            while (rs.next()) {
                datosChoferB[conta][0] = rs.getString("idalquiler");
                datosChoferB[conta][1] = rs.getString("identidadChofer");
                datosChoferB[conta][2] = rs.getString("identidadCliente");
                datosChoferB[conta][3] = rs.getString("dias");
                datosChoferB[conta][4] = rs.getString("total");
                System.out.println("pri");
                conta = conta + 1;
            }
            modelo = new DefaultTableModel(datosChoferB, titChofer) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            tbChofer.setModel(modelo);
            trsCliente = new TableRowSorter<>(modelo);
            tbChofer.setRowSorter(trsCliente);
            centrarTabla();
            diseñotabla();
        } catch (Exception e) {
        }
    }//GEN-LAST:event_txtBuscarCliente1KeyReleased

    private void btnleer1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnleer1ActionPerformed
        limpiarChofer();
        leerChofer();
    }//GEN-LAST:event_btnleer1ActionPerformed

    private void btnleer1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnleer1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnleer1MouseClicked

    private void tbChoferMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbChoferMouseClicked

    }//GEN-LAST:event_tbChoferMouseClicked

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int fila = tbViajes.getSelectedRow();
        if (fila >= 0) {
            llamarConfirmacionViajes();
        } else {
            notificacion();
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnEliminarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliminarMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnEliminarMouseClicked

    private void btnactualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnactualizarActionPerformed
        int fila = tbViajes.getSelectedRow();
        if (fila >= 0) {
            frameRentaViajes.NUM = 2;
            fila = tbViajes.getSelectedRow();
            frameRentaViajes.idAerpuerto = (tbViajes.getValueAt(fila, 0).toString());
            frameRentaViajes.hora = (tbViajes.getValueAt(fila, 1).toString());
            frameRentaViajes.idCliente = (tbViajes.getValueAt(fila, 2).toString());
            frameRentaViajes.nombreA = (tbViajes.getValueAt(fila, 3).toString());
            frameRentaViajes.DireccionAerolinea = (tbViajes.getValueAt(fila, 4).toString());
            frameRentaViajes.costo = (tbViajes.getValueAt(fila, 5).toString());
            limpiarViajes();
            llamarViajes(1);
        } else {
            notificacion();
        }
    }//GEN-LAST:event_btnactualizarActionPerformed

    private void btnactualizarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnactualizarMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnactualizarMouseClicked

    private void btnagregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnagregarActionPerformed

        frameRentaViajes.NUM = 1;
        frameRentaViajes.idAerpuerto = "";
        frameRentaViajes.hora = "";
        frameRentaViajes.idCliente = "";
        frameRentaViajes.nombreA = "";
        frameRentaViajes.DireccionAerolinea = "";
        frameRentaViajes.costo = "";
        limpiarViajes();
        llamarViajes(1);
    }//GEN-LAST:event_btnagregarActionPerformed

    private void btnagregarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnagregarMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnagregarMouseClicked

    private void txtBuscarClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarClienteKeyReleased
        TableRowSorter<TableModel> trsCliente;
        int valor = 0;
        int conta = 0;
        String nomconsulta = cbxCliente.getSelectedItem().toString();

        String aux = "" + txtBuscarCliente.getText();
        try {
            conectarBD();
            if (nomconsulta.equals("Identidad")) {
                senteciaSQL = ("SELECT COUNT(*) FROM viaje_aeropuerto WHERE UPPER(idCliente) LIKE (UPPER('%" + txtBuscarCliente.getText() + "%')) AND estado='Activo'");
                ps = con.prepareStatement(senteciaSQL);
                rs = ps.executeQuery();
            }

            if (rs.next()) {
                valor = rs.getInt(1);
            }

            datosViajesB = new String[valor][6];
            if (nomconsulta.equals("Identidad")) {
                senteciaSQL = ("SELECT * FROM viaje_aeropuerto WHERE  UPPER(idCliente) LIKE (UPPER('%" + txtBuscarCliente.getText() + "%')) AND estado='Activo'");
                ps = con.prepareStatement(senteciaSQL);
                rs = ps.executeQuery();
            }
            while (rs.next()) {
                datosViajesB[conta][0] = rs.getString("idviaje");
                datosViajesB[conta][1] = rs.getString("hora");
                datosViajesB[conta][2] = rs.getString("idCliente");
                datosViajesB[conta][3] = rs.getString("nombreAerolinea");
                datosViajesB[conta][4] = rs.getString("direccion");
                datosViajesB[conta][5] = rs.getString("costo");
                conta = conta + 1;
            }
            modelo = new DefaultTableModel(datosViajesB, titViajes) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            tbViajes.setModel(modelo);
            trsCliente = new TableRowSorter<>(modelo);
            tbViajes.setRowSorter(trsCliente);
            centrarTabla();
            diseñotabla();
        } catch (Exception e) {
        }
    }//GEN-LAST:event_txtBuscarClienteKeyReleased

    private void txtBuscarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBuscarClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBuscarClienteActionPerformed

    private void btnleerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnleerActionPerformed
        limpiarViajes();
        leerViajes();
    }//GEN-LAST:event_btnleerActionPerformed

    private void btnleerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnleerMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnleerMouseClicked

    private void tbViajesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbViajesMouseClicked

    }//GEN-LAST:event_tbViajesMouseClicked

    private void tbViajesKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbViajesKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_tbViajesKeyReleased

    private void bntLimpiarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bntLimpiarMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_bntLimpiarMouseClicked

    private void bntLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntLimpiarActionPerformed
        limpiarViajes();
    }//GEN-LAST:event_bntLimpiarActionPerformed

    private void bntLimpiar1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bntLimpiar1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_bntLimpiar1MouseClicked

    private void bntLimpiar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntLimpiar1ActionPerformed
        limpiarChofer();
    }//GEN-LAST:event_bntLimpiar1ActionPerformed

    private void bntLimpiar2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bntLimpiar2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_bntLimpiar2MouseClicked

    private void bntLimpiar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntLimpiar2ActionPerformed
        limpiarAuto();
    }//GEN-LAST:event_bntLimpiar2ActionPerformed

    private void MinimizeSysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MinimizeSysActionPerformed
        // TODO add your handling code here:
        this.setExtendedState(ICONIFIED);
    }//GEN-LAST:event_MinimizeSysActionPerformed

    private void ExitSysMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseClicked

        //int Jop = JOptionPane.showConfirmDialog(null, "Salir del sistema", "Salir", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
        //if(Jop== JOptionPane.YES_OPTION){System.exit(0);} else if(Jop == JOptionPane.CANCEL_OPTION){}
    }//GEN-LAST:event_ExitSysMouseClicked

    private void ExitSysMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseEntered

    }//GEN-LAST:event_ExitSysMouseEntered

    private void ExitSysMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseExited

    }//GEN-LAST:event_ExitSysMouseExited

    private void ExitSysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitSysActionPerformed
        MessageDialog obj = new MessageDialog(this);
        obj.showMessage("Estas seguro que desea salir?", "Recuerda que puedes volver cuando quieras");

        if (obj.getMessageType() == MessageDialog.MessageType.OK) {
            this.dispose();
        } else {
            System.out.println("User click cancel");
        }
    }//GEN-LAST:event_ExitSysActionPerformed

    public static void main(String args[]) {
        /* Set the Metal look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Windows  (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(administracionRentasTransporte.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(administracionRentasTransporte.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(administracionRentasTransporte.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(administracionRentasTransporte.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new administracionRentasTransporte().setVisible(true);

            }
        });

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Auto;
    private java.awt.Panel Chofer;
    private javax.swing.JButton ExitSys;
    private javax.swing.JButton MinimizeSys;
    private javax.swing.JTabbedPane TabbedP;
    private java.awt.Panel Viaje;
    private javax.swing.JButton bntLimpiar;
    private javax.swing.JButton bntLimpiar1;
    private javax.swing.JButton bntLimpiar2;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnEliminar1;
    private javax.swing.JButton btnEliminar2;
    private javax.swing.JButton btnactualizar;
    private javax.swing.JButton btnactualizar1;
    private javax.swing.JButton btnactualizar2;
    private javax.swing.JButton btnagregar;
    private javax.swing.JButton btnleer;
    private javax.swing.JButton btnleer1;
    private javax.swing.JButton btnleer4;
    private javax.swing.JButton btnleer6;
    private javax.swing.JButton btnleer7;
    private javax.swing.JComboBox<String> cbxCliente;
    private javax.swing.JComboBox<String> cbxCliente1;
    private javax.swing.JComboBox<String> cbxCliente2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JPopupMenu tablaautos;
    private javax.swing.JPopupMenu tablachofer;
    private javax.swing.JPopupMenu tablaviajes;
    public static javax.swing.JTable tbAutos;
    public static javax.swing.JTable tbChofer;
    public static javax.swing.JTable tbViajes;
    private javax.swing.JTextField txtBuscarCliente;
    private javax.swing.JTextField txtBuscarCliente1;
    private javax.swing.JTextField txtBuscarCliente2;
    // End of variables declaration//GEN-END:variables
}
