/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Registros_Reservaciones;

import Conexion.conexionBD;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/**
 *
 * @author The2220
 */
public class detalles_Reservacion extends javax.swing.JFrame {

    String Usuario;
    Connection con = null;
    conexionBD conecta;
    String senteciaSQL;
    PreparedStatement ps = null;

    int xMouse, yMouse;

    public detalles_Reservacion() {
        initComponents();
        this.setLocationRelativeTo(null);
        mostrarfoto();
    }

    public void mostrarfoto() {
        conectarBD();
        try {
            cargar();
        } catch (IOException ex) {
            Logger.getLogger(detalles_Reservacion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void cargar() throws IOException {

        try {

            ImageIcon foto;
            InputStream is;

            senteciaSQL = "SELECT * FROM habitacion WHERE codHabitaciones LIKE '2'";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(senteciaSQL);

            if (rs.next()) {
                AreaDesc.setText(rs.getString(3));
                is = rs.getBinaryStream("foto");
                
                BufferedImage bi = ImageIO.read(is);
                foto = new ImageIcon(bi);

                Image img = foto.getImage();
                Image newimg = img.getScaledInstance(lblFoto.getWidth(), lblFoto.getHeight(), Image.SCALE_REPLICATE);

                ImageIcon newcon = new ImageIcon(newimg);

                lblFoto.setIcon(newcon);
            } else {
                JOptionPane.showMessageDialog(null, "REGISTRO NO ENCONTRADO", "INFORMACION", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        try {

            ImageIcon foto;
            InputStream is;

            senteciaSQL = "SELECT * FROM habitacion WHERE codHabitaciones LIKE '12'";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(senteciaSQL);

            if (rs.next()) {
                AreaDesc1.setText(rs.getString(3));
                is = rs.getBinaryStream("foto");
                
                BufferedImage bi = ImageIO.read(is);
                foto = new ImageIcon(bi);

                Image img = foto.getImage();
                Image newimg = img.getScaledInstance(lblFoto1.getWidth(), lblFoto1.getHeight(), Image.SCALE_REPLICATE);

                ImageIcon newcon = new ImageIcon(newimg);

                lblFoto1.setIcon(newcon);
            } else {
                JOptionPane.showMessageDialog(null, "REGISTRO NO ENCONTRADO", "INFORMACION", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }        
        try {

            ImageIcon foto;
            InputStream is;

            senteciaSQL = "SELECT * FROM habitacion WHERE codHabitaciones LIKE '23'";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(senteciaSQL);

            if (rs.next()) {
                AreaDesc2.setText(rs.getString(3));
                is = rs.getBinaryStream("foto");
                
                BufferedImage bi = ImageIO.read(is);
                foto = new ImageIcon(bi);

                Image img = foto.getImage();
                Image newimg = img.getScaledInstance(lblFoto2.getWidth(), lblFoto2.getHeight(), Image.SCALE_REPLICATE);

                ImageIcon newcon = new ImageIcon(newimg);

                lblFoto2.setIcon(newcon);
            } else {
                JOptionPane.showMessageDialog(null, "REGISTRO NO ENCONTRADO", "INFORMACION", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }           
        try {

            ImageIcon foto;
            InputStream is;

            senteciaSQL = "SELECT * FROM habitacion WHERE codHabitaciones LIKE '33'";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(senteciaSQL);

            if (rs.next()) {
                AreaDesc3.setText(rs.getString(3));
                is = rs.getBinaryStream("foto");
                
                BufferedImage bi = ImageIO.read(is);
                foto = new ImageIcon(bi);

                Image img = foto.getImage();
                Image newimg = img.getScaledInstance(lblFoto3.getWidth(), lblFoto3.getHeight(), Image.SCALE_REPLICATE);

                ImageIcon newcon = new ImageIcon(newimg);

                lblFoto3.setIcon(newcon);
            } else {
                JOptionPane.showMessageDialog(null, "REGISTRO NO ENCONTRADO", "INFORMACION", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }        
    }

    public void conectarBD() {
        conecta = new conexionBD("proyecto_final");
        con = conecta.getConexion();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        TabbedHabs = new javax.swing.JTabbedPane();
        PEstandar = new javax.swing.JPanel();
        tDesc = new javax.swing.JLabel();
        lblFoto = new javax.swing.JLabel();
        ScrollDesc = new javax.swing.JScrollPane();
        AreaDesc = new javax.swing.JTextArea();
        Border = new javax.swing.JLabel();
        PPremium = new javax.swing.JPanel();
        tDesc1 = new javax.swing.JLabel();
        ScrollDesc1 = new javax.swing.JScrollPane();
        AreaDesc1 = new javax.swing.JTextArea();
        Border1 = new javax.swing.JLabel();
        lblFoto1 = new javax.swing.JLabel();
        PSuite = new javax.swing.JPanel();
        ScrollDesc2 = new javax.swing.JScrollPane();
        AreaDesc2 = new javax.swing.JTextArea();
        tDesc2 = new javax.swing.JLabel();
        Border2 = new javax.swing.JLabel();
        lblFoto2 = new javax.swing.JLabel();
        PDiscap = new javax.swing.JPanel();
        tDesc3 = new javax.swing.JLabel();
        ScrollDesc3 = new javax.swing.JScrollPane();
        AreaDesc3 = new javax.swing.JTextArea();
        Border3 = new javax.swing.JLabel();
        lblFoto3 = new javax.swing.JLabel();
        PUpper = new java.awt.Panel();
        ExitSys = new javax.swing.JButton();
        tSoftwHotel = new javax.swing.JLabel();
        tIcHotel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        TabbedHabs.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N

        PEstandar.setBackground(new java.awt.Color(153, 153, 153));
        PEstandar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tDesc.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tDesc.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tDesc.setText("Descripcion");
        PEstandar.add(tDesc, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 440, 20));

        lblFoto.setBackground(new java.awt.Color(255, 255, 255));
        PEstandar.add(lblFoto, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 220, 240, 190));

        AreaDesc.setColumns(20);
        AreaDesc.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        AreaDesc.setRows(5);
        ScrollDesc.setViewportView(AreaDesc);

        PEstandar.add(ScrollDesc, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 460, 140));

        Border.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        Border.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Border.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        PEstandar.add(Border, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 480, 190));

        TabbedHabs.addTab("      Estandar      ", PEstandar);

        PPremium.setBackground(new java.awt.Color(153, 153, 153));
        PPremium.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tDesc1.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tDesc1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tDesc1.setText("Descripcion");
        PPremium.add(tDesc1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 440, 20));

        AreaDesc1.setColumns(20);
        AreaDesc1.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        AreaDesc1.setRows(5);
        ScrollDesc1.setViewportView(AreaDesc1);

        PPremium.add(ScrollDesc1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 460, 140));

        Border1.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        Border1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Border1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        PPremium.add(Border1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 480, 190));

        lblFoto1.setBackground(new java.awt.Color(255, 255, 255));
        PPremium.add(lblFoto1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 210, 240, 190));

        TabbedHabs.addTab("      Premium      ", PPremium);

        PSuite.setBackground(new java.awt.Color(153, 153, 153));
        PSuite.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        AreaDesc2.setColumns(20);
        AreaDesc2.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        AreaDesc2.setRows(5);
        ScrollDesc2.setViewportView(AreaDesc2);

        PSuite.add(ScrollDesc2, new org.netbeans.lib.awtextra.AbsoluteConstraints(16, 48, 460, 140));

        tDesc2.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tDesc2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tDesc2.setText("Descripcion");
        PSuite.add(tDesc2, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 18, 440, 20));

        Border2.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        Border2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Border2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        PSuite.add(Border2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 8, 480, 190));

        lblFoto2.setBackground(new java.awt.Color(255, 255, 255));
        PSuite.add(lblFoto2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 230, 240, 180));

        TabbedHabs.addTab("     Suite     ", PSuite);

        PDiscap.setBackground(new java.awt.Color(153, 153, 153));
        PDiscap.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tDesc3.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tDesc3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tDesc3.setText("Descripcion");
        PDiscap.add(tDesc3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 440, 20));

        AreaDesc3.setColumns(20);
        AreaDesc3.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        AreaDesc3.setRows(5);
        ScrollDesc3.setViewportView(AreaDesc3);

        PDiscap.add(ScrollDesc3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 460, 150));

        Border3.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        Border3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Border3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        PDiscap.add(Border3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 480, 200));

        lblFoto3.setBackground(new java.awt.Color(255, 255, 255));
        PDiscap.add(lblFoto3, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 230, 240, 180));

        TabbedHabs.addTab("      Discapacidad      ", PDiscap);

        PUpper.setBackground(new java.awt.Color(0, 153, 255));
        PUpper.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PUpperMousePressed(evt);
            }
        });
        PUpper.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                PUpperMouseDragged(evt);
            }
        });

        ExitSys.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BClose.png"))); // NOI18N
        ExitSys.setContentAreaFilled(false);
        ExitSys.setDoubleBuffered(true);
        ExitSys.setPreferredSize(new java.awt.Dimension(30, 30));
        ExitSys.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExitSysMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ExitSysMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ExitSysMouseExited(evt);
            }
        });
        ExitSys.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitSysActionPerformed(evt);
            }
        });

        tSoftwHotel.setFont(new java.awt.Font("Roboto Black", 0, 20)); // NOI18N
        tSoftwHotel.setForeground(new java.awt.Color(255, 255, 255));
        tSoftwHotel.setText("Software Hotel");

        tIcHotel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/LogIc.png"))); // NOI18N
        tIcHotel.setDoubleBuffered(true);

        javax.swing.GroupLayout PUpperLayout = new javax.swing.GroupLayout(PUpper);
        PUpper.setLayout(PUpperLayout);
        PUpperLayout.setHorizontalGroup(
            PUpperLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PUpperLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(tIcHotel)
                .addGap(9, 9, 9)
                .addComponent(tSoftwHotel, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ExitSys, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10))
        );
        PUpperLayout.setVerticalGroup(
            PUpperLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PUpperLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PUpperLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PUpperLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(tSoftwHotel))
                    .addComponent(ExitSys, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 32, Short.MAX_VALUE)
                    .addComponent(tIcHotel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TabbedHabs, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addComponent(PUpper, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(PUpper, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TabbedHabs, javax.swing.GroupLayout.PREFERRED_SIZE, 462, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents



    private void ExitSysMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseClicked
        this.dispose();
    }//GEN-LAST:event_ExitSysMouseClicked

    private void ExitSysMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseEntered

    }//GEN-LAST:event_ExitSysMouseEntered

    private void ExitSysMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseExited

    }//GEN-LAST:event_ExitSysMouseExited

    private void ExitSysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitSysActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ExitSysActionPerformed

    private void PUpperMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMousePressed
        // TODO add your handling code here:
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_PUpperMousePressed

    private void PUpperMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);

    }//GEN-LAST:event_PUpperMouseDragged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(detalles_Reservacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(detalles_Reservacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(detalles_Reservacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(detalles_Reservacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new detalles_Reservacion().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea AreaDesc;
    private javax.swing.JTextArea AreaDesc1;
    private javax.swing.JTextArea AreaDesc2;
    private javax.swing.JTextArea AreaDesc3;
    private javax.swing.JLabel Border;
    private javax.swing.JLabel Border1;
    private javax.swing.JLabel Border2;
    private javax.swing.JLabel Border3;
    private javax.swing.JButton ExitSys;
    private javax.swing.JPanel PDiscap;
    private javax.swing.JPanel PEstandar;
    private javax.swing.JPanel PPremium;
    private javax.swing.JPanel PSuite;
    private java.awt.Panel PUpper;
    private javax.swing.JScrollPane ScrollDesc;
    private javax.swing.JScrollPane ScrollDesc1;
    private javax.swing.JScrollPane ScrollDesc2;
    private javax.swing.JScrollPane ScrollDesc3;
    private javax.swing.JTabbedPane TabbedHabs;
    private javax.swing.JLabel lblFoto;
    private javax.swing.JLabel lblFoto1;
    private javax.swing.JLabel lblFoto2;
    private javax.swing.JLabel lblFoto3;
    private javax.swing.JLabel tDesc;
    private javax.swing.JLabel tDesc1;
    private javax.swing.JLabel tDesc2;
    private javax.swing.JLabel tDesc3;
    private javax.swing.JLabel tIcHotel;
    private javax.swing.JLabel tSoftwHotel;
    // End of variables declaration//GEN-END:variables
}
