/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Registros_Reservaciones;

import Conexion.conexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author The2220
 */

public class reservacionesFuturas extends javax.swing.JFrame {
    
  
    String Usuario;
    Connection con = null;
    conexionBD conecta;
    String sentenciaSQL;
    PreparedStatement ps = null;
    ResultSet rs = null;
    
    int xMouse, yMouse;
     
    public reservacionesFuturas() {
        initComponents();
        
        this.setLocationRelativeTo(null);
        
        
        try {
                conectarBD();
                sentenciaSQL = "SELECT * FROM reservacion WHERE estado LIKE  'Futura' ";
                ps = con.prepareStatement(sentenciaSQL);
                 rs = ps.executeQuery();
                DefaultTableModel model;
                Object Ress[] = new Object[8];
                model = (DefaultTableModel) TCanc.getModel();

                while (rs.next()) {
                    Ress[0] = (rs.getInt(1));
                    Ress[1] = (rs.getString(2));
                    Ress[2] = (rs.getDate(3));
                    Ress[3] = (rs.getDate(4));
                    Ress[4] = (rs.getInt(5));
                    Ress[5] = (rs.getInt(6));
                    Ress[6] = (rs.getDouble(7));
                    Ress[7] = (rs.getString(8));
               

                    model.addRow(Ress);
                }
                TCanc.setModel(model);

                con.close();

            } catch (SQLException ex) {
                System.out.println("Error al contactar reservaciones canceladas:  " + ex.getMessage());
            }
        
        
        
        
        
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PUpper = new java.awt.Panel();
        ExitSys = new javax.swing.JButton();
        tSoftwHotel = new javax.swing.JLabel();
        tIcHotel = new javax.swing.JLabel();
        PCanc = new javax.swing.JPanel();
        ScrollCanc = new javax.swing.JScrollPane();
        TCanc = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setName("FrameCanceladas"); // NOI18N
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PUpper.setBackground(new java.awt.Color(0, 153, 255));
        PUpper.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PUpperMousePressed(evt);
            }
        });
        PUpper.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                PUpperMouseDragged(evt);
            }
        });

        ExitSys.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BClose.png"))); // NOI18N
        ExitSys.setContentAreaFilled(false);
        ExitSys.setDoubleBuffered(true);
        ExitSys.setPreferredSize(new java.awt.Dimension(30, 30));
        ExitSys.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExitSysMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ExitSysMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ExitSysMouseExited(evt);
            }
        });
        ExitSys.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitSysActionPerformed(evt);
            }
        });

        tSoftwHotel.setFont(new java.awt.Font("Roboto Black", 0, 20)); // NOI18N
        tSoftwHotel.setForeground(new java.awt.Color(255, 255, 255));
        tSoftwHotel.setText("Software Hotel - Reservaciones Futuras");

        tIcHotel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/LogIc.png"))); // NOI18N
        tIcHotel.setDoubleBuffered(true);

        javax.swing.GroupLayout PUpperLayout = new javax.swing.GroupLayout(PUpper);
        PUpper.setLayout(PUpperLayout);
        PUpperLayout.setHorizontalGroup(
            PUpperLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PUpperLayout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addComponent(tIcHotel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tSoftwHotel, javax.swing.GroupLayout.PREFERRED_SIZE, 417, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 96, Short.MAX_VALUE)
                .addComponent(ExitSys, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        PUpperLayout.setVerticalGroup(
            PUpperLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PUpperLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tSoftwHotel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(tIcHotel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(ExitSys, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );

        getContentPane().add(PUpper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 40));

        PCanc.setBackground(new java.awt.Color(153, 153, 153));

        TCanc.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "# Confi", "ID Cliente", "Ingreso", "Salida", "ID Hab", "Extra", "Total", "Metodo pago"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        ScrollCanc.setViewportView(TCanc);

        javax.swing.GroupLayout PCancLayout = new javax.swing.GroupLayout(PCanc);
        PCanc.setLayout(PCancLayout);
        PCancLayout.setHorizontalGroup(
            PCancLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PCancLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(ScrollCanc, javax.swing.GroupLayout.PREFERRED_SIZE, 567, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(18, Short.MAX_VALUE))
        );
        PCancLayout.setVerticalGroup(
            PCancLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PCancLayout.createSequentialGroup()
                .addContainerGap(45, Short.MAX_VALUE)
                .addComponent(ScrollCanc, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );

        getContentPane().add(PCanc, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 600, 370));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void conectarBD() {
        conecta = new conexionBD("proyecto_final");
        con = conecta.getConexion();
    }
    
    
    public void UpdCanc()
    {
        DefaultTableModel TC = (DefaultTableModel) TCanc.getModel();
                TC.getDataVector().removeAllElements();
                TC.fireTableDataChanged();
    }
    
    private void ExitSysMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseClicked
        this.dispose();
        
        UpdCanc();
        
    }//GEN-LAST:event_ExitSysMouseClicked

    private void ExitSysMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseEntered

    }//GEN-LAST:event_ExitSysMouseEntered

    private void ExitSysMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseExited

    }//GEN-LAST:event_ExitSysMouseExited

    private void ExitSysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitSysActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ExitSysActionPerformed

    private void PUpperMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMousePressed
        // TODO add your handling code here:
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_PUpperMousePressed

    private void PUpperMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_PUpperMouseDragged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(reservacionesFuturas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(reservacionesFuturas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(reservacionesFuturas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(reservacionesFuturas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new reservacionesFuturas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ExitSys;
    private javax.swing.JPanel PCanc;
    private java.awt.Panel PUpper;
    private javax.swing.JScrollPane ScrollCanc;
    private javax.swing.JTable TCanc;
    private javax.swing.JLabel tIcHotel;
    private javax.swing.JLabel tSoftwHotel;
    // End of variables declaration//GEN-END:variables
}
