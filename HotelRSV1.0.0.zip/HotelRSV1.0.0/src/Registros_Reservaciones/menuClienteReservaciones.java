package Registros_Reservaciones;

/**
 *
 * @author jairo
 */
//importada Res
import Registros_Reservaciones.Reservaciones;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import Conexion.conexionBD;
import java.awt.Color;
import java.awt.Font;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import Componentes.Notification;
import Componentes.MessageDialog;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import proyecto_final.Login;

public class menuClienteReservaciones extends javax.swing.JFrame {

    public static String Usuario, Identidad;
    String usuario;
    Connection con = null;
    conexionBD conecta;
    String senteciaSQL;
    PreparedStatement ps = null;
    ResultSet rs = null;
    DefaultTableModel modelo;
    Object datosClientes[] = new Object[8];
    TableRowSorter<TableModel> trsCliente;

    String[] titCliente = {"Identidad", "Edad", "Nombre", "Apellido", "Direccion", "Telfono", "Discapacidad"};

    String[][] datosClienteB;

    public menuClienteReservaciones() {
        initComponents();
        popumMenu();
        this.setLocationRelativeTo(null);
        diseñotabla();
    }

    public void conectarBD() {
        conecta = new conexionBD("proyecto_final");
        con = conecta.getConexion();
    }

    public void popumMenu() {
        JMenuItem open = new JMenuItem("Crear", getIcon("/img/crear.png", 25, 25));
        JMenuItem update = new JMenuItem("Actualizar", getIcon("/img/actualizar.png", 25, 25));
        JMenuItem delete = new JMenuItem("Eliminar", getIcon("/img/borrar.png", 25, 25));

        tbCliente.setComponentPopupMenu(tablacliente);

        tablacliente.add(open);
        tablacliente.addSeparator();
        tablacliente.add(update);
        tablacliente.addSeparator();
        tablacliente.add(delete);
        tablacliente.addSeparator();

        open.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int fila = tbCliente.getSelectedRow();
                if (fila >= 0) {
                    registrarClientes.NUM = 1;
                    registrarClientes.id = "";
                    registrarClientes.edad = "";
                    registrarClientes.Nombre = "";
                    registrarClientes.Apellido = "";
                    registrarClientes.Dirreccion = "";
                    registrarClientes.Telefono = "";
                    registrarClientes.Discapacidad = "";
                    limpiar();
                    llamar(1);

                } else {
                    notificacion();
                }

            }
        });
        update.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int fila = tbCliente.getSelectedRow();
                if (fila >= 0) {
                    registrarClientes.NUM = 2;
                    fila = tbCliente.getSelectedRow();
                    registrarClientes.id = (tbCliente.getValueAt(fila, 0).toString());
                    registrarClientes.edad = (tbCliente.getValueAt(fila, 1).toString());
                    registrarClientes.Nombre = (tbCliente.getValueAt(fila, 2).toString());
                    registrarClientes.Apellido = (tbCliente.getValueAt(fila, 3).toString());
                    registrarClientes.Dirreccion = (tbCliente.getValueAt(fila, 4).toString());
                    registrarClientes.Telefono = (tbCliente.getValueAt(fila, 5).toString());
                    registrarClientes.Discapacidad = (tbCliente.getValueAt(fila, 6).toString());
                    limpiar();
                    llamar(1);
                } else {
                    notificacion();
                }
            }
        });

        delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int fila = tbCliente.getSelectedRow();
                if (fila >= 0) {
                    llamarConfirmacion();
                } else {
                    notificacion();
                }
            }
        });

    }

    public void notificacion() {
        Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.CENTER, "Debe Seleccionar Almenos un Dato en la Tabla Cliente");
        not.showNotification();
    }

    public void centrarTabla() {
        DefaultTableCellRenderer tcr = new DefaultTableCellRenderer();
        tcr.setHorizontalAlignment(SwingConstants.CENTER);
        tbCliente.getColumnModel().getColumn(0).setCellRenderer(tcr);
        tbCliente.getColumnModel().getColumn(1).setCellRenderer(tcr);
        tbCliente.getColumnModel().getColumn(2).setCellRenderer(tcr);
        tbCliente.getColumnModel().getColumn(3).setCellRenderer(tcr);
        tbCliente.getColumnModel().getColumn(4).setCellRenderer(tcr);
        tbCliente.getColumnModel().getColumn(5).setCellRenderer(tcr);
        tbCliente.getColumnModel().getColumn(6).setCellRenderer(tcr);

        ((DefaultTableCellRenderer) tbCliente.getTableHeader().getDefaultRenderer())
                .setHorizontalAlignment(SwingConstants.CENTER);
    }

    public void diseñotabla() {
        tbCliente.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tbCliente.getTableHeader().setOpaque(false);
        tbCliente.getTableHeader().setBackground(new Color(32, 136, 203));
        tbCliente.getTableHeader().setForeground(new Color(255, 255, 255));
        tbCliente.setRowHeight(25);
    }

    public void limpiar() {
        int fila = tbCliente.getRowCount();
        for (int i = fila - 1; i >= 0; i--) {
            modelo.removeRow(i);
        }
    }

    public void llamarConfirmacion() {

        MessageDialog obj = new MessageDialog(this);
        obj.showMessage("Estas seguro?", "Recuerda una vez eliminado no hay marcha atras");

        if (obj.getMessageType() == MessageDialog.MessageType.OK) {
            int fila = tbCliente.getSelectedRow();
            System.out.println(tbCliente.getValueAt(fila, 0).toString());
            try {
                conectarBD();
                //senteciaSQL = "DELETE FROM empleado WHERE identidad=" +txtCodigo.getText().trim();
                senteciaSQL = "UPDATE cliente SET estado='Inactivo' WHERE identidad LIKE  '" + tbCliente.getValueAt(fila, 0).toString() + "'";
                ps = con.prepareStatement(senteciaSQL);
                ps.execute();
                con.close();
                Notification not = new Notification(this, Notification.Type.SUCCESS, Notification.Location.TOP_CENTER, "Datos Eliminados Correctamente ");
                not.showNotification();
                limpiar();
                leerCliente();
                System.out.println(tbCliente.getValueAt(fila, 0).toString());

            } catch (SQLException ex) {
                Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No se pudieron eliminar los datos " + ex);
                not.showNotification();
            }
        } else {
            System.out.println("User click cancel");
        }

    }

    public void llamar(int num) {
        if (num == 1) {
            registrarClientes em = new registrarClientes();
            em.setVisible(true);
        }
    }

    public void leerCliente() {
        conectarBD();
        senteciaSQL = "SELECT * FROM cliente WHERE estado LIKE 'Activo'";
        try {
            ps = con.prepareStatement(senteciaSQL);
            rs = ps.executeQuery();
            modelo = (DefaultTableModel) tbCliente.getModel();
            while (rs.next()) {
                datosClientes[0] = (rs.getString(1));
                datosClientes[1] = (rs.getString(2));
                datosClientes[2] = (rs.getString(3));
                datosClientes[3] = (rs.getString(4));
                datosClientes[4] = (rs.getString(5));
                datosClientes[5] = (rs.getString(6));
                if (rs.getBoolean(7) == true) {
                    datosClientes[6] = "Si";
                } else {
                    datosClientes[6] = "No";
                }
                modelo.addRow(datosClientes);
            }
            tbCliente.setModel(modelo);
            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
        }

    }

    public Icon getIcon(String ruta, int widht, int height) {
        Icon icono = new ImageIcon(new ImageIcon(getClass().getResource(ruta)).getImage().getScaledInstance(widht, height, 0));
        return icono;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tablacliente = new javax.swing.JPopupMenu();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbCliente = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnleer = new javax.swing.JButton();
        txtBuscarCliente = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        cbxCliente = new javax.swing.JComboBox<>();
        PUpper = new java.awt.Panel();
        ExitSys = new javax.swing.JButton();
        MinimizeSys = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        BSelectCliente = new javax.swing.JButton();
        btnleer2 = new javax.swing.JButton();
        btnactualizar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnleer3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 255), 10));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(null);

        tbCliente.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        tbCliente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Identidad", "Edad", "Nombre", "Apellido", "Dirreccion", "Telefono", "Discapacidad"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tbCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tbCliente.setGridColor(new java.awt.Color(204, 204, 204));
        tbCliente.setShowGrid(true);
        tbCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbClienteMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbCliente);

        jPanel2.add(jScrollPane1);
        jScrollPane1.setBounds(10, 0, 950, 500);

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 221, 970, 500));

        jLabel1.setFont(new java.awt.Font("Corbel", 1, 36)); // NOI18N
        jLabel1.setText("REGISTROS DE CLIENTES");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 70, 430, 60));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/clasificacion (1).png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 50, 101, 95));

        btnleer.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        btnleer.setForeground(new java.awt.Color(102, 102, 255));
        btnleer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/leer (3).png"))); // NOI18N
        btnleer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnleerMouseClicked(evt);
            }
        });
        btnleer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnleerActionPerformed(evt);
            }
        });
        jPanel1.add(btnleer, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 150, 50, 50));

        txtBuscarCliente.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        txtBuscarCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarClienteKeyReleased(evt);
            }
        });
        jPanel1.add(txtBuscarCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 160, 294, -1));

        jLabel3.setFont(new java.awt.Font("Bodoni Bd BT", 0, 24)); // NOI18N
        jLabel3.setText("Buscar");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 150, 80, 38));

        cbxCliente.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        cbxCliente.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Identidad", "Nombre" }));
        jPanel1.add(cbxCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 160, 140, 30));

        PUpper.setBackground(new java.awt.Color(0, 153, 255));
        PUpper.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PUpperMousePressed(evt);
            }
        });
        PUpper.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                PUpperMouseDragged(evt);
            }
        });
        PUpper.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ExitSys.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/BClose.png"))); // NOI18N
        ExitSys.setContentAreaFilled(false);
        ExitSys.setPreferredSize(new java.awt.Dimension(30, 30));
        ExitSys.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExitSysMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ExitSysMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ExitSysMouseExited(evt);
            }
        });
        ExitSys.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitSysActionPerformed(evt);
            }
        });
        PUpper.add(ExitSys, new org.netbeans.lib.awtextra.AbsoluteConstraints(958, 7, 32, 26));

        MinimizeSys.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/BMin.png"))); // NOI18N
        MinimizeSys.setContentAreaFilled(false);
        MinimizeSys.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MinimizeSysActionPerformed(evt);
            }
        });
        PUpper.add(MinimizeSys, new org.netbeans.lib.awtextra.AbsoluteConstraints(921, 7, 30, 26));

        jLabel20.setFont(new java.awt.Font("Roboto Black", 0, 20)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Software Hotel");
        PUpper.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 7, 191, -1));
        PUpper.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(4, 13, -1, 26));
        PUpper.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 13, -1, 26));
        PUpper.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/LogIc.png"))); // NOI18N
        PUpper.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 7, 30, 30));

        jPanel1.add(PUpper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1000, 40));

        BSelectCliente.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        BSelectCliente.setForeground(new java.awt.Color(102, 102, 255));
        BSelectCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/selectt.png"))); // NOI18N
        BSelectCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BSelectClienteMouseClicked(evt);
            }
        });
        BSelectCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BSelectClienteActionPerformed(evt);
            }
        });
        jPanel1.add(BSelectCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 150, 50, 50));

        btnleer2.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        btnleer2.setForeground(new java.awt.Color(102, 102, 255));
        btnleer2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/crear2.png"))); // NOI18N
        btnleer2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnleer2MouseClicked(evt);
            }
        });
        btnleer2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnleer2ActionPerformed(evt);
            }
        });
        jPanel1.add(btnleer2, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 150, 50, 50));

        btnactualizar.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        btnactualizar.setForeground(new java.awt.Color(102, 102, 255));
        btnactualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/actualizar (6).png"))); // NOI18N
        btnactualizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnactualizarMouseClicked(evt);
            }
        });
        btnactualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnactualizarActionPerformed(evt);
            }
        });
        jPanel1.add(btnactualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 150, 50, 50));

        btnEliminar.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        btnEliminar.setForeground(new java.awt.Color(102, 102, 255));
        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/eliminar (1).png"))); // NOI18N
        btnEliminar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEliminarMouseClicked(evt);
            }
        });
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        jPanel1.add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 150, 50, 50));

        btnleer3.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        btnleer3.setForeground(new java.awt.Color(102, 102, 255));
        btnleer3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/borrar2.png"))); // NOI18N
        btnleer3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnleer3MouseClicked(evt);
            }
        });
        btnleer3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnleer3ActionPerformed(evt);
            }
        });
        jPanel1.add(btnleer3, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 150, 50, 50));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 750, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tbClienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbClienteMouseClicked

    }//GEN-LAST:event_tbClienteMouseClicked

    private void btnleerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnleerMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnleerMouseClicked

    private void btnleerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnleerActionPerformed
        limpiar();
        leerCliente();
    }//GEN-LAST:event_btnleerActionPerformed

    private void txtBuscarClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarClienteKeyReleased
        TableRowSorter<TableModel> trsCliente;
        int valor = 0;
        int conta = 0;
        String nomconsulta = cbxCliente.getSelectedItem().toString();

        String aux = "" + txtBuscarCliente.getText();
        try {
            conectarBD();
            if (nomconsulta.equals("Identidad")) {
                senteciaSQL = ("SELECT COUNT(*) FROM cliente WHERE UPPER(identidad) LIKE (UPPER('%" + txtBuscarCliente.getText() + "%')) AND estado='Activo'");
                ps = con.prepareStatement(senteciaSQL);
                rs = ps.executeQuery();
            } else if (nomconsulta.equals("Nombre")) {
                senteciaSQL = ("SELECT COUNT(*) FROM cliente WHERE UPPER(nombre) LIKE (UPPER('%" + txtBuscarCliente.getText() + "%')) AND estado='Activo'");
                ps = con.prepareStatement(senteciaSQL);
                rs = ps.executeQuery();
            }

            if (rs.next()) {
                valor = rs.getInt(1);
            }

            datosClienteB = new String[valor][8];
            if (nomconsulta.equals("Identidad")) {
                senteciaSQL = ("SELECT * FROM cliente WHERE  UPPER(identidad) LIKE (UPPER('%" + txtBuscarCliente.getText() + "%')) AND estado='Activo'");
                ps = con.prepareStatement(senteciaSQL);
                rs = ps.executeQuery();
            } else if (nomconsulta.equals("Nombre")) {
                senteciaSQL = ("SELECT * FROM cliente WHERE UPPER(nombre) LIKE (UPPER('%" + txtBuscarCliente.getText() + "%')) AND estado='Activo'");
                ps = con.prepareStatement(senteciaSQL);
                rs = ps.executeQuery();
            }
            while (rs.next()) {
                datosClienteB[conta][0] = rs.getString("identidad");
                datosClienteB[conta][1] = rs.getString("edad");
                datosClienteB[conta][2] = rs.getString("nombre");
                datosClienteB[conta][3] = rs.getString("apellido");
                datosClienteB[conta][4] = rs.getString("direccion");
                datosClienteB[conta][5] = rs.getString("telefono");
                if (rs.getBoolean("discapacidad") == true) {
                    datosClienteB[conta][6] = "Si";
                } else {
                    datosClienteB[conta][6] = "No";
                }
                conta = conta + 1;
            }
            modelo = new DefaultTableModel(datosClienteB, titCliente) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            tbCliente.setModel(modelo);
            trsCliente = new TableRowSorter<>(modelo);
            tbCliente.setRowSorter(trsCliente);

        } catch (Exception e) {
        }


    }//GEN-LAST:event_txtBuscarClienteKeyReleased

    private void ExitSysMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseClicked

        //int Jop = JOptionPane.showConfirmDialog(null, "Salir del sistema", "Salir", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
        //if(Jop== JOptionPane.YES_OPTION){System.exit(0);} else if(Jop == JOptionPane.CANCEL_OPTION){}

    }//GEN-LAST:event_ExitSysMouseClicked

    private void ExitSysMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseEntered

    }//GEN-LAST:event_ExitSysMouseEntered

    private void ExitSysMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseExited

    }//GEN-LAST:event_ExitSysMouseExited

    private void ExitSysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitSysActionPerformed
        MessageDialog obj = new MessageDialog(this);
        obj.showMessage("Estas seguro que desea salir?", "Recuerda que puedes volver cuando quieras");

        if (obj.getMessageType() == MessageDialog.MessageType.OK) {
            this.dispose();
        } else {
            System.out.println("User click cancel");
        }
    }//GEN-LAST:event_ExitSysActionPerformed

    private void MinimizeSysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MinimizeSysActionPerformed
        // TODO add your handling code here:
        this.setExtendedState(ICONIFIED);
    }//GEN-LAST:event_MinimizeSysActionPerformed

    private void PUpperMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMousePressed
        // TODO add your handling code here:
        //        xMouse = evt.getX();
        //        yMouse = evt.getY();
    }//GEN-LAST:event_PUpperMousePressed

    private void PUpperMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMouseDragged
        // TODO add your handling code here
        //        int x = evt.getXOnScreen();
        //        int y = evt.getYOnScreen();
        //        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_PUpperMouseDragged

    private void BSelectClienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BSelectClienteMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_BSelectClienteMouseClicked

    private void BSelectClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BSelectClienteActionPerformed

        int SelRow = tbCliente.getSelectedRow();

        String SendID = tbCliente.getValueAt(SelRow, 0).toString();
        String SendAge = tbCliente.getValueAt(SelRow, 1).toString();
        String SendName = tbCliente.getValueAt(SelRow, 2).toString();
        String SendSName = tbCliente.getValueAt(SelRow, 3).toString();
        String SendAddress = tbCliente.getValueAt(SelRow, 4).toString();
        String SendPhone = tbCliente.getValueAt(SelRow, 5).toString();
        String SendHandi = tbCliente.getValueAt(SelRow, 6).toString();

        //llamado de las variables
        //Reservaciones DataSend = new Reservaciones();
        Reservaciones.FieldIDC.setText(SendID);
        Reservaciones.FieldNombre.setText(SendName);
        Reservaciones.FieldApellido.setText(SendSName);
        Reservaciones.FieldEdad.setText(SendAge);
        Reservaciones.FieldTLF.setText(SendPhone);
        Reservaciones.FieldDireccion.setText(SendAddress);

        if (SendHandi.equalsIgnoreCase("Si")) {
            Reservaciones.CheckDiscap.setSelected(true);
        } else if (SendHandi.equalsIgnoreCase("no")) {
            Reservaciones.CheckDiscap.setSelected(false);
        }
        this.dispose();


    }//GEN-LAST:event_BSelectClienteActionPerformed

    private void btnleer2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnleer2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnleer2MouseClicked

    private void btnleer2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnleer2ActionPerformed

        registrarClientes.NUM = 1;
        registrarClientes.id = "";
        registrarClientes.edad = "";
        registrarClientes.Nombre = "";
        registrarClientes.Apellido = "";
        registrarClientes.Dirreccion = "";
        registrarClientes.Telefono = "";
        registrarClientes.Discapacidad = "";
        limpiar();
        llamar(1);


    }//GEN-LAST:event_btnleer2ActionPerformed

    private void btnactualizarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnactualizarMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnactualizarMouseClicked

    private void btnactualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnactualizarActionPerformed
        int fila = tbCliente.getSelectedRow();
        if (fila >= 0) {
            registrarClientes.NUM = 2;
            fila = tbCliente.getSelectedRow();
            registrarClientes.id = (tbCliente.getValueAt(fila, 0).toString());
            registrarClientes.edad = (tbCliente.getValueAt(fila, 1).toString());
            registrarClientes.Nombre = (tbCliente.getValueAt(fila, 2).toString());
            registrarClientes.Apellido = (tbCliente.getValueAt(fila, 3).toString());
            registrarClientes.Dirreccion = (tbCliente.getValueAt(fila, 4).toString());
            registrarClientes.Telefono = (tbCliente.getValueAt(fila, 5).toString());
            registrarClientes.Discapacidad = (tbCliente.getValueAt(fila, 6).toString());
            limpiar();
            llamar(1);
        } else {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.CENTER, "Debe Seleccionar Almenos un Dato en la Tabla Cliente");
            not.showNotification();
        }

    }//GEN-LAST:event_btnactualizarActionPerformed

    private void btnEliminarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliminarMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnEliminarMouseClicked

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int fila = tbCliente.getSelectedRow();
        if (fila >= 0) {
            llamarConfirmacion();
        } else {
            notificacion();
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnleer3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnleer3MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnleer3MouseClicked

    private void btnleer3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnleer3ActionPerformed
      limpiar();
    }//GEN-LAST:event_btnleer3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(menuClienteReservaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(menuClienteReservaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(menuClienteReservaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(menuClienteReservaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menuClienteReservaciones().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BSelectCliente;
    private javax.swing.JButton ExitSys;
    private javax.swing.JButton MinimizeSys;
    private java.awt.Panel PUpper;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnactualizar;
    private javax.swing.JButton btnleer;
    private javax.swing.JButton btnleer2;
    private javax.swing.JButton btnleer3;
    private javax.swing.JComboBox<String> cbxCliente;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPopupMenu tablacliente;
    public static javax.swing.JTable tbCliente;
    private javax.swing.JTextField txtBuscarCliente;
    // End of variables declaration//GEN-END:variables
}
