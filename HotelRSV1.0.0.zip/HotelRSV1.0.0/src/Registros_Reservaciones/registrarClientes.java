package Registros_Reservaciones;

import Conexion.conexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import Componentes.Notification;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class registrarClientes extends javax.swing.JFrame {

    public static String id;
    public static String edad;
    public static String Nombre;
    public static String Apellido;
    public static String Dirreccion;
    public static String Telefono;
    public static String Discapacidad;
    public static int NUM;

    String usuario;
    Connection con = null;
    conexionBD conecta;
    String senteciaSQL;
    PreparedStatement ps = null;

    ResultSet rs = null;
    DefaultTableModel modelo;
    Object datosEmpleados[] = new Object[8];

    public registrarClientes() {
        initComponents();
        txtCodigo.requestFocus();
        this.setLocationRelativeTo(null);
        txtCodigo.setText(id);
        txtNombre.setText(Nombre);
        txtEdad.setText(edad);
        txtApellido.setText(Apellido);
        txtDirreccion.setText(Dirreccion);
        txtTel.setText(Telefono);
        txtDiscapacidad.setSelectedItem(Discapacidad);
    }

    public void conectarBD() {
        conecta = new conexionBD("proyecto_final");
        con = conecta.getConexion();
    }

    public void InsertarDisc() {

        Boolean tipo;
        if (txtDiscapacidad.getSelectedIndex() == 0) {

            JOptionPane.showMessageDialog(null, "Seleccione Si tiene discapacidad");

        } else if (txtDiscapacidad.getSelectedIndex() == 1) {

            tipo = true;
            crearCliente(tipo);

        } else if (txtDiscapacidad.getSelectedIndex() == 2) {

            tipo = false;

            crearCliente(tipo);

        }
        this.setLocationRelativeTo(null);
    }

    public void crearCliente(Boolean tipo) {

        try {
            conectarBD();
            senteciaSQL = "INSERT INTO cliente (identidad,edad,nombre,apellido,direccion,telefono,discapacidad,estado) VALUES(?,?,?,?,?,?,?,?)";
            ps = con.prepareStatement(senteciaSQL);
            ps.setString(1, txtCodigo.getText());
            ps.setString(2, txtEdad.getText());
            ps.setString(3, txtNombre.getText());
            ps.setString(4, txtApellido.getText());
            ps.setString(5, txtDirreccion.getText());
            ps.setString(6, txtTel.getText());
            ps.setBoolean(7, tipo);
            ps.setString(8, "Activo");
            ps.execute();
            Notification not = new Notification(this, Notification.Type.SUCCESS, Notification.Location.TOP_CENTER, "Datos de Cliente Guardados Correctamente");
            not.showNotification();
            con.close();
        } catch (SQLException ex) {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No Se pudo agregar el cliente " + ex);
            not.showNotification();
        }
    }

    public void actualizarCliente() {

        Boolean tipo;

        if (txtDiscapacidad.getSelectedIndex() == 0) {

            JOptionPane.showMessageDialog(null, "Seleccione el Cargo que dispondra");

        } else if (txtDiscapacidad.getSelectedIndex() == 1) {

            tipo =true;
            consultaacutualizar(tipo);

        } else if (txtDiscapacidad.getSelectedIndex() == 2) {

            tipo = false;
            consultaacutualizar(tipo);

        }
        this.setLocationRelativeTo(null);
    }

    public void consultaacutualizar(boolean tipo) {
        try {
            conectarBD();
            senteciaSQL = "UPDATE cliente SET edad=?,nombre=?,apellido=?,direccion=?,telefono=?,discapacidad=? WHERE identidad=?";
            ps = con.prepareStatement(senteciaSQL);
            ps.setString(1, txtEdad.getText());
            ps.setString(2, txtNombre.getText());
            ps.setString(3, txtApellido.getText());
            ps.setString(4, txtDirreccion.getText());
            ps.setString(5, txtTel.getText());
            ps.setBoolean(6, tipo);
            ps.setString(7, txtCodigo.getText());
            ps.execute();
            con.close();
            Notification not = new Notification(this, Notification.Type.INFO, Notification.Location.TOP_CENTER, "Datos Actualizados Correctamente");
            not.showNotification();
        } catch (SQLException ex) {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No se pudo actualizar el dato " + ex);
            not.showNotification();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtDirreccion = new javax.swing.JTextField();
        txtTel = new javax.swing.JFormattedTextField();
        jLabel5 = new javax.swing.JLabel();
        txtApellido = new javax.swing.JTextField();
        txtEdad = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtDiscapacidad = new javax.swing.JComboBox<>();
        txtCodigo = new javax.swing.JFormattedTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        PUpper = new java.awt.Panel();
        ExitSys = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102), 5));
        jPanel1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(null);

        jLabel2.setFont(new java.awt.Font("Roboto Medium", 1, 16)); // NOI18N
        jLabel2.setText("Discapacidad");
        jPanel2.add(jLabel2);
        jLabel2.setBounds(10, 260, 110, 30);

        jLabel3.setFont(new java.awt.Font("Roboto Medium", 1, 16)); // NOI18N
        jLabel3.setText("Identidad");
        jPanel2.add(jLabel3);
        jLabel3.setBounds(20, 20, 80, 30);

        jLabel4.setFont(new java.awt.Font("Roboto Medium", 1, 16)); // NOI18N
        jLabel4.setText("Edad");
        jPanel2.add(jLabel4);
        jLabel4.setBounds(40, 140, 70, 30);

        jLabel6.setFont(new java.awt.Font("Roboto Medium", 1, 16)); // NOI18N
        jLabel6.setText("Dirreccion");
        jPanel2.add(jLabel6);
        jLabel6.setBounds(20, 180, 80, 30);

        jLabel7.setFont(new java.awt.Font("Roboto Medium", 1, 16)); // NOI18N
        jLabel7.setText("Telefono");
        jPanel2.add(jLabel7);
        jLabel7.setBounds(30, 220, 70, 30);

        txtNombre.setFont(new java.awt.Font("Roboto Light", 1, 16)); // NOI18N
        jPanel2.add(txtNombre);
        txtNombre.setBounds(120, 60, 250, 30);

        txtDirreccion.setFont(new java.awt.Font("Roboto Light", 1, 16)); // NOI18N
        jPanel2.add(txtDirreccion);
        txtDirreccion.setBounds(120, 180, 250, 30);

        try {
            txtTel.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("(+504) #### - ####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtTel.setFont(new java.awt.Font("Roboto Light", 0, 16)); // NOI18N
        jPanel2.add(txtTel);
        txtTel.setBounds(120, 220, 250, 30);

        jLabel5.setFont(new java.awt.Font("Roboto Medium", 1, 16)); // NOI18N
        jLabel5.setText("Nombre");
        jPanel2.add(jLabel5);
        jLabel5.setBounds(30, 60, 70, 30);

        txtApellido.setFont(new java.awt.Font("Roboto Light", 1, 16)); // NOI18N
        jPanel2.add(txtApellido);
        txtApellido.setBounds(120, 100, 250, 30);

        txtEdad.setFont(new java.awt.Font("Roboto Light", 1, 16)); // NOI18N
        jPanel2.add(txtEdad);
        txtEdad.setBounds(120, 140, 250, 30);

        jLabel8.setFont(new java.awt.Font("Roboto Medium", 1, 16)); // NOI18N
        jLabel8.setText("Apellido");
        jPanel2.add(jLabel8);
        jLabel8.setBounds(30, 100, 70, 30);

        txtDiscapacidad.setFont(new java.awt.Font("Roboto Light", 0, 16)); // NOI18N
        txtDiscapacidad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione", "Si", "No" }));
        jPanel2.add(txtDiscapacidad);
        txtDiscapacidad.setBounds(120, 260, 250, 30);

        try {
            txtCodigo.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("#### - #### - #####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtCodigo.setFont(new java.awt.Font("Roboto Light", 0, 16)); // NOI18N
        jPanel2.add(txtCodigo);
        txtCodigo.setBounds(120, 20, 250, 30);

        jPanel1.add(jPanel2);
        jPanel2.setBounds(10, 60, 390, 300);
        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(730, -10, 2, 2);

        PUpper.setBackground(new java.awt.Color(0, 102, 102));
        PUpper.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PUpperMousePressed(evt);
            }
        });
        PUpper.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                PUpperMouseDragged(evt);
            }
        });
        PUpper.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ExitSys.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/BClose.png"))); // NOI18N
        ExitSys.setContentAreaFilled(false);
        ExitSys.setPreferredSize(new java.awt.Dimension(30, 30));
        ExitSys.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExitSysMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ExitSysMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ExitSysMouseExited(evt);
            }
        });
        ExitSys.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitSysActionPerformed(evt);
            }
        });
        PUpper.add(ExitSys, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 7, 32, 26));

        jLabel20.setFont(new java.awt.Font("Roboto Black", 0, 20)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Software Hotel");
        PUpper.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 7, 191, -1));
        PUpper.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(4, 13, -1, 26));
        PUpper.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 13, -1, 26));
        PUpper.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/LogIc.png"))); // NOI18N
        PUpper.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 7, 30, 30));

        jPanel1.add(PUpper);
        PUpper.setBounds(0, 0, 420, 39);

        jButton5.setBackground(new java.awt.Color(0, 255, 153));
        jButton5.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(102, 102, 255));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/guardar (2).png"))); // NOI18N
        jButton5.setText("GUARDAR");
        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton5MouseClicked(evt);
            }
        });
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton5);
        jButton5.setBounds(100, 410, 220, 50);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 419, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 517, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ExitSysMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseClicked

        //int Jop = JOptionPane.showConfirmDialog(null, "Salir del sistema", "Salir", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
        //if(Jop== JOptionPane.YES_OPTION){System.exit(0);} else if(Jop == JOptionPane.CANCEL_OPTION){}
    }//GEN-LAST:event_ExitSysMouseClicked

    private void ExitSysMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseEntered

    }//GEN-LAST:event_ExitSysMouseEntered

    private void ExitSysMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseExited

    }//GEN-LAST:event_ExitSysMouseExited

    private void ExitSysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitSysActionPerformed
        this.dispose();
    }//GEN-LAST:event_ExitSysActionPerformed

    private void PUpperMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMousePressed
        // TODO add your handling code here:
        //        xMouse = evt.getX();
        //        yMouse = evt.getY();
    }//GEN-LAST:event_PUpperMousePressed

    private void PUpperMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMouseDragged
        // TODO add your handling code here
        //        int x = evt.getXOnScreen();
        //        int y = evt.getYOnScreen();
        //        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_PUpperMouseDragged

    private void jButton5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5MouseClicked

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        if (txtCodigo.getText().isEmpty() || txtCodigo.getText().equals("     -      -      ")||txtTel.getText().equals("(+504)      -     ")|| txtNombre.getText().isEmpty() || txtApellido.getText().isEmpty() || txtDirreccion.getText().isEmpty() || txtEdad.getText().isEmpty() || txtTel.getText().isEmpty() || txtDiscapacidad.getSelectedIndex() == 0) {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "Datos Incompletos, Favor llenar todos los campos");
            not.showNotification();
        }
        else{
            if (NUM == 1) {
                InsertarDisc();
                this.dispose();
            } else if (NUM == 2) {
                actualizarCliente();
                this.dispose();
            }
        }


    }//GEN-LAST:event_jButton5ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(registrarClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(registrarClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(registrarClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(registrarClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new registrarClientes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ExitSys;
    private java.awt.Panel PUpper;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JFormattedTextField txtCodigo;
    private javax.swing.JTextField txtDirreccion;
    private javax.swing.JComboBox<String> txtDiscapacidad;
    private javax.swing.JTextField txtEdad;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JFormattedTextField txtTel;
    // End of variables declaration//GEN-END:variables
}
