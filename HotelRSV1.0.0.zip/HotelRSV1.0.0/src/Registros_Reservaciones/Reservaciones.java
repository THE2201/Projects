package Registros_Reservaciones;

import Registros_Reservaciones.rentaReservacionAuto;
import Registros_Reservaciones.selectorAutomovilReservacion;
import Registros_Reservaciones.selectorClientesReservacion;
import Registros_Reservaciones.rentaAuto;
import Registros_Reservaciones.rentaChofer;
import Registros_Reservaciones.rentaViajes;
import Registros_Reservaciones.reservacionesCanceladas;
import Registros_Reservaciones.menuClienteReservaciones;
import Registros_Reservaciones.registrarClientes;
import Registros_Reservaciones.detalles_Reservacion;
import Conexion.conexionBD;
import java.awt.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import Componentes.Notification;
import Componentes.MessageDialog;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import proyecto_final.Login;


/*@author A.S. */
public class Reservaciones extends javax.swing.JFrame {

    String Usuario;
    Connection Conn = null;
    conexionBD Conecta;
    String SenSQL, SenSQL2;
    PreparedStatement PS = null, PS2 = null;
    ResultSet RS = null, RS2 = null;

    int xMouse, yMouse;
    int ncs;
    int ncsM;

    //para registrar res: Variable de id habitacion
    String IDHB;

    //fechas a base
    String DL, DS;

    public static String Ad;
    public static Double TotMod;

    DefaultTableModel model;

    public Reservaciones() {
        initComponents();
        setLocationRelativeTo(null);

        //Plasmar la funcion para llamar la fecha del S.O. en el JLabel
        tHoyFecha.setText(RealTime());

        //Visibles solo cuando se modifica reservacion
        ComboMod.setVisible(false);
        tBordeEdit.setVisible(false);
        tLlegadaEdit.setVisible(false);
        ChooserEditL.setVisible(false);
        tTotalMod.setVisible(false);
        BGuardar1.setVisible(false);
        ChooserEditS.setVisible(false);
        tSalidaEdit.setVisible(false);
        BCancEdit.setVisible(false);
        BNochesMod.setVisible(false);
        tHabNox.setVisible(false);
        FieldTotalMod.setVisible(false);
        tLpsMod.setVisible(false);
        tTotalMod.setVisible(false);
        BNochesMod.setVisible(false);
        BListMod.setVisible(false);
        tNMod.setVisible(false);
        tHabMod.setVisible(false);
        BRegRes.setEnabled(false);

        //START STATUS UPDATER
        //String to Int Local Date
        String LoComp = tHoyFecha.getText();
        char[] charA = LoComp.toCharArray();
        String Dof1 = String.valueOf(charA[0]), Dof2 = String.valueOf(charA[1]);
        String Mof1 = String.valueOf(charA[3]), Mof2 = String.valueOf(charA[4]);
        String Yof1 = String.valueOf(charA[6]), Yof2 = String.valueOf(charA[7]), Yof3 = String.valueOf(charA[8]), Yof4 = String.valueOf(charA[9]);

        String SDay = Dof1 + Dof2, SMonth = Mof1 + Mof2, SYear = Yof1 + Yof2 + Yof3 + Yof4;

        int NDayLocal = Integer.parseInt(SDay);
        int NMonthLocal = Integer.parseInt(SMonth);
        int NYearLocal = Integer.parseInt(SYear);

        //CodH = guarda el id de habitacion para actualizarlo de Ocupada -> Disponible
        int CodH;

        //actualizador de Activas a pasadas
        try {
            ConectarBD();
            SenSQL = "SELECT * FROM reservacion WHERE estado LIKE  'Activa'";
            PS = Conn.prepareStatement(SenSQL);
            RS = PS.executeQuery();

            while (RS.next()) {
                int UCon = RS.getInt(1);                //id reservacion
                String DIng = RS.getString(3);     //fecha ingreso
                String DSal = RS.getString(4);     //fecha salida
                CodH = RS.getInt(5);                     //codhabitacion

                System.out.println("#CNF" + UCon + " Entrada " + DIng + " Salida " + DSal);

                char[] Ar = DSal.toCharArray();
                String D1 = String.valueOf(Ar[8]);
                String D2 = String.valueOf(Ar[9]);
                String Dia = D1 + D2;
                int DiaN = Integer.parseInt(Dia);

                String M1 = String.valueOf(5);
                String M2 = String.valueOf(6);
                String Mes = M1 + M2;
                int MesN = Integer.parseInt(Mes);

                String Y1 = String.valueOf(Ar[0]);
                String Y2 = String.valueOf(Ar[1]);
                String Y3 = String.valueOf(Ar[2]);
                String Y4 = String.valueOf(Ar[3]);
                String Anio = Y1 + Y2 + Y3 + Y4;
                int AnioN = Integer.parseInt(Anio);
                //comparar si fecha de hoy es mayor a fecha de salida 

                if (NDayLocal > DiaN && NMonthLocal == MesN && NYearLocal == AnioN) {
                    try {//try1
                        SenSQL = "UPDATE reservaciones SET estado=? WHERE codreserva=" + UCon + "'";
                        PS = Conn.prepareStatement(SenSQL);
                        PS.setString(11, "Pasada");

                        PS.execute();

                        try //try2
                        {
                            SenSQL2 = "UPDATE habitacion SET alquiler=? WHERE codHabitaciones='" + CodH + "'";
                            PS2 = Conn.prepareStatement(SenSQL2);
                            PS2.setString(7, "Disponible");

                            PS2.execute();
                            Conn.close();

                        } catch (SQLException ex) {//vacio por que solo una condicion
                        }//try2

                    } catch (SQLException ex) {//vacio por que solo una condicion
                    }//try1
                }
            }

            Conn.close();

        } catch (SQLException ex) {
            System.out.println("Error al actualizar estado de reservacion: " + ex.getMessage());
        }

        //fin de actualizar Activas a pasadas--------------------------------------------------------------------------------------------------------------------------
        int CodH2;
        int TipoVehiculo = 0;
        //actualizador de Futuras a activas
        try {
            ConectarBD();
            SenSQL = "SELECT * FROM reservacion WHERE estado LIKE  'Futura'";
            PS = Conn.prepareStatement(SenSQL);
            RS = PS.executeQuery();

            while (RS.next()) {
                int UCon = RS.getInt(1);                //id reservacion
                String DIng = RS.getString(3);     //fecha ingreso
                String DSal = RS.getString(4);     //fecha salida
                CodH2 = RS.getInt(5);                     //codhabitacion
                TipoVehiculo = RS.getInt(6);
                System.out.println("#CNF" + UCon + " Entrada " + DIng + " Salida " + DSal);

                //2022-08-06
                char[] Ar = DSal.toCharArray();
                String D1 = String.valueOf(Ar[8]);
                String D2 = String.valueOf(Ar[9]);
                String Dia = D1 + D2;
                int DiaN = Integer.parseInt(Dia);

                String M1 = String.valueOf(5);
                String M2 = String.valueOf(6);
                String Mes = M1 + M2;
                int MesN = Integer.parseInt(Mes);

                String Y1 = String.valueOf(Ar[0]);
                String Y2 = String.valueOf(Ar[1]);
                String Y3 = String.valueOf(Ar[2]);
                String Y4 = String.valueOf(Ar[3]);
                String Anio = Y1 + Y2 + Y3 + Y4;
                int AnioN = Integer.parseInt(Anio);

                //comparar si fecha de hoy es mayor a fecha de salida 
                if (NDayLocal == DiaN && NMonthLocal == MesN && NYearLocal == AnioN) {
                    try {//try1
                        SenSQL = "UPDATE reservaciones SET estado=? WHERE codreserva='" + UCon + "'";
                        PS = Conn.prepareStatement(SenSQL);
                        PS.setString(11, "Activa");

                        PS.execute();

                        try //try2
                        {
                            SenSQL2 = "UPDATE habitacion SET alquiler=? WHERE codHabitaciones='" + CodH2 + "'";
                            PS2 = Conn.prepareStatement(SenSQL2);
                            PS2.setString(7, "Ocupada");

                            PS2.execute();
                            Conn.close();

                        } catch (SQLException ex) {//vacio por que solo una condicion
                        }//try2

                    } catch (SQLException ex) {//vacio por que solo una condicion
                    }//try1

                    Object auto = null, viaje = null, chofer = null;
                    int codigo = 0;
                    try {
                        ConectarBD();
                        SenSQL = "SELECT * FROM tipoalquilervihiculo WHERE idTipo ='" + TipoVehiculo + "'";
                        PS = Conn.prepareStatement(SenSQL);
                        RS = PS.executeQuery();

                        while (RS.next()) {
                            auto = RS.getString(3);
                            viaje = RS.getString(4);
                            chofer = RS.getString(5);

                        }

                        Conn.close();

                    } catch (SQLException ex) {
                        System.out.println("Error al contactar registro de habitaciones: " + ex.getMessage());
                    }

                    if (auto != null) {
                        //*Servicio de AUTO Cuando es distinto a nulo
                        codigo = Integer.parseInt(auto.toString());
                        int id = 0;

                        try {
                            ConectarBD();
                            SenSQL = "SELECT * FROM alquilerauto WHERE idalquiler = '" + codigo + "'";
                            PS = Conn.prepareStatement(SenSQL);
                            RS = PS.executeQuery();

                            while (RS.next()) {
                                id = RS.getInt(4);

                            }

                            Conn.close();

                        } catch (SQLException ex) {
                            System.out.println("Error al contactar precio de habitacion: " + ex.getMessage());
                        }

                        try {
                            ConectarBD();
                            SenSQL = "UPDATE alquilerauto SET estado='Activo' WHERE idalquiler='" + codigo + "'";
                            PS = Conn.prepareStatement(SenSQL);

                            PS.execute();
                            Conn.close();

                        } catch (SQLException ex) {
                            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "Err: " + ex);
                            not.showNotification();
                        }

                        try {
                            ConectarBD();
                            SenSQL = "UPDATE automovil SET alquiler='Ocupado' WHERE idAutomovil= '" + id + "'";
                            PS = Conn.prepareStatement(SenSQL);

                            PS.execute();
                            Conn.close();

                        } catch (SQLException ex) {
                            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "Err: " + ex);
                            not.showNotification();
                        }
                    }

                }
            }

            Conn.close();

        } catch (SQLException ex) {
            System.out.println("Error al actualizar estado de reservacion: " + ex.getMessage());
        }

        //END STATUS UPDATER
        //Llenado de Reservaciones en tabla inicial
        LeerHab();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        TabbedP = new javax.swing.JTabbedPane();
        PCrear = new java.awt.Panel();
        s1 = new javax.swing.JSeparator();
        s2 = new javax.swing.JSeparator();
        s3 = new javax.swing.JSeparator();
        s4 = new javax.swing.JSeparator();
        tInfoCliente = new javax.swing.JLabel();
        tConfRes = new javax.swing.JLabel();
        tLlegada = new javax.swing.JLabel();
        tNoches = new javax.swing.JLabel();
        tSalida = new javax.swing.JLabel();
        ChooserLlegada = new com.toedter.calendar.JDateChooser();
        ChooserSalida = new com.toedter.calendar.JDateChooser();
        tApellido = new javax.swing.JLabel();
        tNombre = new javax.swing.JLabel();
        tDireccion = new javax.swing.JLabel();
        tEdad = new javax.swing.JLabel();
        tTelefono = new javax.swing.JLabel();
        tIDCliente = new javax.swing.JLabel();
        tDiscapacidad = new javax.swing.JLabel();
        FieldDireccion = new javax.swing.JTextField();
        FieldNombre = new javax.swing.JTextField();
        FieldApellido = new javax.swing.JTextField();
        FieldEdad = new javax.swing.JTextField();
        CheckDiscap = new javax.swing.JCheckBox();
        BRegRes = new javax.swing.JButton();
        tHabitacion = new javax.swing.JLabel();
        tTarifaEsp = new javax.swing.JLabel();
        ComboTarifa = new javax.swing.JComboBox<>();
        tFecha = new javax.swing.JLabel();
        tPago = new javax.swing.JLabel();
        tTarjeta = new javax.swing.JLabel();
        tVencimiento = new javax.swing.JLabel();
        FrmTarjeta = new javax.swing.JFormattedTextField();
        FrmVencimiento = new javax.swing.JFormattedTextField();
        tHoy = new javax.swing.JLabel();
        tHoyFecha = new javax.swing.JLabel();
        BNoches = new javax.swing.JButton();
        ScrollHabs = new javax.swing.JScrollPane();
        TableHabs = new javax.swing.JTable();
        BDetalles = new javax.swing.JButton();
        tPNeto = new javax.swing.JLabel();
        tNeto = new javax.swing.JLabel();
        tImpuesto = new javax.swing.JLabel();
        tImp = new javax.swing.JLabel();
        ScrollPoliza = new javax.swing.JScrollPane();
        AreaPoliza = new javax.swing.JTextArea();
        tPoliza = new javax.swing.JLabel();
        BSearchClient = new javax.swing.JButton();
        BLimpiarTodo = new javax.swing.JButton();
        CSalida = new javax.swing.JTextField();
        CLlegada = new javax.swing.JTextField();
        CNoches = new javax.swing.JTextField();
        CTPago = new javax.swing.JTextField();
        CHabitacion = new javax.swing.JTextField();
        CTotal = new javax.swing.JTextField();
        tCFechas = new javax.swing.JLabel();
        tCPago = new javax.swing.JLabel();
        tCExtra = new javax.swing.JLabel();
        CFieldIDT = new javax.swing.JTextField();
        BListoCheck = new javax.swing.JButton();
        CheckTarjeta = new javax.swing.JCheckBox();
        CheckEfectivo = new javax.swing.JCheckBox();
        tTotal = new javax.swing.JLabel();
        tTot = new javax.swing.JLabel();
        BTransport = new javax.swing.JButton();
        FieldIDC = new javax.swing.JTextField();
        FieldTLF = new javax.swing.JTextField();
        CFieldCosto = new javax.swing.JTextField();
        CFieldTipoT = new javax.swing.JTextField();
        ComboTrans = new javax.swing.JComboBox<>();
        BLMP = new javax.swing.JButton();
        PMod = new java.awt.Panel();
        tIdConf = new javax.swing.JLabel();
        sMod1 = new javax.swing.JSeparator();
        sMod2 = new javax.swing.JSeparator();
        sMod4 = new javax.swing.JSeparator();
        tResultados = new javax.swing.JLabel();
        FieldBusq = new javax.swing.JTextField();
        ComboBusq = new javax.swing.JComboBox<>();
        ScrollExistRes = new javax.swing.JScrollPane();
        TableExisting = new javax.swing.JTable();
        BModRes = new javax.swing.JButton();
        BDelRes = new javax.swing.JButton();
        tFechaLlegaEx = new javax.swing.JLabel();
        FieldLlegadaEx = new javax.swing.JTextField();
        tFechaSaliEx = new javax.swing.JLabel();
        FieldSalidaEx = new javax.swing.JTextField();
        FieldConfEx = new javax.swing.JTextField();
        tConfEx = new javax.swing.JLabel();
        tNombreEx = new javax.swing.JLabel();
        FieldNombreEx = new javax.swing.JTextField();
        tHabitacionEx = new javax.swing.JLabel();
        FieldHabitacionEx = new javax.swing.JTextField();
        tTotalEx = new javax.swing.JLabel();
        tTarjetaEx = new javax.swing.JLabel();
        FieldTotalEx = new javax.swing.JTextField();
        FieldPagoEx = new javax.swing.JTextField();
        FieldTarjetaEx = new javax.swing.JTextField();
        tPagoEx = new javax.swing.JLabel();
        BSearchRes = new javax.swing.JButton();
        BCancEdit = new javax.swing.JButton();
        tBordeMetodo1 = new javax.swing.JLabel();
        FieldTVeh = new javax.swing.JTextField();
        tPagoEx1 = new javax.swing.JLabel();
        BGuardar1 = new javax.swing.JButton();
        ChooserEditL = new com.toedter.calendar.JDateChooser();
        ChooserEditS = new com.toedter.calendar.JDateChooser();
        tSalidaEdit = new javax.swing.JLabel();
        tHabNox = new javax.swing.JLabel();
        tNMod = new javax.swing.JLabel();
        tHabMod = new javax.swing.JLabel();
        FieldTotalMod = new javax.swing.JTextField();
        tBordeMetodo2 = new javax.swing.JLabel();
        tTotalMod = new javax.swing.JLabel();
        tLlegadaEdit = new javax.swing.JLabel();
        ComboMod = new javax.swing.JComboBox<>();
        BNochesMod = new javax.swing.JButton();
        tLpsMod = new javax.swing.JLabel();
        BListMod = new javax.swing.JButton();
        tBordeEdit = new javax.swing.JLabel();
        BFuturas = new javax.swing.JButton();
        BLimpiarEx = new javax.swing.JButton();
        BCanceladas = new javax.swing.JButton();
        BActivas = new javax.swing.JButton();
        PUpper = new java.awt.Panel();
        ExitSys = new javax.swing.JButton();
        MinimizeSys = new javax.swing.JButton();
        tSoftwHotel = new javax.swing.JLabel();
        tIcHotel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Reservaciones");
        setFocusCycleRoot(false);
        setMinimumSize(new java.awt.Dimension(1010, 810));
        setName("ResForm"); // NOI18N
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TabbedP.setBackground(new java.awt.Color(204, 255, 204));
        TabbedP.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 255), 10));
        TabbedP.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        TabbedP.setMinimumSize(new java.awt.Dimension(1010, 810));
        TabbedP.setPreferredSize(new java.awt.Dimension(1010, 810));

        PCrear.setBackground(new java.awt.Color(204, 204, 204));
        PCrear.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        PCrear.add(s1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 84, 997, 10));
        PCrear.add(s2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 299, 997, 10));
        PCrear.add(s3, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 535, 997, 10));
        PCrear.add(s4, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 684, 997, 10));

        tInfoCliente.setBackground(new java.awt.Color(204, 204, 204));
        tInfoCliente.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tInfoCliente.setForeground(new java.awt.Color(0, 102, 255));
        tInfoCliente.setText("Informacion de Cliente");
        PCrear.add(tInfoCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 315, 258, -1));

        tConfRes.setBackground(new java.awt.Color(204, 204, 204));
        tConfRes.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tConfRes.setForeground(new java.awt.Color(0, 102, 255));
        tConfRes.setText("Confirmacion de Reservacion");
        PCrear.add(tConfRes, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 551, -1, -1));

        tLlegada.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tLlegada.setText("Llegada");
        PCrear.add(tLlegada, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 43, 73, -1));

        tNoches.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tNoches.setText("Noches:");
        PCrear.add(tNoches, new org.netbeans.lib.awtextra.AbsoluteConstraints(575, 43, 73, -1));

        tSalida.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tSalida.setText("Salida");
        PCrear.add(tSalida, new org.netbeans.lib.awtextra.AbsoluteConstraints(308, 43, 61, -1));

        ChooserLlegada.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        PCrear.add(ChooserLlegada, new org.netbeans.lib.awtextra.AbsoluteConstraints(107, 43, 181, -1));

        ChooserSalida.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        PCrear.add(ChooserSalida, new org.netbeans.lib.awtextra.AbsoluteConstraints(375, 43, 180, -1));

        tApellido.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tApellido.setText("Apellido");
        PCrear.add(tApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 417, 99, -1));

        tNombre.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tNombre.setText("Nombre");
        PCrear.add(tNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 383, 99, -1));

        tDireccion.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tDireccion.setText("Direccion");
        PCrear.add(tDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(452, 349, 128, -1));

        tEdad.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tEdad.setText("Edad");
        PCrear.add(tEdad, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 451, 99, -1));

        tTelefono.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tTelefono.setText("Telefono");
        tTelefono.setToolTipText("Telefono");
        PCrear.add(tTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 485, 99, -1));

        tIDCliente.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tIDCliente.setText("ID Cliente");
        PCrear.add(tIDCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 349, 99, -1));

        tDiscapacidad.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tDiscapacidad.setText("Discapacidad");
        PCrear.add(tDiscapacidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(452, 383, 128, -1));

        FieldDireccion.setEditable(false);
        FieldDireccion.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        FieldDireccion.setBorder(null);
        FieldDireccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FieldDireccionActionPerformed(evt);
            }
        });
        PCrear.add(FieldDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(586, 354, 224, -1));

        FieldNombre.setEditable(false);
        FieldNombre.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        FieldNombre.setBorder(null);
        PCrear.add(FieldNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(149, 388, 205, -1));

        FieldApellido.setEditable(false);
        FieldApellido.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        FieldApellido.setBorder(null);
        PCrear.add(FieldApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(149, 422, 205, -1));

        FieldEdad.setEditable(false);
        FieldEdad.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        FieldEdad.setBorder(null);
        PCrear.add(FieldEdad, new org.netbeans.lib.awtextra.AbsoluteConstraints(149, 456, 205, -1));

        CheckDiscap.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        CheckDiscap.setBorder(null);
        CheckDiscap.setEnabled(false);
        PCrear.add(CheckDiscap, new org.netbeans.lib.awtextra.AbsoluteConstraints(586, 383, -1, -1));

        BRegRes.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        BRegRes.setForeground(new java.awt.Color(0, 153, 0));
        BRegRes.setText("REGISTRAR NUEVA RESERVACION");
        BRegRes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BRegResActionPerformed(evt);
            }
        });
        PCrear.add(BRegRes, new org.netbeans.lib.awtextra.AbsoluteConstraints(376, 698, 271, -1));

        tHabitacion.setBackground(new java.awt.Color(204, 204, 204));
        tHabitacion.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tHabitacion.setForeground(new java.awt.Color(0, 102, 255));
        tHabitacion.setText("Habitacion");
        PCrear.add(tHabitacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 100, 260, -1));

        tTarifaEsp.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tTarifaEsp.setText("Tarifa especial");
        PCrear.add(tTarifaEsp, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 146, 184, -1));

        ComboTarifa.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        ComboTarifa.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar", "Tercera edad", "Gobierno", "Personal Hotel", "Milicia", "Veterano" }));
        ComboTarifa.setToolTipText("Tarifas aplicables");
        ComboTarifa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboTarifaActionPerformed(evt);
            }
        });
        PCrear.add(ComboTarifa, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 174, 184, -1));

        tFecha.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tFecha.setForeground(new java.awt.Color(0, 102, 255));
        tFecha.setText("Fechas");
        PCrear.add(tFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 15, 117, -1));

        tPago.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tPago.setText("Tipo de pago");
        PCrear.add(tPago, new org.netbeans.lib.awtextra.AbsoluteConstraints(452, 417, 128, -1));

        tTarjeta.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tTarjeta.setText("Tarjeta");
        tTarjeta.setToolTipText("Numero de tarjeta");
        PCrear.add(tTarjeta, new org.netbeans.lib.awtextra.AbsoluteConstraints(452, 451, 128, -1));

        tVencimiento.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tVencimiento.setText("Vencimiento");
        PCrear.add(tVencimiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(452, 485, 128, -1));

        FrmTarjeta.setBorder(null);
        try {
            FrmTarjeta.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("####-####-####-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        FrmTarjeta.setToolTipText("16 Digitos");
        FrmTarjeta.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        PCrear.add(FrmTarjeta, new org.netbeans.lib.awtextra.AbsoluteConstraints(586, 456, 132, -1));

        FrmVencimiento.setBorder(null);
        try {
            FrmVencimiento.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        FrmVencimiento.setToolTipText("MM/YY");
        FrmVencimiento.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        PCrear.add(FrmVencimiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(586, 490, 78, -1));

        tHoy.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tHoy.setText("Hoy:");
        PCrear.add(tHoy, new org.netbeans.lib.awtextra.AbsoluteConstraints(796, 43, 46, -1));

        tHoyFecha.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        tHoyFecha.setForeground(new java.awt.Color(0, 153, 51));
        tHoyFecha.setText("-");
        PCrear.add(tHoyFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(848, 43, 144, -1));

        BNoches.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        BNoches.setText("Obtener");
        BNoches.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BNochesMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BNochesMouseExited(evt);
            }
        });
        BNoches.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BNochesActionPerformed(evt);
            }
        });
        PCrear.add(BNoches, new org.netbeans.lib.awtextra.AbsoluteConstraints(654, 45, -1, -1));

        TableHabs.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        TableHabs.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Habitacion", "Capacidad", "Precio"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TableHabs.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableHabsMouseClicked(evt);
            }
        });
        ScrollHabs.setViewportView(TableHabs);

        PCrear.add(ScrollHabs, new org.netbeans.lib.awtextra.AbsoluteConstraints(297, 146, 660, 141));

        BDetalles.setBackground(new java.awt.Color(153, 153, 153));
        BDetalles.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        BDetalles.setIcon(new javax.swing.ImageIcon(getClass().getResource("/VerMas.png"))); // NOI18N
        BDetalles.setText("Detalles");
        BDetalles.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        BDetalles.setBorderPainted(false);
        BDetalles.setContentAreaFilled(false);
        BDetalles.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        BDetalles.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BDetallesMouseClicked(evt);
            }
        });
        BDetalles.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BDetallesActionPerformed(evt);
            }
        });
        PCrear.add(BDetalles, new org.netbeans.lib.awtextra.AbsoluteConstraints(865, 100, -1, -1));

        tPNeto.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        tPNeto.setForeground(new java.awt.Color(0, 153, 51));
        tPNeto.setText("--");
        tPNeto.setToolTipText("");
        PCrear.add(tPNeto, new org.netbeans.lib.awtextra.AbsoluteConstraints(133, 207, -1, -1));

        tNeto.setFont(new java.awt.Font("Roboto Black", 0, 16)); // NOI18N
        tNeto.setText("Neto");
        PCrear.add(tNeto, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 209, 82, -1));

        tImpuesto.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        tImpuesto.setForeground(new java.awt.Color(0, 153, 51));
        tImpuesto.setText("--");
        PCrear.add(tImpuesto, new org.netbeans.lib.awtextra.AbsoluteConstraints(132, 235, -1, -1));

        tImp.setFont(new java.awt.Font("Roboto Black", 0, 16)); // NOI18N
        tImp.setText("Impuesto");
        PCrear.add(tImp, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 237, 82, -1));

        AreaPoliza.setEditable(false);
        AreaPoliza.setBackground(new java.awt.Color(255, 255, 255));
        AreaPoliza.setColumns(20);
        AreaPoliza.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        AreaPoliza.setRows(5);
        ScrollPoliza.setViewportView(AreaPoliza);

        PCrear.add(ScrollPoliza, new org.netbeans.lib.awtextra.AbsoluteConstraints(615, 598, 351, 68));

        tPoliza.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        tPoliza.setText("Poliza de cancelacion");
        tPoliza.setToolTipText("");
        PCrear.add(tPoliza, new org.netbeans.lib.awtextra.AbsoluteConstraints(615, 575, 327, -1));

        BSearchClient.setBackground(new java.awt.Color(153, 153, 153));
        BSearchClient.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        BSearchClient.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Search.png"))); // NOI18N
        BSearchClient.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        BSearchClient.setBorderPainted(false);
        BSearchClient.setContentAreaFilled(false);
        BSearchClient.setDoubleBuffered(true);
        BSearchClient.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        BSearchClient.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BSearchClientMouseClicked(evt);
            }
        });
        BSearchClient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BSearchClientActionPerformed(evt);
            }
        });
        PCrear.add(BSearchClient, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 349, -1, 22));

        BLimpiarTodo.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        BLimpiarTodo.setText("Deshacer");
        BLimpiarTodo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BLimpiarTodoMouseClicked(evt);
            }
        });
        BLimpiarTodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BLimpiarTodoActionPerformed(evt);
            }
        });
        PCrear.add(BLimpiarTodo, new org.netbeans.lib.awtextra.AbsoluteConstraints(843, 699, 120, -1));

        CSalida.setEditable(false);
        CSalida.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        CSalida.setText("Salida");
        CSalida.setBorder(null);
        PCrear.add(CSalida, new org.netbeans.lib.awtextra.AbsoluteConstraints(283, 580, 147, -1));

        CLlegada.setEditable(false);
        CLlegada.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        CLlegada.setText("Llegada");
        CLlegada.setBorder(null);
        PCrear.add(CLlegada, new org.netbeans.lib.awtextra.AbsoluteConstraints(124, 580, 147, -1));

        CNoches.setEditable(false);
        CNoches.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        CNoches.setText("Noches");
        CNoches.setBorder(null);
        PCrear.add(CNoches, new org.netbeans.lib.awtextra.AbsoluteConstraints(442, 580, 147, -1));

        CTPago.setEditable(false);
        CTPago.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        CTPago.setText("TPago");
        CTPago.setBorder(null);
        PCrear.add(CTPago, new org.netbeans.lib.awtextra.AbsoluteConstraints(124, 615, 147, -1));

        CHabitacion.setEditable(false);
        CHabitacion.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        CHabitacion.setText("Habitacion");
        CHabitacion.setBorder(null);
        PCrear.add(CHabitacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(283, 615, 147, -1));

        CTotal.setEditable(false);
        CTotal.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        CTotal.setText("Total");
        CTotal.setBorder(null);
        PCrear.add(CTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(442, 615, 147, -1));

        tCFechas.setFont(new java.awt.Font("Roboto Black", 0, 14)); // NOI18N
        tCFechas.setText("Fechas / Noches");
        PCrear.add(tCFechas, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 579, -1, -1));

        tCPago.setFont(new java.awt.Font("Roboto Black", 0, 14)); // NOI18N
        tCPago.setText("Detalles pago");
        PCrear.add(tCPago, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 614, 106, -1));

        tCExtra.setFont(new java.awt.Font("Roboto Black", 0, 14)); // NOI18N
        tCExtra.setText("Extra");
        PCrear.add(tCExtra, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 649, 106, -1));

        CFieldIDT.setEditable(false);
        CFieldIDT.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        CFieldIDT.setText("1");
        CFieldIDT.setBorder(null);
        PCrear.add(CFieldIDT, new org.netbeans.lib.awtextra.AbsoluteConstraints(124, 650, 147, -1));

        BListoCheck.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        BListoCheck.setIcon(new javax.swing.ImageIcon(getClass().getResource("/checked (1).png"))); // NOI18N
        BListoCheck.setText("Listo");
        BListoCheck.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BListoCheck.setContentAreaFilled(false);
        BListoCheck.setDoubleBuffered(true);
        BListoCheck.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        BListoCheck.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/quality (1).png"))); // NOI18N
        BListoCheck.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BListoCheckMouseClicked(evt);
            }
        });
        BListoCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BListoCheckActionPerformed(evt);
            }
        });
        PCrear.add(BListoCheck, new org.netbeans.lib.awtextra.AbsoluteConstraints(855, 488, 112, -1));

        CheckTarjeta.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        CheckTarjeta.setText("Tarjeta");
        CheckTarjeta.setContentAreaFilled(false);
        PCrear.add(CheckTarjeta, new org.netbeans.lib.awtextra.AbsoluteConstraints(586, 420, 85, -1));

        CheckEfectivo.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        CheckEfectivo.setText("Efectivo");
        CheckEfectivo.setContentAreaFilled(false);
        PCrear.add(CheckEfectivo, new org.netbeans.lib.awtextra.AbsoluteConstraints(701, 420, 85, -1));

        tTotal.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        tTotal.setForeground(new java.awt.Color(0, 153, 51));
        tTotal.setText("--");
        PCrear.add(tTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(133, 265, -1, -1));

        tTot.setFont(new java.awt.Font("Roboto Black", 0, 16)); // NOI18N
        tTot.setText("Total");
        PCrear.add(tTot, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 267, 82, -1));

        BTransport.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        BTransport.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Transport.png"))); // NOI18N
        BTransport.setText("Tranporte");
        BTransport.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BTransport.setContentAreaFilled(false);
        BTransport.setDoubleBuffered(true);
        BTransport.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        BTransport.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/TransPress.png"))); // NOI18N
        BTransport.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BTransportMouseClicked(evt);
            }
        });
        BTransport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTransportActionPerformed(evt);
            }
        });
        PCrear.add(BTransport, new org.netbeans.lib.awtextra.AbsoluteConstraints(855, 381, 112, -1));

        FieldIDC.setEditable(false);
        FieldIDC.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        FieldIDC.setBorder(null);
        PCrear.add(FieldIDC, new org.netbeans.lib.awtextra.AbsoluteConstraints(149, 354, 205, -1));

        FieldTLF.setEditable(false);
        FieldTLF.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        FieldTLF.setBorder(null);
        PCrear.add(FieldTLF, new org.netbeans.lib.awtextra.AbsoluteConstraints(149, 490, 205, -1));

        CFieldCosto.setEditable(false);
        CFieldCosto.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        CFieldCosto.setText("Costo");
        CFieldCosto.setBorder(null);
        PCrear.add(CFieldCosto, new org.netbeans.lib.awtextra.AbsoluteConstraints(442, 650, 147, -1));

        CFieldTipoT.setEditable(false);
        CFieldTipoT.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        CFieldTipoT.setText("TipoTransporte");
        CFieldTipoT.setBorder(null);
        PCrear.add(CFieldTipoT, new org.netbeans.lib.awtextra.AbsoluteConstraints(283, 650, 147, -1));

        ComboTrans.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        ComboTrans.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar", "Viaje", "Auto", "Chofer" }));
        ComboTrans.setToolTipText("Tarifas aplicables");
        ComboTrans.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboTransActionPerformed(evt);
            }
        });
        PCrear.add(ComboTrans, new org.netbeans.lib.awtextra.AbsoluteConstraints(855, 354, 112, -1));

        BLMP.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        BLMP.setText("Limpiar");
        BLMP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BLMPActionPerformed(evt);
            }
        });
        PCrear.add(BLMP, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 699, 123, -1));

        TabbedP.addTab("     Reservacion nueva     ", PCrear);

        PMod.setBackground(new java.awt.Color(204, 204, 204));
        PMod.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        PMod.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tIdConf.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tIdConf.setForeground(new java.awt.Color(0, 102, 255));
        tIdConf.setText("IDCliente / Confirmacion");
        PMod.add(tIdConf, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 230, -1));
        PMod.add(sMod1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 988, 10));
        PMod.add(sMod2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 300, 988, 10));
        PMod.add(sMod4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 680, 988, 10));

        tResultados.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        tResultados.setForeground(new java.awt.Color(0, 102, 255));
        tResultados.setText("Resultados de busqueda");
        PMod.add(tResultados, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, 230, 20));

        FieldBusq.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        PMod.add(FieldBusq, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 20, 290, 30));

        ComboBusq.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        ComboBusq.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ID Cliente", "Confirmacion" }));
        PMod.add(ComboBusq, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, 100, 30));

        TableExisting.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        TableExisting.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "# Confirmacion", "ID Cliente", "F. Llegada", "F. Salida", "Habitacion", "Transporte", "Total", "Metodo pago", "Tarjeta", "Vencimiento", "Estado"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TableExisting.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableExistingMouseClicked(evt);
            }
        });
        ScrollExistRes.setViewportView(TableExisting);

        PMod.add(ScrollExistRes, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, 920, 130));

        BModRes.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        BModRes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/edit.png"))); // NOI18N
        BModRes.setText("Modificar datos reservacion");
        BModRes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BModResMouseClicked(evt);
            }
        });
        BModRes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BModResActionPerformed(evt);
            }
        });
        PMod.add(BModRes, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 690, 270, 30));

        BDelRes.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        BDelRes.setForeground(new java.awt.Color(255, 0, 51));
        BDelRes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/delete.png"))); // NOI18N
        BDelRes.setText("Cancelar reservacion");
        BDelRes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BDelResActionPerformed(evt);
            }
        });
        PMod.add(BDelRes, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 690, 280, 30));

        tFechaLlegaEx.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        tFechaLlegaEx.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tFechaLlegaEx.setText("Fecha Llegada");
        PMod.add(tFechaLlegaEx, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 400, 210, -1));

        FieldLlegadaEx.setEditable(false);
        FieldLlegadaEx.setBackground(new java.awt.Color(204, 204, 204));
        FieldLlegadaEx.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        FieldLlegadaEx.setForeground(new java.awt.Color(0, 102, 255));
        PMod.add(FieldLlegadaEx, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 420, 210, 30));

        tFechaSaliEx.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        tFechaSaliEx.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tFechaSaliEx.setText("Fecha Salida");
        PMod.add(tFechaSaliEx, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 400, 200, -1));

        FieldSalidaEx.setEditable(false);
        FieldSalidaEx.setBackground(new java.awt.Color(204, 204, 204));
        FieldSalidaEx.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        FieldSalidaEx.setForeground(new java.awt.Color(0, 102, 255));
        PMod.add(FieldSalidaEx, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 420, 200, 30));

        FieldConfEx.setEditable(false);
        FieldConfEx.setBackground(new java.awt.Color(204, 204, 204));
        FieldConfEx.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        FieldConfEx.setForeground(new java.awt.Color(0, 102, 255));
        PMod.add(FieldConfEx, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 370, 210, 30));

        tConfEx.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        tConfEx.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tConfEx.setText("Numero de Confirmacion");
        PMod.add(tConfEx, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 350, 210, -1));

        tNombreEx.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        tNombreEx.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tNombreEx.setText("Identidad Cliente");
        PMod.add(tNombreEx, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 350, 200, -1));

        FieldNombreEx.setEditable(false);
        FieldNombreEx.setBackground(new java.awt.Color(204, 204, 204));
        FieldNombreEx.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        FieldNombreEx.setForeground(new java.awt.Color(0, 102, 255));
        PMod.add(FieldNombreEx, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 370, 200, 30));

        tHabitacionEx.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        tHabitacionEx.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tHabitacionEx.setText("Habitacion");
        PMod.add(tHabitacionEx, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 450, 210, -1));

        FieldHabitacionEx.setEditable(false);
        FieldHabitacionEx.setBackground(new java.awt.Color(204, 204, 204));
        FieldHabitacionEx.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        FieldHabitacionEx.setForeground(new java.awt.Color(0, 102, 255));
        PMod.add(FieldHabitacionEx, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 470, 210, 30));

        tTotalEx.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        tTotalEx.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tTotalEx.setText("Total");
        PMod.add(tTotalEx, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 450, 200, -1));

        tTarjetaEx.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        tTarjetaEx.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tTarjetaEx.setText("Tarjeta");
        PMod.add(tTarjetaEx, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 600, 210, -1));

        FieldTotalEx.setEditable(false);
        FieldTotalEx.setBackground(new java.awt.Color(204, 204, 204));
        FieldTotalEx.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        FieldTotalEx.setForeground(new java.awt.Color(0, 102, 255));
        PMod.add(FieldTotalEx, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 470, 200, 30));

        FieldPagoEx.setEditable(false);
        FieldPagoEx.setBackground(new java.awt.Color(204, 204, 204));
        FieldPagoEx.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        FieldPagoEx.setForeground(new java.awt.Color(0, 102, 255));
        PMod.add(FieldPagoEx, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 560, 210, 30));

        FieldTarjetaEx.setEditable(false);
        FieldTarjetaEx.setBackground(new java.awt.Color(204, 204, 204));
        FieldTarjetaEx.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        FieldTarjetaEx.setForeground(new java.awt.Color(0, 102, 255));
        PMod.add(FieldTarjetaEx, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 620, 210, 30));

        tPagoEx.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        tPagoEx.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tPagoEx.setText("Tipo de pago");
        PMod.add(tPagoEx, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 540, 210, -1));

        BSearchRes.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        BSearchRes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Search.png"))); // NOI18N
        BSearchRes.setText("Buscar");
        BSearchRes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BSearchResMouseClicked(evt);
            }
        });
        BSearchRes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BSearchResActionPerformed(evt);
            }
        });
        PMod.add(BSearchRes, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 20, 100, 30));

        BCancEdit.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        BCancEdit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Canceladas.png"))); // NOI18N
        BCancEdit.setText("Cancelar");
        BCancEdit.setIconTextGap(5);
        BCancEdit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BCancEditMouseClicked(evt);
            }
        });
        BCancEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BCancEditActionPerformed(evt);
            }
        });
        PMod.add(BCancEdit, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 620, 170, 30));

        tBordeMetodo1.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        tBordeMetodo1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tBordeMetodo1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Metodo de pago", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Roboto Medium", 0, 12))); // NOI18N
        PMod.add(tBordeMetodo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 520, 250, 140));

        FieldTVeh.setEditable(false);
        FieldTVeh.setBackground(new java.awt.Color(204, 204, 204));
        FieldTVeh.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        FieldTVeh.setForeground(new java.awt.Color(0, 102, 255));
        PMod.add(FieldTVeh, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 580, 210, 30));

        tPagoEx1.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        tPagoEx1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tPagoEx1.setText("Tipo");
        PMod.add(tPagoEx1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 560, 210, -1));

        BGuardar1.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        BGuardar1.setForeground(new java.awt.Color(0, 153, 0));
        BGuardar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Save.png"))); // NOI18N
        BGuardar1.setText("Guardar cambios");
        BGuardar1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BGuardar1MouseClicked(evt);
            }
        });
        BGuardar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BGuardar1ActionPerformed(evt);
            }
        });
        PMod.add(BGuardar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 620, 170, 30));

        ChooserEditL.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        PMod.add(ChooserEditL, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 390, 130, 30));

        ChooserEditS.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        PMod.add(ChooserEditS, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 390, 130, 30));

        tSalidaEdit.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        tSalidaEdit.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tSalidaEdit.setText("fecha salida");
        PMod.add(tSalidaEdit, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 370, 130, -1));

        tHabNox.setBackground(new java.awt.Color(51, 51, 51));
        tHabNox.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        tHabNox.setForeground(new java.awt.Color(255, 255, 255));
        tHabNox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        PMod.add(tHabNox, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 570, 100, 30));

        tNMod.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        tNMod.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        tNMod.setText("Noche");
        PMod.add(tNMod, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 570, 70, 30));

        tHabMod.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        tHabMod.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tHabMod.setText("Habitacion");
        PMod.add(tHabMod, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 440, 370, -1));

        FieldTotalMod.setEditable(false);
        FieldTotalMod.setBackground(new java.awt.Color(204, 204, 204));
        FieldTotalMod.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        FieldTotalMod.setForeground(new java.awt.Color(255, 255, 255));
        PMod.add(FieldTotalMod, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 570, 140, 30));

        tBordeMetodo2.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        tBordeMetodo2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tBordeMetodo2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Servicio Transporte", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Roboto Medium", 0, 12))); // NOI18N
        PMod.add(tBordeMetodo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 520, 250, 140));

        tTotalMod.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        tTotalMod.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tTotalMod.setText("Total");
        PMod.add(tTotalMod, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 550, 170, -1));

        tLlegadaEdit.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        tLlegadaEdit.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tLlegadaEdit.setText("Fecha llegada");
        PMod.add(tLlegadaEdit, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 370, 130, -1));

        ComboMod.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        ComboMod.setMaximumRowCount(10);
        ComboMod.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));
        PMod.add(ComboMod, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 460, 370, 30));

        BNochesMod.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        BNochesMod.setText("Noches");
        BNochesMod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BNochesModActionPerformed(evt);
            }
        });
        PMod.add(BNochesMod, new org.netbeans.lib.awtextra.AbsoluteConstraints(852, 390, 90, 30));

        tLpsMod.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        tLpsMod.setForeground(new java.awt.Color(0, 204, 0));
        tLpsMod.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        tLpsMod.setText("Lps.");
        PMod.add(tLpsMod, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 570, 40, 30));

        BListMod.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        BListMod.setText("Listo");
        BListMod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BListModActionPerformed(evt);
            }
        });
        PMod.add(BListMod, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 500, 370, -1));

        tBordeEdit.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        tBordeEdit.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tBordeEdit.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Modificar", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Roboto Medium", 0, 12))); // NOI18N
        PMod.add(tBordeEdit, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 350, 410, 320));

        BFuturas.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        BFuturas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Fut.png"))); // NOI18N
        BFuturas.setText("Futuras");
        BFuturas.setIconTextGap(5);
        BFuturas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BFuturasActionPerformed(evt);
            }
        });
        PMod.add(BFuturas, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 20, 120, 30));

        BLimpiarEx.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        BLimpiarEx.setText("Limpiar");
        BLimpiarEx.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BLimpiarExMouseClicked(evt);
            }
        });
        BLimpiarEx.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BLimpiarExActionPerformed(evt);
            }
        });
        PMod.add(BLimpiarEx, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 690, 110, 30));

        BCanceladas.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        BCanceladas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Canceladas.png"))); // NOI18N
        BCanceladas.setText("Canceladas");
        BCanceladas.setIconTextGap(5);
        BCanceladas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BCanceladasActionPerformed(evt);
            }
        });
        PMod.add(BCanceladas, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 20, -1, 30));

        BActivas.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        BActivas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Act.png"))); // NOI18N
        BActivas.setText("Activas");
        BActivas.setIconTextGap(5);
        BActivas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BActivasActionPerformed(evt);
            }
        });
        PMod.add(BActivas, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 20, 120, 30));

        TabbedP.addTab("     Revisar reservacion     ", PMod);

        getContentPane().add(TabbedP, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 1010, 790));

        PUpper.setBackground(new java.awt.Color(0, 153, 255));
        PUpper.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PUpperMousePressed(evt);
            }
        });
        PUpper.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                PUpperMouseDragged(evt);
            }
        });
        PUpper.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ExitSys.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BClose.png"))); // NOI18N
        ExitSys.setContentAreaFilled(false);
        ExitSys.setDoubleBuffered(true);
        ExitSys.setPreferredSize(new java.awt.Dimension(30, 30));
        ExitSys.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExitSysMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ExitSysMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ExitSysMouseExited(evt);
            }
        });
        ExitSys.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitSysActionPerformed(evt);
            }
        });
        PUpper.add(ExitSys, new org.netbeans.lib.awtextra.AbsoluteConstraints(958, 6, 32, 28));

        MinimizeSys.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BMin.png"))); // NOI18N
        MinimizeSys.setContentAreaFilled(false);
        MinimizeSys.setDoubleBuffered(true);
        MinimizeSys.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MinimizeSysActionPerformed(evt);
            }
        });
        PUpper.add(MinimizeSys, new org.netbeans.lib.awtextra.AbsoluteConstraints(922, 6, 30, 28));

        tSoftwHotel.setFont(new java.awt.Font("Roboto Black", 0, 20)); // NOI18N
        tSoftwHotel.setForeground(new java.awt.Color(255, 255, 255));
        tSoftwHotel.setText("Software Hotel");
        PUpper.add(tSoftwHotel, new org.netbeans.lib.awtextra.AbsoluteConstraints(49, 10, 280, -1));

        tIcHotel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/LogIc.png"))); // NOI18N
        tIcHotel.setDoubleBuffered(true);
        PUpper.add(tIcHotel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 6, -1, 28));

        getContentPane().add(PUpper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1010, 40));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void ConectarBD()//Conexion a base
    {
        Conecta = new conexionBD("proyecto_final");
        Conn = Conecta.getConexion();
    }

    //funcion para reciir el tiempo real
    public static String RealTime() {
        Date fecha = new Date();
        SimpleDateFormat formatFecha = new SimpleDateFormat("dd/MM/YYYY");

        SimpleDateFormat dx = new SimpleDateFormat("dd");
        SimpleDateFormat mx = new SimpleDateFormat("MM");
        SimpleDateFormat yx = new SimpleDateFormat("YYYY");
        return formatFecha.format(fecha);
    }

    private void ExitSysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitSysActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ExitSysActionPerformed

    private void MinimizeSysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MinimizeSysActionPerformed
        // Funcion para boton minimizar
        this.setExtendedState(ICONIFIED);
    }//GEN-LAST:event_MinimizeSysActionPerformed

    private void ExitSysMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseClicked
        MessageDialog obj = new MessageDialog(this);
        obj.showMessage("Estas seguro que desea salir?", "Recuerda que puedes volver cuando quieras");

        if (obj.getMessageType() == MessageDialog.MessageType.OK) {
            this.dispose();
        } else {
            System.out.println("User click cancel");
        }


    }//GEN-LAST:event_ExitSysMouseClicked

    private void PUpperMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMouseDragged
        //variables x y para el mouse arrastrado para el panel superior
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);

    }//GEN-LAST:event_PUpperMouseDragged

    private void PUpperMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMousePressed
        //llamando a la funcion por el evento
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_PUpperMousePressed

    private void ExitSysMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseEntered

    }//GEN-LAST:event_ExitSysMouseEntered

    private void ExitSysMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseExited

    }//GEN-LAST:event_ExitSysMouseExited

    private void BDetallesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BDetallesMouseClicked
        //abrir frame de detalles de las habitaciones
        detalles_Reservacion AbrirDet = new detalles_Reservacion();
        AbrirDet.setVisible(true);
    }//GEN-LAST:event_BDetallesMouseClicked

    private void BNochesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BNochesMouseClicked

    }//GEN-LAST:event_BNochesMouseClicked

    private void BSearchResActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BSearchResActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BSearchResActionPerformed

    private void BCancEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BCancEditActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BCancEditActionPerformed

    private void ComboTarifaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboTarifaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboTarifaActionPerformed

    private void BDetallesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BDetallesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BDetallesActionPerformed

    private void FieldDireccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FieldDireccionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FieldDireccionActionPerformed

    private void BSearchClientMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BSearchClientMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_BSearchClientMouseClicked
    private void BSearchClientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BSearchClientActionPerformed
        //llamar MenuClientes
        menuClienteReservaciones AbrirMN = new menuClienteReservaciones();
        AbrirMN.setVisible(true);
    }//GEN-LAST:event_BSearchClientActionPerformed

    private void BNochesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BNochesMouseExited

    }//GEN-LAST:event_BNochesMouseExited

    private void BListoCheckMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BListoCheckMouseClicked

        //fechas
        int dL = ChooserLlegada.getCalendar().get(Calendar.DAY_OF_MONTH), mL = ChooserLlegada.getCalendar().get(Calendar.MONTH) + 1, yL = ChooserLlegada.getCalendar().get(Calendar.YEAR);
        int dS = ChooserSalida.getCalendar().get(Calendar.DAY_OF_MONTH), mS = ChooserSalida.getCalendar().get(Calendar.MONTH) + 1, yS = ChooserSalida.getCalendar().get(Calendar.YEAR);

        //Obtencion de fecha con digitos individuales
        String ConfL = String.valueOf(dL) + "/" + String.valueOf(mL) + "/" + String.valueOf(yL);
        String ConfS = String.valueOf(dS) + "/" + String.valueOf(mS) + "/" + String.valueOf(yS);

        //poliza tarjeta y efectivo
        String polizaT = "Segun nuestra poliza, usted puede cancelar su reservacion \nsin costo  alguno antes del " + dL + " , en caso de ausencia \nen la fecha antes mencionada, se realizara \nel cobro por el costo de una noche de su reservacion";
        String polizaE = "No se aplica poliza, pago en efectivo.";
        //llenado de espacios de confirmacion

        CLlegada.setText(ConfL);
        CSalida.setText(ConfS);
        CNoches.setText(BNoches.getText());

        if (CheckTarjeta.isSelected()) {
            CTPago.setText("Tarjeta");
            AreaPoliza.append(polizaT);
            // CheckEfectivo.setEnabled(false);
        } else if (CheckEfectivo.isSelected()) {

            CTPago.setText("Efectivo");
            AreaPoliza.append(polizaE);
            CheckTarjeta.setEnabled(false);
            FrmTarjeta.setEnabled(false);
            FrmTarjeta.setText(null);
            FrmVencimiento.setEnabled(false);
            FrmVencimiento.setText(null);

        } else {
            JOptionPane.showMessageDialog(null, "Seleccione un metodo de pago.");
        }

        String Tt = tTotal.getText();
        double tTN = Double.parseDouble(Tt);
        double CNConf = Double.parseDouble(CNoches.getText());
        double TotalLast = tTN * CNConf;
        int fila = TableHabs.getSelectedRow();
        String Habit = TableHabs.getValueAt(fila, 1).toString();
        CHabitacion.setText(Habit);
        CTotal.setText(String.valueOf(TotalLast));

        if (FieldIDC.getText().length() > 0 || BNoches.getText() != "Obtener") {
            BRegRes.setEnabled(true);
        }


    }//GEN-LAST:event_BListoCheckMouseClicked

    private void BListoCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BListoCheckActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BListoCheckActionPerformed

    private void BLimpiarTodoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BLimpiarTodoMouseClicked

        if (CFieldIDT.getText().equals("1")) {
            JOptionPane.showMessageDialog(null, "No hay cambios que revertir");
        } else if (CFieldIDT.getText() != "1") {
            try {
                ConectarBD();
                SenSQL = "rollback";
                PS = Conn.prepareStatement(SenSQL);
                RS = PS.executeQuery();
                Conn.close();
                System.out.println("Servicios extra cancelados");

            } catch (SQLException ex) {
                System.out.println("Error al revertir cambios de reservacion no concretada" + ex.getMessage());
            }

        }
        /* if(CheckEfectivo.isSelected()){
            FrmTarjeta.setText(null);
            FrmVencimiento.setText(null);
        }*/
    }//GEN-LAST:event_BLimpiarTodoMouseClicked

    private void BModResMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BModResMouseClicked

        if (FieldConfEx.getText().isEmpty()) {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "Seleccione una reservacion");
            not.showNotification();

        } else {

            int Fsel = TableExisting.getSelectedRow();

            String TEST = TableExisting.getValueAt(Fsel, 10).toString();

            if (TEST.equals("Activa")) {
                JOptionPane.showMessageDialog(null, "No puede modificar una reservacion activa");
            } else {

                ComboMod.setVisible(true);
                tBordeEdit.setVisible(true);
                tLlegadaEdit.setVisible(true);
                ChooserEditL.setVisible(true);
                tTotalMod.setVisible(true);
                BGuardar1.setVisible(true);
                ChooserEditS.setVisible(true);
                tSalidaEdit.setVisible(true);
                BCancEdit.setVisible(true);
                BNochesMod.setVisible(true);
                tHabNox.setVisible(true);
                FieldTotalMod.setVisible(true);
                tLpsMod.setVisible(true);
                tTotalMod.setVisible(true);
                BListMod.setVisible(true);
                tNMod.setVisible(true);
                tHabMod.setVisible(true);

                try {
                    ConectarBD();
                    SenSQL = "SELECT * FROM habitacion WHERE estado LIKE 'Activa'  AND alquiler LIKE 'Disponible'";
                    PS = Conn.prepareStatement(SenSQL);
                    RS = PS.executeQuery();

                    while (RS.next()) {
                        String IDCom = String.valueOf(RS.getInt(1));            //CodHabitacion
                        ComboMod.addItem(IDCom + RS.getString(2));   //habitacion        
                    }

                    Conn.close();

                } catch (SQLException ex) {
                    System.out.println("Error al contactar registro de habitaciones disponibles para modificar: " + ex.getMessage());
                }

            }//fin Else de Activa

        }//fin else vacio
    }//GEN-LAST:event_BModResMouseClicked

    private void TableHabsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableHabsMouseClicked

        int fila = TableHabs.getSelectedRow();

        String IDHab = TableHabs.getValueAt(fila, 0).toString();

        IDHB = IDHab;

        String Data = TableHabs.getValueAt(fila, 3).toString();
        double PrPrice = Double.parseDouble(Data);

        double PrNet = PrPrice * 0.85, PrISV = PrPrice * 0.15;

        tPNeto.setText(String.valueOf(PrNet));
        tImpuesto.setText(String.valueOf(PrISV));

        double PrTotal;

        if (ComboTarifa.getSelectedIndex() == 0)//Seleccionar
        {
            //no aplica descuento
            PrTotal = PrPrice;
            tTotal.setText(String.valueOf(PrTotal));

        } else if (ComboTarifa.getSelectedIndex() == 1) //Tercera edad
        {
            //aplica descuento de la tercera edad 25%
            PrTotal = PrPrice - (PrPrice * 0.25);
            tTotal.setText(String.valueOf(PrTotal));
        } else if (ComboTarifa.getSelectedIndex() == 2) //gobierno
        {
            //aplica descuento para gobierno 10%
            PrTotal = PrPrice - (PrPrice * 0.10);
            tTotal.setText(String.valueOf(PrTotal));
        } else if (ComboTarifa.getSelectedIndex() == 3) // Personal Hotel
        {
            //aplica descuento para personal del hotel 10%
            PrTotal = PrPrice - (PrPrice * 0.10);
            tTotal.setText(String.valueOf(PrTotal));
        } else if (ComboTarifa.getSelectedIndex() == 4) //Milicia
        {
            //aplica descuento para miembros de milicia 15%
            PrTotal = PrPrice - (PrPrice * 0.15);
            tTotal.setText(String.valueOf(PrTotal));
        } else if (ComboTarifa.getSelectedIndex() == 5) //Veterano
        {
            //aplica descuento para veterano de guerra %40
            PrTotal = PrPrice - (PrPrice * 0.40);
            tTotal.setText(String.valueOf(PrTotal));
        }

        //fin de funcion
    }//GEN-LAST:event_TableHabsMouseClicked

    private void BTransportMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BTransportMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_BTransportMouseClicked

    private void BTransportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTransportActionPerformed
        // TODO add your handling code here:

        if (ComboTrans.getSelectedIndex() == 0)//seleccionar
        {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "Seleccione tipo de servicio");
            not.showNotification();

        } else if (ComboTrans.getSelectedIndex() == 1)//viaje = ruta de aeropuerto hacia hotel
        {
            rentaViajes OpenV = new rentaViajes();
            OpenV.setVisible(true);

            //pasar datos de cliente
            rentaViajes.txtCodigo.setText(FieldIDC.getText());
            rentaViajes.txtNombre.setText(FieldNombre.getText());
            rentaViajes.txtApellido.setText(FieldApellido.getText());

            if (CheckDiscap.isSelected()) {
                rentaViajes.txtDiscapacidad.setText("Si");
            } else {
                rentaViajes.txtDiscapacidad.setText("No");
            }

        } else if (ComboTrans.getSelectedIndex() == 2)//auto = alquiler de vehiculo
        {
            rentaAuto OpenA = new rentaAuto();
            OpenA.setVisible(true);

            //pasar datos de cliente
            rentaAuto.txtIdCliente.setText(FieldIDC.getText());
            rentaAuto.txtNombre.setText(FieldNombre.getText());
            rentaAuto.txtApellido.setText(FieldApellido.getText());

            if (CheckDiscap.isSelected()) {
                rentaAuto.txtDiscapacidad.setText("Si");
            } else {
                rentaAuto.txtDiscapacidad.setText("No");
            }

        } else if (ComboTrans.getSelectedIndex() == 3)//chofer
        {
            rentaChofer OpenC = new rentaChofer();
            OpenC.setVisible(true);

            //pasar datos de cliente
            rentaChofer.txtIdCliente.setText(FieldIDC.getText());
            rentaChofer.txtNombre.setText(FieldNombre.getText());
            rentaChofer.txtApellido.setText(FieldApellido.getText());
            rentaChofer.txtDias.setText(BNoches.getText());
            //pendiente pasar dias y llenar automaticamente los dias

            if (CheckDiscap.isSelected()) {
                rentaChofer.txtDiscapacidad.setText("Si");
            } else {
                rentaChofer.txtDiscapacidad.setText("No");
            }

        }


    }//GEN-LAST:event_BTransportActionPerformed

    private void BGuardar1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BGuardar1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_BGuardar1MouseClicked

    private void BFuturasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BFuturasActionPerformed

        Registros_Reservaciones.reservacionesFuturas FUT = new Registros_Reservaciones.reservacionesFuturas();
        FUT.setVisible(true);

    }//GEN-LAST:event_BFuturasActionPerformed

    private void BCancEditMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BCancEditMouseClicked

        ComboMod.setVisible(false);
        tBordeEdit.setVisible(false);
        tLlegadaEdit.setVisible(false);
        ChooserEditL.setVisible(false);
        tTotalMod.setVisible(false);
        BGuardar1.setVisible(false);
        ChooserEditS.setVisible(false);
        tSalidaEdit.setVisible(false);
        BCancEdit.setVisible(false);
        BNochesMod.setVisible(false);
        tHabNox.setVisible(false);
        FieldTotalMod.setVisible(false);
        tLpsMod.setVisible(false);
        tTotalMod.setVisible(false);
        BNochesMod.setVisible(false);
        BListMod.setVisible(false);
        tNMod.setVisible(false);
        tHabMod.setVisible(false);

        tHabNox.setText(null);
        FieldTotalMod.setText(null);
        ComboMod.setSelectedIndex(0);
        BNochesMod.setText("Noches");


    }//GEN-LAST:event_BCancEditMouseClicked

    private void BSearchResMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BSearchResMouseClicked

        limpiarTEX();

        if (FieldBusq.getText().isEmpty() || FieldBusq.getText().length() > 20) {

            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "Inserte dato valido para busqueda");
            not.showNotification();
        } else if (ComboBusq.getSelectedIndex() == 0)//ID Cliente
        {

            try {
                ConectarBD();
                SenSQL = "SELECT * FROM reservacion WHERE identidadCliente LIKE '" + FieldBusq.getText() + "' AND estado != 'Cancelada'";
                PS = Conn.prepareStatement(SenSQL);
                RS = PS.executeQuery();

                Object Ress[] = new Object[11];
                model = (DefaultTableModel) TableExisting.getModel();

                while (RS.next()) {
                    Ress[0] = (RS.getInt(1));
                    Ress[1] = (RS.getString(2));
                    Ress[2] = (RS.getDate(3));
                    Ress[3] = (RS.getDate(4));
                    Ress[4] = (RS.getInt(5));
                    Ress[5] = (RS.getInt(6));
                    Ress[6] = (RS.getDouble(7));
                    Ress[7] = (RS.getString(8));
                    Ress[8] = (RS.getString(9));
                    Ress[9] = (RS.getString(10));
                    Ress[10] = (RS.getString(11));

                    model.addRow(Ress);
                }
                TableExisting.setModel(model);

                Conn.close();
                // LimpiarEx();
            } catch (SQLException ex) {
                System.out.println("Error al contactar reservaciones existentes: " + ex.getMessage());
            }

        }//fin busqueda * cliente
        else if (ComboBusq.getSelectedIndex() == 1)//Confirmacion
        {

            String IDS = FieldBusq.getText();
            int IDX = Integer.parseInt(IDS);

            try {

                ConectarBD();
                SenSQL = "SELECT * FROM reservacion WHERE codreserva ='" + Integer.parseInt(FieldBusq.getText()) + "' AND estado != 'Cancelada'";
                PS = Conn.prepareStatement(SenSQL);
                RS = PS.executeQuery();

                DefaultTableModel model;
                Object Ress[] = new Object[11];

                model = (DefaultTableModel) TableExisting.getModel();

                while (RS.next()) {
                    Ress[0] = (RS.getInt(1));
                    Ress[1] = (RS.getString(2));
                    Ress[2] = (RS.getDate(3));
                    Ress[3] = (RS.getDate(4));
                    Ress[4] = (RS.getInt(5));
                    Ress[5] = (RS.getInt(6));
                    Ress[6] = (RS.getDouble(7));
                    Ress[7] = (RS.getString(8));
                    Ress[8] = (RS.getString(9));
                    Ress[9] = (RS.getString(10));
                    Ress[10] = (RS.getString(11));

                    model.addRow(Ress);
                }
                TableExisting.setModel(model);

                Conn.close();
                //LimpiarEx();
            } catch (SQLException ex) {
                System.out.println("Error al contactar reservaciones existentes: " + ex.getMessage());
            }

        }//fin busqueda * confirmacion

    }//GEN-LAST:event_BSearchResMouseClicked

    private void TableExistingMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableExistingMouseClicked

        int Fsel = TableExisting.getSelectedRow();

        String TCf = TableExisting.getValueAt(Fsel, 0).toString();
        String TID = TableExisting.getValueAt(Fsel, 1).toString();
        String TFL = TableExisting.getValueAt(Fsel, 2).toString();
        String TFS = TableExisting.getValueAt(Fsel, 3).toString();
        String THB = TableExisting.getValueAt(Fsel, 4).toString();
        String TVEH = TableExisting.getValueAt(Fsel, 5).toString();
        String TTT = TableExisting.getValueAt(Fsel, 6).toString();
        String TPAY = TableExisting.getValueAt(Fsel, 7).toString();
        String TEST = TableExisting.getValueAt(Fsel, 10).toString();

        //intento con NULL
        if (TableExisting.getValueAt(Fsel, 8) != null && TableExisting.getValueAt(Fsel, 9) != null) {
            //cuando esta lleno
            String TCRD = TableExisting.getValueAt(Fsel, 8).toString();
            String TEXP = TableExisting.getValueAt(Fsel, 9).toString();
            FieldTarjetaEx.setText(TCRD);
        }

        FieldConfEx.setText(TCf);
        FieldNombreEx.setText(TID);
        FieldLlegadaEx.setText(TFL);
        FieldSalidaEx.setText(TFS);
        FieldHabitacionEx.setText(THB);
        FieldTVeh.setText(TVEH);
        FieldTotalEx.setText(TTT);
        FieldPagoEx.setText(TPAY);


    }//GEN-LAST:event_TableExistingMouseClicked

    private void BNochesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BNochesActionPerformed
        // TODO add your handling code here:

        if (ChooserLlegada.getCalendar() == null && ChooserSalida.getCalendar() == null || ChooserLlegada.getCalendar() == null || ChooserSalida.getCalendar() == null) {
            JOptionPane.showMessageDialog(null, "Verificar veracidad de fechas.");

        } else {
            int dL = ChooserLlegada.getCalendar().get(Calendar.DAY_OF_MONTH);
            int mL = ChooserLlegada.getCalendar().get(Calendar.MONTH) + 1;
            int yL = ChooserLlegada.getCalendar().get(Calendar.YEAR);

            int dS = ChooserSalida.getCalendar().get(Calendar.DAY_OF_MONTH);
            int mS = ChooserSalida.getCalendar().get(Calendar.MONTH) + 1;
            int yS = ChooserSalida.getCalendar().get(Calendar.YEAR);

            System.out.println("Fechas Digitadas-------------------------");
            System.out.println("Fecha Llegada: " + dL + "/" + mL + "/" + yL);
            System.out.println("Fecha Salida: " + dS + "/" + mS + "/" + yS);

            String ncsx = Integer.toString(ncs);

            if (yL > yS) {
                JOptionPane.showMessageDialog(null, "Fecha no valida. Revisar año");
            } else if (mL > mS) {
                JOptionPane.showMessageDialog(null, "Fecha no valida. Revisar mes");
            } else if (yL > yS && mL > mS) {
                JOptionPane.showMessageDialog(null, "Fecha no valida. Revisar mes y año");
            } else if (yL == yS && mL == mS && dL > dS) {
                JOptionPane.showMessageDialog(null, "No puede llegar en el futuro y salir en el pasado.");
            } else if (yL == yS && mL == mS && dL != dS)//dias iguales
            {
                ncs = (dS - dL);
                BNoches.setText(ncsx);
                Ad = ncsx;

            } else if (yL == yS && mL != mS)//mes diferente
            {
                if (mL < mS) {
                    if (mS == mL + 1) {
                        if (mL == 1 && mS == 2 || mL == 3 && mS == 4 || mL == 5 && mS == 6 || mL == 7 && mS == 8 || mL == 8 && mS == 9 || mL == 10 && mS == 11)//Mes primero con 31
                        {
                            ncs = (31 - dL) + dS;
                            BNoches.setText(ncsx);
                            Ad = ncsx;

                        } else if (mL == 4 && mS == 5 || mL == 6 && mS == 7 || mL == 9 && mS == 10 || mL == 11 && mS == 12)//mes primero con 30
                        {
                            ncs = (30 - dL) + dS;
                            BNoches.setText(ncsx);
                        } else if (mL == 2 && mS == 3)//febrero, el especial.... todo hubiera sido mas facil con meses de 30 dias
                        {
                            ncs = (28 - dL) + dS;
                            BNoches.setText(ncsx);
                            Ad = ncsx;
                        }

                    } else {
                        JOptionPane.showMessageDialog(null, "Sobrepasa el limite establecido");
                        BNoches.setText("Obtener");
                    }

                } else {
                    JOptionPane.showMessageDialog(null, "Fecha no valida. El mes de entrada no puede ser mayor a la salida.");
                }
            }

            //Obtencion de fecha con digitos individuales
            //String para luego convertir en un arreglo de caracteres adquieiendo la fecha de su Tag
            String ddx = tHoyFecha.getText();

            //Metodo para recibir los datos que se han obtenido mediante un char
            char[] charA = ddx.toCharArray();
            String Dof1 = String.valueOf(charA[0]), Dof2 = String.valueOf(charA[1]);
            String Mof1 = String.valueOf(charA[3]), Mof2 = String.valueOf(charA[4]);
            String Yof1 = String.valueOf(charA[6]), Yof2 = String.valueOf(charA[7]), Yof3 = String.valueOf(charA[8]), Yof4 = String.valueOf(charA[9]);

            String SDay = Dof1 + Dof2, SMonth = Mof1 + Mof2, SYear = Yof1 + Yof2 + Yof3 + Yof4;

            int NDay = Integer.parseInt(SDay);
            int NMonth = Integer.parseInt(SMonth);
            int NYear = Integer.parseInt(SYear);
            System.out.println(NDay + "/" + NMonth + "/" + NYear);

            if (dL == NDay && mL == NMonth && yL == NYear) {
                //si el dia de llegada es el mismo de la fecha presente
                CheckEfectivo.setEnabled(true);
                CheckTarjeta.setEnabled(true);

            } else {
                CheckEfectivo.setEnabled(false);
                CheckEfectivo.setSelected(false);

            }

        }//fin 
    }//GEN-LAST:event_BNochesActionPerformed

    private void BRegResActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BRegResActionPerformed
        //Boton de Registrar reservacion nueva

        int dL = ChooserLlegada.getCalendar().get(Calendar.DAY_OF_MONTH);
        int mL = ChooserLlegada.getCalendar().get(Calendar.MONTH) + 1;
        int yL = ChooserLlegada.getCalendar().get(Calendar.YEAR);

        int dS = ChooserSalida.getCalendar().get(Calendar.DAY_OF_MONTH);
        int mS = ChooserSalida.getCalendar().get(Calendar.MONTH) + 1;
        int yS = ChooserSalida.getCalendar().get(Calendar.YEAR);

        String SendFL = String.valueOf(yL) + "/" + String.valueOf(mL) + "/" + String.valueOf(dL);

        String SendFS = String.valueOf(yS) + "/" + String.valueOf(mS) + "/" + String.valueOf(dS);

        if (CNoches.getText().equals("Noches") || CNoches.getText().equals("0"))//else de las validaciones no cumplidas
        {
            Notification not = new Notification(this, Notification.Type.INFO, Notification.Location.BOTTOM_CENTER, "Noches no validas");
            not.showNotification();
        } else if (CHabitacion.getText().equals("Habitacion")) {
            Notification not = new Notification(this, Notification.Type.INFO, Notification.Location.BOTTOM_CENTER, "Seleccione una habitacion");
            not.showNotification();
        } else if (FieldIDC.getText().isEmpty()) {
            Notification not = new Notification(this, Notification.Type.INFO, Notification.Location.BOTTOM_CENTER, "Seleccionar  un cliente");
            not.showNotification();
        } else if (CTPago.getText().equals("TPago")) {
            Notification not = new Notification(this, Notification.Type.INFO, Notification.Location.BOTTOM_CENTER, "Tiene que pagar maeistro");
            not.showNotification();
        } else {
            //si el checkefectivo Activado -> fecha actual
            if (CheckEfectivo.isEnabled()) {

                //try catch reservacion presente
                try {

                    Double Tott = Double.parseDouble(CTotal.getText());

                    ConectarBD();
                    SenSQL = "INSERT INTO reservacion (codreserva,identidadCliente,fechaIngreso,fechasalida,codHabitacion,rentaVehiculo,total,TPago,Tarjeta,Venc,estado) VALUES(?,?,?,?,?,?,?,?,?,?,?)";
                    PS = Conn.prepareStatement(SenSQL);
                    PS.setInt(1, 0);                                                            //codreserva
                    PS.setString(2, FieldIDC.getText());                        //identidadCliente
                    PS.setString(3, SendFL);                                         //fechaIngreso
                    PS.setString(4, SendFS);                                        //fechasalida
                    PS.setInt(5, Integer.parseInt(IDHB));                    //codHabitacion
                    PS.setInt(6, Integer.parseInt((CFieldIDT.getText())));      //rentaVehiculo
                    PS.setDouble(7, Tott);                                           //total
                    PS.setString(8, CTPago.getText());                    //TPago
                    PS.setString(9, FrmTarjeta.getText());               //Tarjeta
                    PS.setString(10, FrmVencimiento.getText());   //Venc
                    PS.setString(11, "Activa");                                   //estado

                    PS.execute();

                    Notification not = new Notification(this, Notification.Type.SUCCESS, Notification.Location.TOP_CENTER, "Reservacion registrada Correctamente");
                    not.showNotification();
                    Conn.close();

                    BRegRes.setEnabled(false);

                    //trycatch para recibir en pantalla confirmacion (RES ACTIVA)
                    int CRS = 0, CRSS = 0, Val = 0;

                    //try1
                    try {
                        ConectarBD();
                        SenSQL = "SELECT  * FROM reservacion";
                        PS = Conn.prepareStatement(SenSQL);
                        RS = PS.executeQuery();

                        while (RS.next()) {
                            CRS++;

                        }
                        Conn.close();

                    } catch (SQLException ex) {
                        System.out.println("Error al contactar numero de confirmacion " + ex.getMessage());
                    }

                    //try2
                    try {
                        ConectarBD();
                        SenSQL = "SELECT  * FROM reservacion";
                        PS = Conn.prepareStatement(SenSQL);
                        RS = PS.executeQuery();

                        while (RS.next()) {
                            CRSS++;

                            if (CRS == CRSS) {
                                Val = RS.getInt(1);

                            }

                        }
                        Conn.close();

                        JOptionPane.showMessageDialog(null, "Su numero de confirmacion es: " + Val, "Reservacion Creada", JOptionPane.INFORMATION_MESSAGE);
                        int fila = TableHabs.getRowCount();
                        for (int i = fila - 1; i >= 0; i--) {
                            model.removeRow(i);
                        }
                        LeerHab();
                    } catch (SQLException ex) {
                        System.out.println("Error al contactar numero de confirmacion " + ex.getMessage());
                    }

                    //fin trycatch recibir conf
                } catch (SQLException ex) {
                    Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "Falla al reservar" + ex);
                    not.showNotification();
                }

                //ID de habitacion en seccion de habilitada
                try {
                    ConectarBD();
                    SenSQL = "UPDATE habitacion SET alquiler='Ocupada' WHERE codHabitaciones= '" + Integer.parseInt(IDHB) + "'";
                    PS = Conn.prepareStatement(SenSQL);

                    PS.execute();
                    Conn.close();

                } catch (SQLException ex) {
                    Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "HBACTX " + ex);
                    not.showNotification();
                }

            } else {
                //try catch reservacion Futura
                try {
                    Double Tott = Double.parseDouble(CTotal.getText());

                    ConectarBD();
                    SenSQL = "INSERT INTO reservacion (codreserva,identidadCliente,fechaIngreso,fechasalida,codHabitacion,rentaVehiculo,total,TPago,Tarjeta,Venc,estado) VALUES(?,?,?,?,?,?,?,?,?,?,?)";
                    PS = Conn.prepareStatement(SenSQL);
                    PS.setInt(1, 0);//codreserva
                    PS.setString(2, FieldIDC.getText());//identidadCliente
                    PS.setString(3, SendFL);//fechaIngreso
                    PS.setString(4, SendFS);//fechasalida
                    PS.setInt(5, Integer.parseInt(IDHB));//codHabitacion
                    PS.setInt(6, Integer.parseInt((CFieldIDT.getText())));      //rentaVehiculo
                    PS.setDouble(7, Tott);//total
                    PS.setString(8, CTPago.getText());//TPago
                    PS.setString(9, FrmTarjeta.getText());//Tarjeta
                    PS.setString(10, FrmVencimiento.getText());//Venc
                    PS.setString(11, "Futura");//estado

                    PS.execute();
                    Notification not = new Notification(this, Notification.Type.SUCCESS, Notification.Location.TOP_CENTER, "Reservacion registrada Correctamente");
                    not.showNotification();
                    Conn.close();

                    BRegRes.setEnabled(false);
                    LmReg();
                    LeerHab();

                    //trycatch para recibir en pantalla confirmacion (RES Futura)
                    int CRS = 0, CRSS = 0, Val = 0;

                    //try1
                    try {
                        ConectarBD();
                        SenSQL = "SELECT  * FROM reservacion";
                        PS = Conn.prepareStatement(SenSQL);
                        RS = PS.executeQuery();

                        while (RS.next()) {
                            CRS++;

                        }
                        Conn.close();

                    } catch (SQLException ex) {
                        System.out.println("Error al contactar numero de confirmacion " + ex.getMessage());
                    }

                    //try2
                    try {
                        ConectarBD();
                        SenSQL = "SELECT  * FROM reservacion";
                        PS = Conn.prepareStatement(SenSQL);
                        RS = PS.executeQuery();

                        while (RS.next()) {
                            CRSS++;

                            if (CRS == CRSS) {
                                Val = RS.getInt(1);

                            }

                        }
                        Conn.close();

                        JOptionPane.showMessageDialog(null, "Su numero de confirmacion es: " + Val, "Reservacion Creada", JOptionPane.INFORMATION_MESSAGE);

                    } catch (SQLException ex) {
                        System.out.println("Error al contactar numero de confirmacion " + ex.getMessage());
                    }

                    //fin trycatch recibir conf
                } catch (SQLException ex) {
                    Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "F.X:" + ex);
                    not.showNotification();
                }
            }

            // LmReg();
        }//fin de validacionse 


    }//GEN-LAST:event_BRegResActionPerformed

    private void BDelResActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BDelResActionPerformed
        // Funcion para redefinir la opcion de cancelar una reservacion

        if (FieldConfEx.getText().isEmpty()) {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "Seleccione una reservacion");
            not.showNotification();
        } else {

            MessageDialog obj = new MessageDialog(this);
            obj.showMessage("Cancelar reservacion", "Esta funcion es irreversible, confirmar primero.");

            if (obj.getMessageType() == MessageDialog.MessageType.OK) {

                int ConfH = Integer.parseInt(FieldHabitacionEx.getText());
                int ConfC = Integer.parseInt(FieldConfEx.getText());

//update a Cancelada
                try {
                    ConectarBD();
                    SenSQL = "UPDATE reservacion SET estado='Cancelada' WHERE codreserva='" + ConfC + "'";
                    PS = Conn.prepareStatement(SenSQL);

                    PS.execute();
                    Conn.close();
                    Notification not = new Notification(this, Notification.Type.INFO, Notification.Location.TOP_CENTER, "Reservacion cancelada con exito");
                    not.showNotification();

                    JOptionPane.showMessageDialog(null, "Su numero de cancelacion es: " + FieldConfEx.getText(), "Cancelacion", JOptionPane.INFORMATION_MESSAGE);

                    limpiarTEX();
                } catch (SQLException ex) {
                    Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "Err: " + ex);
                    not.showNotification();
                }
//FIN UPDATE A CANCELADO RES

                //RESTABLECER cambios luego de cancelar RES
                Object auto = null, viaje = null, chofer = null;

                int codigo = 0;

                try {
                    ConectarBD();
                    SenSQL = "SELECT * FROM tipoalquilervihiculo WHERE idTipo ='" + Integer.parseInt(FieldTVeh.getText()) + "'";
                    PS = Conn.prepareStatement(SenSQL);
                    RS = PS.executeQuery();

                    while (RS.next()) {
                        auto = RS.getString(3);
                        viaje = RS.getString(4);
                        chofer = RS.getString(5);

                    }

                    Conn.close();

                } catch (SQLException ex) {
                    System.out.println("Error al contactar registro de habitaciones: " + ex.getMessage());
                }

                if (auto != null) {
//*Servicio de AUTO Cuando es distinto a nulo
                    codigo = Integer.parseInt(auto.toString());
                    int id = 0;

                    try {
                        ConectarBD();
                        SenSQL = "SELECT * FROM alquilerauto WHERE idalquiler = '" + codigo + "'";
                        PS = Conn.prepareStatement(SenSQL);
                        RS = PS.executeQuery();

                        while (RS.next()) {
                            id = RS.getInt(4);

                        }

                        Conn.close();

                    } catch (SQLException ex) {
                        System.out.println("Error al contactar precio de habitacion: " + ex.getMessage());
                    }

                    try {
                        ConectarBD();
                        SenSQL = "UPDATE alquilerauto SET estado='Cancelado' WHERE idalquiler='" + codigo + "'";
                        PS = Conn.prepareStatement(SenSQL);

                        PS.execute();
                        Conn.close();

                    } catch (SQLException ex) {
                        Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "Err: " + ex);
                        not.showNotification();
                    }

                    try {
                        ConectarBD();
                        SenSQL = "UPDATE automovil SET alquiler='Disponible' WHERE idAutomovil= '" + id + "'";
                        PS = Conn.prepareStatement(SenSQL);

                        PS.execute();
                        Conn.close();

                    } catch (SQLException ex) {
                        Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "Err: " + ex);
                        not.showNotification();
                    }

                } else if (viaje != null) {
//*Servicio de VIAJE Cuando es distinto a nulo
                    codigo = Integer.parseInt(viaje.toString());
                    int id = 0;

                    //try1
                    try {
                        ConectarBD();
                        SenSQL = "SELECT * FROM viaje_aeropuerto WHERE idviaje = '" + codigo + "'";
                        PS = Conn.prepareStatement(SenSQL);
                        RS = PS.executeQuery();

                        while (RS.next()) {
                            id = RS.getInt(1);

                        }

                        Conn.close();

                    } catch (SQLException ex) {
                        System.out.println("Error al contactar precio de habitacion: " + ex.getMessage());
                    }
//try2
                    try {
                        ConectarBD();
                        SenSQL = "UPDATE viaje_aeropuerto SET estado='Cancelado' WHERE idviaje='" + codigo + "'";
                        PS = Conn.prepareStatement(SenSQL);

                        PS.execute();
                        Conn.close();

                    } catch (SQLException ex) {
                        Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "Err: " + ex);
                        not.showNotification();
                    }
//try3  

                } else if (chofer != null) {
//*Servicio de CHOFER Cuando es distinto a nulo
                    codigo = Integer.parseInt(chofer.toString());
                    int id = 0;

//try1
                    try {
                        ConectarBD();
                        SenSQL = "SELECT * FROM alquilerchofer WHERE idalquiler = '" + codigo + "'";
                        PS = Conn.prepareStatement(SenSQL);
                        RS = PS.executeQuery();

                        while (RS.next()) {
                            id = RS.getInt(1);

                        }

                        Conn.close();

                    } catch (SQLException ex) {
                        System.out.println("Error al contactar precio de habitacion: " + ex.getMessage());
                    }
//try2
                    try {
                        ConectarBD();
                        SenSQL = "UPDATE alquilerchofer SET estado='Cancelado' WHERE idalquiler='" + codigo + "'";
                        PS = Conn.prepareStatement(SenSQL);

                        PS.execute();
                        Conn.close();

                    } catch (SQLException ex) {
                        Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "Err: " + ex);
                        not.showNotification();
                    }

                }
                //FIN RESTABLECER CAMBIOS 

                System.out.println("Viaje: " + viaje);
                System.out.println("Auto: " + auto);
                System.out.println("chofer: " + chofer);
                System.out.println("CCC" + codigo);
                //trycatch para devolver habitacion disponible            
                try {
                    ConectarBD();
                    SenSQL = "UPDATE habitacion SET alquiler='Disponible' WHERE codHabitaciones='" + ConfH + "'";
                    PS = Conn.prepareStatement(SenSQL);

                    PS.execute();
                    Conn.close();

                    LimpiarEx();

                } catch (SQLException ex) {
                    Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "Err: " + ex);
                    not.showNotification();
                }

            } else {
                System.out.println("Opcion Cancelar ejecucion. (Cancelar Reservacion)");
            }

        }//fin else de espacio vacio

    }//GEN-LAST:event_BDelResActionPerformed

    private void BLimpiarExMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BLimpiarExMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_BLimpiarExMouseClicked

    private void BLimpiarExActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BLimpiarExActionPerformed
        TableExisting.clearSelection();
        LimpiarEx();
        limpiarTEX();


    }//GEN-LAST:event_BLimpiarExActionPerformed

    private void ComboTransActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboTransActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboTransActionPerformed

    private void BNochesModActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BNochesModActionPerformed

        if (ChooserEditL.getCalendar() == null && ChooserEditS.getCalendar() == null || ChooserEditL.getCalendar() == null || ChooserEditS.getCalendar() == null) {
            JOptionPane.showMessageDialog(null, "Verificar veracidad de fechas.");

        } else {

            int dL = ChooserEditL.getCalendar().get(Calendar.DAY_OF_MONTH);
            int mL = ChooserEditL.getCalendar().get(Calendar.MONTH) + 1;
            int yL = ChooserEditL.getCalendar().get(Calendar.YEAR);

            int dS = ChooserEditS.getCalendar().get(Calendar.DAY_OF_MONTH);
            int mS = ChooserEditS.getCalendar().get(Calendar.MONTH) + 1;
            int yS = ChooserEditS.getCalendar().get(Calendar.YEAR);
            System.out.print("Fechas Edit\t" + "Fecha Llegada: " + dL + "/" + mL + "/" + yL + "\t" + "Fecha Salida: " + dS + "/" + mS + "/" + yS + "\n");

            String ncsxM = Integer.toString(ncsM);

            if (yL > yS) {
                JOptionPane.showMessageDialog(null, "Fecha no valida. Revisar año");
            } else if (mL > mS) {
                JOptionPane.showMessageDialog(null, "Fecha no valida. Revisar mes");
            } else if (yL > yS && mL > mS) {
                JOptionPane.showMessageDialog(null, "Fecha no valida. Revisar mes y año");
            } else if (yL == yS && mL == mS && dL > dS) {
                JOptionPane.showMessageDialog(null, "No puede llegar en el futuro y salir en el pasado.");
            } else if (yL == yS && mL == mS && dL != dS)//dias iguales
            {
                ncsM = (dS - dL);
                BNochesMod.setText(ncsxM);
                //Ad = ncsxM;

            } else if (yL == yS && mL != mS)//mes diferente
            {
                if (mL < mS) {
                    if (mS == mL + 1) {
                        if (mL == 1 && mS == 2 || mL == 3 && mS == 4 || mL == 5 && mS == 6 || mL == 7 && mS == 8 || mL == 8 && mS == 9 || mL == 10 && mS == 11)//Mes primero con 31
                        {
                            ncsM = (31 - dL) + dS;
                            BNochesMod.setText(ncsxM);
                            //Ad = ncsxM;

                        } else if (mL == 4 && mS == 5 || mL == 6 && mS == 7 || mL == 9 && mS == 10 || mL == 11 && mS == 12)//mes primero con 30
                        {
                            ncsM = (30 - dL) + dS;
                            BNoches.setText(ncsxM);
                        } else if (mL == 2 && mS == 3)//febrero, el especial.... todo hubiera sido mas facil con meses de 30 dias
                        {
                            ncsM = (28 - dL) + dS;
                            BNochesMod.setText(ncsxM);
                            //Ad = ncsxM;
                        }

                    } else {
                        JOptionPane.showMessageDialog(null, "Sobrepasa el limite establecido");
                        BNochesMod.setText("Obtener");
                    }

                } else {
                    JOptionPane.showMessageDialog(null, "Fecha no valida. El mes de entrada no puede ser mayor a la salida.");
                }
            }

        }

    }//GEN-LAST:event_BNochesModActionPerformed

    private void BListModActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BListModActionPerformed
        //confimar que en efecto todo es valido
        tNMod.setText("Noche L.");

        if (ComboMod.getSelectedIndex() != 0) {
            String Div = ComboMod.getSelectedItem().toString();
            int Nid;

            char Dix[] = Div.toCharArray();

            if (Dix[1] == 'E' || Dix[1] == 'P' || Dix[1] == 'S' || Dix[1] == 'D') {
                String V1 = String.valueOf(Dix[0]);
                Nid = Integer.parseInt(V1);
            } else {
                String V1 = String.valueOf(Dix[0]);
                String V2 = String.valueOf(Dix[1]);
                String Vid = V1 + V2;
                Nid = Integer.parseInt(Vid);
            }

            try {
                ConectarBD();
                SenSQL = "SELECT * FROM habitacion WHERE codHabitaciones LIKE '" + Nid + "'";
                PS = Conn.prepareStatement(SenSQL);
                RS = PS.executeQuery();

                while (RS.next()) {
                    TotMod = RS.getDouble(6);
                    tHabNox.setText(String.valueOf(RS.getDouble(6)));

                }

                Conn.close();

            } catch (SQLException ex) {
                System.out.println("Error al contactar precio de habitacion: " + ex.getMessage());
            }

            Double N = Double.parseDouble(BNochesMod.getText());
            Double TotModSel = TotMod * N;

            String SetTMod = String.valueOf(TotModSel);

            FieldTotalMod.setText(SetTMod);

        } else if (ComboMod.getSelectedIndex() == 0 || ChooserEditL.getCalendar() == null || ChooserEditS.getCalendar() == null || ChooserEditL.getCalendar() == null && ChooserEditS.getCalendar() == null) {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "Rellenar espacios vacios");
            not.showNotification();

        }

    }//GEN-LAST:event_BListModActionPerformed

    private void BModResActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BModResActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BModResActionPerformed

    private void BGuardar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BGuardar1ActionPerformed

        int dL = ChooserEditL.getCalendar().get(Calendar.DAY_OF_MONTH), mL = ChooserEditL.getCalendar().get(Calendar.MONTH) + 1, yL = ChooserEditL.getCalendar().get(Calendar.YEAR);
        int dS = ChooserEditS.getCalendar().get(Calendar.DAY_OF_MONTH), mS = ChooserEditS.getCalendar().get(Calendar.MONTH) + 1, yS = ChooserEditS.getCalendar().get(Calendar.YEAR);

        String SendModL = String.valueOf(yL) + "/" + String.valueOf(mL) + "/" + String.valueOf(dL);
        String SendModS = String.valueOf(yS) + "/" + String.valueOf(mS) + "/" + String.valueOf(dS);

        String ddx = tHoyFecha.getText();
        char[] charA = ddx.toCharArray();
        String Dof1 = String.valueOf(charA[0]), Dof2 = String.valueOf(charA[1]);
        String Mof1 = String.valueOf(charA[3]), Mof2 = String.valueOf(charA[4]);
        String Yof1 = String.valueOf(charA[6]), Yof2 = String.valueOf(charA[7]), Yof3 = String.valueOf(charA[8]), Yof4 = String.valueOf(charA[9]);
        String SDay = Dof1 + Dof2, SMonth = Mof1 + Mof2, SYear = Yof1 + Yof2 + Yof3 + Yof4;
        int NDay = Integer.parseInt(SDay), NMonth = Integer.parseInt(SMonth), NYear = Integer.parseInt(SYear);

        if (ComboMod.getSelectedIndex() != 0) {
            String Div = ComboMod.getSelectedItem().toString();

            int Nid;

            char Dix[] = Div.toCharArray();

            if (Dix[1] == 'E' || Dix[1] == 'P' || Dix[1] == 'S' || Dix[1] == 'D') {
                String V1 = String.valueOf(Dix[0]);
                Nid = Integer.parseInt(V1);
            } else {
                String V1 = String.valueOf(Dix[0]);
                String V2 = String.valueOf(Dix[1]);
                String Vid = V1 + V2;
                Nid = Integer.parseInt(Vid);
            }

            //Modify to Active reservacion   adjunto con alterecion de Habitacion al ser activa
            if (NDay == dL && NMonth == mL && NYear == yL) {
                try {
                    ConectarBD();
                    SenSQL = "UPDATE reservacion SET  fechaIngreso=?,fechasalida=?,total=?,estado=? WHERE codreserva='" + Integer.parseInt(FieldConfEx.getText()) + "'";
                    PS = Conn.prepareStatement(SenSQL);

                    PS.setString(1, SendModL);
                    PS.setString(2, SendModS);
                    PS.setDouble(3, Double.parseDouble(FieldTotalMod.getText()));
                    PS.setString(4, "Activa");

                    PS.execute();
                    Conn.close();
                    Notification not = new Notification(this, Notification.Type.INFO, Notification.Location.TOP_CENTER, "Reservacion modificada con exito");
                    not.showNotification();

                } catch (SQLException ex) {
                    Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "UPDRS " + ex);
                    System.out.println("Err: " + ex);
                    not.showNotification();
                }

                //try para actualizar estado de habitacion a ocupado ya que es reservacion en el mismo dia
                try {
                    ConectarBD();
                    SenSQL = "UPDATE habitacion SET  alquiler='Ocupada' WHERE codHabitaciones='" + Nid + "'";
                    PS = Conn.prepareStatement(SenSQL);
                    PS.execute();
                    Conn.close();

                } catch (SQLException ex) {
                    Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "E. HBUPD " + ex);
                    not.showNotification();
                }

            } else {//Modify to Active reservacion adjunto con alterecion de Habitacion al ser Futura
                try {
                    ConectarBD();
                    SenSQL = "UPDATE reservacion SET  fechaIngreso=?,fechasalida=?,total=?,estado=? WHERE codreserva='" + Integer.parseInt(FieldConfEx.getText()) + "'";
                    PS = Conn.prepareStatement(SenSQL);

                    PS.setString(1, SendModL);
                    PS.setString(2, SendModS);
                    PS.setDouble(3, Double.parseDouble(FieldTotalMod.getText()));
                    PS.setString(4, "Futura");

                    PS.execute();
                    Conn.close();
                    Notification not = new Notification(this, Notification.Type.INFO, Notification.Location.TOP_CENTER, "Reservacion modificada con exito");
                    not.showNotification();

                } catch (SQLException ex) {
                    Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "Error" + ex);
                    not.showNotification();
                    System.out.println("Err: " + ex);
                }

            }

        } else//combo mod cuartos iguala seleccionar
        {
            JOptionPane.showMessageDialog(null, "Seleccione una habitacion");
        }

        limpiarTEX();
        LimpiarEx();
    }//GEN-LAST:event_BGuardar1ActionPerformed

    private void BLimpiarTodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BLimpiarTodoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BLimpiarTodoActionPerformed

    public void LmReg() {

        int fila = TableHabs.getRowCount();
        for (int i = fila - 1; i >= 0; i--) {
            model.removeRow(i);
        }

        FieldApellido.setText(null);
        FieldDireccion.setText(null);
        FieldTLF.setText(null);
        FieldNombre.setText(null);
        CheckTarjeta.setSelected(false);
        FrmTarjeta.setText(null);
        CheckDiscap.setSelected(false);
        FieldEdad.setText(null);
        FrmVencimiento.setText(null);
        ComboTarifa.setSelectedIndex(0);
        FieldIDC.setText(null);
        BNoches.setText("Obtener");
        CheckEfectivo.setSelected(false);
        AreaPoliza.setText(null);
        ComboTrans.setSelectedIndex(0);
        CFieldTipoT.setText("TipoTransporte");
        CFieldCosto.setText("Costo");
        CFieldIDT.setText("1");
        CHabitacion.setText("Habitacion");
        CTotal.setText("Total");
        CTPago.setText("TPago");
        CLlegada.setText("Llegada");
        CSalida.setText("Salida");
        CNoches.setText("Noches");
        BRegRes.setEnabled(false);

    }

    public void LeerHab() {
        try {
            ConectarBD();
            SenSQL = "SELECT * FROM habitacion WHERE  alquiler LIKE 'Disponible' AND estado LIKE 'Activa'";
            PS = Conn.prepareStatement(SenSQL);
            RS = PS.executeQuery();
            Object Habs[] = new Object[5];

            model = (DefaultTableModel) TableHabs.getModel();

            while (RS.next()) {
                Habs[0] = (RS.getInt(1));  //id
                Habs[1] = (RS.getString(2));   //habitacion 
                Habs[2] = (RS.getInt(5));    //capacidad
                Habs[3] = (RS.getDouble(6));  //precio

                model.addRow(Habs);
            }
            TableHabs.setModel(model);

            Conn.close();

        } catch (SQLException ex) {
            System.out.println("Error al contactar registro de habitaciones: " + ex.getMessage());
        }

    }

    public void limpiar() {
        FieldApellido.setText(null);
        FieldDireccion.setText(null);
        FieldTLF.setText(null);
        FieldNombre.setText(null);
        CheckTarjeta.setEnabled(true);
        CheckEfectivo.setEnabled(true);
        CheckTarjeta.setSelected(false);
        FrmTarjeta.setText(null);
        FrmTarjeta.setEditable(true);
        CheckDiscap.setSelected(false);
        FieldEdad.setText(null);
        FrmVencimiento.setEditable(true);
        FrmVencimiento.setText(null);
        ComboTarifa.setSelectedIndex(0);
        FieldIDC.setText(null);
        BNoches.setText("Obtener");
        CheckEfectivo.setSelected(false);
        AreaPoliza.setText(null);
        ComboTrans.setSelectedIndex(0);
        CFieldTipoT.setText("TipoTransporte");
        CFieldCosto.setText("Costo");
        CFieldIDT.setText("1");
        CHabitacion.setText("Habitacion");
        CTotal.setText("Total");
        CTPago.setText("TPago");
        CLlegada.setText("Llegada");
        CSalida.setText("Salida");
        CNoches.setText("Noches");
        BRegRes.setEnabled(false);
        ChooserLlegada.setDate(null);
        ChooserSalida.setDate(null);
        TableHabs.clearSelection();

    }
    private void BLMPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BLMPActionPerformed

        FieldApellido.setText(null);
        FieldDireccion.setText(null);
        FieldTLF.setText(null);
        FieldNombre.setText(null);
        CheckTarjeta.setSelected(false);
        FrmTarjeta.setText(null);
        FrmTarjeta.setEditable(true);
        CheckDiscap.setSelected(false);
        FieldEdad.setText(null);
        FrmVencimiento.setEditable(true);
        FrmVencimiento.setText(null);
        ComboTarifa.setSelectedIndex(0);
        FieldIDC.setText(null);
        BNoches.setText("Obtener");
        CheckEfectivo.setSelected(false);
        AreaPoliza.setText(null);
        ComboTrans.setSelectedIndex(0);
        CFieldTipoT.setText("TipoTransporte");
        CFieldCosto.setText("Costo");
        CFieldIDT.setText("1");
        CHabitacion.setText("Habitacion");
        CTotal.setText("Total");
        CTPago.setText("TPago");
        CLlegada.setText("Llegada");
        CSalida.setText("Salida");
        CNoches.setText("Noches");
        BRegRes.setEnabled(false);
        ChooserLlegada.setDate(null);
        ChooserSalida.setDate(null);
        TableHabs.clearSelection();

    }//GEN-LAST:event_BLMPActionPerformed

    private void BCanceladasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BCanceladasActionPerformed

        Registros_Reservaciones.reservacionesCanceladas CNC = new Registros_Reservaciones.reservacionesCanceladas();
        CNC.setVisible(true);

    }//GEN-LAST:event_BCanceladasActionPerformed

    private void BActivasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BActivasActionPerformed

        Registros_Reservaciones.reservacionesActivas ACT = new Registros_Reservaciones.reservacionesActivas();
        ACT.setVisible(true);

    }//GEN-LAST:event_BActivasActionPerformed

    public void LimpiarEx() {

        FieldConfEx.setText(null);
        FieldPagoEx.setText(null);
        FieldNombreEx.setText(null);
        FieldTVeh.setText(null);
        FieldLlegadaEx.setText(null);
        FieldTarjetaEx.setText(null);
        FieldSalidaEx.setText(null);
        FieldTotalEx.setText(null);
        FieldHabitacionEx.setText(null);
        FieldBusq.setText(null);

    }

    public void limpiarTEX() {

        int fila = TableExisting.getRowCount();
        for (int i = fila - 1; i >= 0; i--) {
            model.removeRow(i);
        }
    }

    public static void main(String args[]) {
        /* Set the Metal look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Windows  (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Reservaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Reservaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Reservaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Reservaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Reservaciones().setVisible(true);

            }
        });

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea AreaPoliza;
    private javax.swing.JButton BActivas;
    private javax.swing.JButton BCancEdit;
    private javax.swing.JButton BCanceladas;
    private javax.swing.JButton BDelRes;
    private javax.swing.JButton BDetalles;
    private javax.swing.JButton BFuturas;
    private javax.swing.JButton BGuardar1;
    private javax.swing.JButton BLMP;
    private javax.swing.JButton BLimpiarEx;
    private javax.swing.JButton BLimpiarTodo;
    private javax.swing.JButton BListMod;
    private javax.swing.JButton BListoCheck;
    private javax.swing.JButton BModRes;
    private javax.swing.JButton BNoches;
    private javax.swing.JButton BNochesMod;
    private javax.swing.JButton BRegRes;
    private javax.swing.JButton BSearchClient;
    private javax.swing.JButton BSearchRes;
    private javax.swing.JButton BTransport;
    public static javax.swing.JTextField CFieldCosto;
    public static javax.swing.JTextField CFieldIDT;
    public static javax.swing.JTextField CFieldTipoT;
    private javax.swing.JTextField CHabitacion;
    private javax.swing.JTextField CLlegada;
    private javax.swing.JTextField CNoches;
    private javax.swing.JTextField CSalida;
    private javax.swing.JTextField CTPago;
    private javax.swing.JTextField CTotal;
    public static javax.swing.JCheckBox CheckDiscap;
    private javax.swing.JCheckBox CheckEfectivo;
    private javax.swing.JCheckBox CheckTarjeta;
    private com.toedter.calendar.JDateChooser ChooserEditL;
    private com.toedter.calendar.JDateChooser ChooserEditS;
    private com.toedter.calendar.JDateChooser ChooserLlegada;
    private com.toedter.calendar.JDateChooser ChooserSalida;
    private javax.swing.JComboBox<String> ComboBusq;
    private javax.swing.JComboBox<String> ComboMod;
    private javax.swing.JComboBox<String> ComboTarifa;
    private javax.swing.JComboBox<String> ComboTrans;
    private javax.swing.JButton ExitSys;
    public static javax.swing.JTextField FieldApellido;
    private javax.swing.JTextField FieldBusq;
    private javax.swing.JTextField FieldConfEx;
    public static javax.swing.JTextField FieldDireccion;
    public static javax.swing.JTextField FieldEdad;
    private javax.swing.JTextField FieldHabitacionEx;
    public static javax.swing.JTextField FieldIDC;
    private javax.swing.JTextField FieldLlegadaEx;
    public static javax.swing.JTextField FieldNombre;
    private javax.swing.JTextField FieldNombreEx;
    private javax.swing.JTextField FieldPagoEx;
    private javax.swing.JTextField FieldSalidaEx;
    public static javax.swing.JTextField FieldTLF;
    private javax.swing.JTextField FieldTVeh;
    private javax.swing.JTextField FieldTarjetaEx;
    private javax.swing.JTextField FieldTotalEx;
    private javax.swing.JTextField FieldTotalMod;
    private javax.swing.JFormattedTextField FrmTarjeta;
    private javax.swing.JFormattedTextField FrmVencimiento;
    private javax.swing.JButton MinimizeSys;
    private java.awt.Panel PCrear;
    private java.awt.Panel PMod;
    private java.awt.Panel PUpper;
    private javax.swing.JScrollPane ScrollExistRes;
    private javax.swing.JScrollPane ScrollHabs;
    private javax.swing.JScrollPane ScrollPoliza;
    private javax.swing.JTabbedPane TabbedP;
    private javax.swing.JTable TableExisting;
    private javax.swing.JTable TableHabs;
    private javax.swing.JSeparator s1;
    private javax.swing.JSeparator s2;
    private javax.swing.JSeparator s3;
    private javax.swing.JSeparator s4;
    private javax.swing.JSeparator sMod1;
    private javax.swing.JSeparator sMod2;
    private javax.swing.JSeparator sMod4;
    private javax.swing.JLabel tApellido;
    private javax.swing.JLabel tBordeEdit;
    private javax.swing.JLabel tBordeMetodo1;
    private javax.swing.JLabel tBordeMetodo2;
    private javax.swing.JLabel tCExtra;
    private javax.swing.JLabel tCFechas;
    private javax.swing.JLabel tCPago;
    private javax.swing.JLabel tConfEx;
    private javax.swing.JLabel tConfRes;
    private javax.swing.JLabel tDireccion;
    private javax.swing.JLabel tDiscapacidad;
    private javax.swing.JLabel tEdad;
    private javax.swing.JLabel tFecha;
    private javax.swing.JLabel tFechaLlegaEx;
    private javax.swing.JLabel tFechaSaliEx;
    private javax.swing.JLabel tHabMod;
    private javax.swing.JLabel tHabNox;
    private javax.swing.JLabel tHabitacion;
    private javax.swing.JLabel tHabitacionEx;
    private javax.swing.JLabel tHoy;
    private javax.swing.JLabel tHoyFecha;
    private javax.swing.JLabel tIDCliente;
    private javax.swing.JLabel tIcHotel;
    private javax.swing.JLabel tIdConf;
    private javax.swing.JLabel tImp;
    private javax.swing.JLabel tImpuesto;
    private javax.swing.JLabel tInfoCliente;
    private javax.swing.JLabel tLlegada;
    private javax.swing.JLabel tLlegadaEdit;
    private javax.swing.JLabel tLpsMod;
    private javax.swing.JLabel tNMod;
    private javax.swing.JLabel tNeto;
    private javax.swing.JLabel tNoches;
    private javax.swing.JLabel tNombre;
    private javax.swing.JLabel tNombreEx;
    private javax.swing.JLabel tPNeto;
    private javax.swing.JLabel tPago;
    private javax.swing.JLabel tPagoEx;
    private javax.swing.JLabel tPagoEx1;
    private javax.swing.JLabel tPoliza;
    private javax.swing.JLabel tResultados;
    private javax.swing.JLabel tSalida;
    private javax.swing.JLabel tSalidaEdit;
    private javax.swing.JLabel tSoftwHotel;
    private javax.swing.JLabel tTarifaEsp;
    private javax.swing.JLabel tTarjeta;
    private javax.swing.JLabel tTarjetaEx;
    private javax.swing.JLabel tTelefono;
    private javax.swing.JLabel tTot;
    private javax.swing.JLabel tTotal;
    private javax.swing.JLabel tTotalEx;
    private javax.swing.JLabel tTotalMod;
    private javax.swing.JLabel tVencimiento;
    // End of variables declaration//GEN-END:variables
}
