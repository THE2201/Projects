package Registros_Reservaciones;

import Registros_Reservaciones.Reservaciones;
import Registros_Reservaciones.Reservaciones;
import Conexion.conexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import Componentes.Notification;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author jairo
 */
public class rentaViajes extends javax.swing.JFrame {

    public static int NUM = 0;
    public static String idAerpuerto;
    public static String hora;
    public static String idCliente;
    public static String apellido;
    public static String Nombre;
    public static String telefono;
    public static String nombreA;
    public static String DireccionAerolinea;
    public static String costo;

    String usuario;
    Connection con = null;
    conexionBD conecta;
    String senteciaSQL;
    PreparedStatement ps = null;
    double totalDis = 0;
    String senteciaSQL2;
    PreparedStatement ps2 = null;
    String senteciaSQL3;
    PreparedStatement ps3 = null;
    ResultSet rs2 = null;
    ResultSet rs3 = null;    
    String[][] datosViajesB;
    ResultSet rs = null;
    DefaultTableModel modelo;
    Object datosAeropuerto[] = new Object[8];

      int Cnt2=0;
       int Cnt=0;
    
    public rentaViajes() {
        initComponents();
        idViaje.requestFocus();
        this.setLocationRelativeTo(null);
       
      
        
        conectarBD();
        senteciaSQL = "SELECT * FROM viaje_aeropuerto";
        try {
            ps = con.prepareStatement(senteciaSQL);
            rs = ps.executeQuery();

            while (rs.next()) {
                Cnt ++;
             
            }
            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
        }
      
        idViaje.setText(String.valueOf(Cnt+1));
        
 
        
        conectarBD();
        senteciaSQL = "SELECT * FROM tipoalquilervihiculo";
        try {
            ps = con.prepareStatement(senteciaSQL);
            rs = ps.executeQuery();

            while (rs.next()) {
                Cnt2 ++;
             
            }
            
            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
        }       
     
    }

    public void conectarBD() {
        conecta = new conexionBD("proyecto_final");
        con = conecta.getConexion();
    }

    public void crearRegistroA() {
        try {

            conectarBD();
            senteciaSQL = "INSERT INTO viaje_aeropuerto (idviaje,hora,idCliente,nombreAerolinea,direccion,costo,estado) VALUES(?,?,?,?,?,?,?)";
            ps = con.prepareStatement(senteciaSQL);
            ps.setInt(1, 0);
            ps.setString(2, txtHora.getText());
            ps.setString(3, txtCodigo.getText());
            ps.setString(4, txtAerolinea.getText());
            ps.setString(5, txtDireccion.getText());
            ps.setString(6, txtCosto.getText());
            ps.setString(7, "Activo");
            ps.execute();
            con.close();
            Notification not = new Notification(this, Notification.Type.SUCCESS, Notification.Location.TOP_CENTER, "Datos de usuario Guardados Correctamente");
            not.showNotification();
        } catch (SQLException ex) {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No Se pudo Crear el usuario " + ex);
            not.showNotification();
            System.out.println("prueba" + ex);
        }

        int id = 0;
        conectarBD();
        senteciaSQL3 = "SELECT * FROM viaje_aeropuerto WHERE estado LIKE 'Activo' AND idCliente LIKE '" + txtCodigo.getText() + "'";
        try {
            ps3 = con.prepareStatement(senteciaSQL3);
            rs3 = ps3.executeQuery();

            while (rs3.next()) {
                id = rs3.getInt(1);
            }

            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
        }
        try {

            conectarBD();
            senteciaSQL2 = "INSERT INTO tipoalquilervihiculo (idTipo,tipo,idAlquilerAuto,idRentaVehivulo,idAlquilerChofer ) VALUES(?,?,?,?,?)";

            ps2 = con.prepareStatement(senteciaSQL2);
            ps2.setInt(1, 0);
            ps2.setString(2, "Viaje Aeropuerto");
            ps2.setString(3, null);
            ps2.setInt(4, id);
            ps2.setString(5, null);
            ps2.execute();
            con.close();
        } catch (SQLException ex) {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No Se pudo Crear el usuario " + ex);
            not.showNotification();
            System.out.println("not = " + ex);
        }

    }

    public void llenarCliente() {
        conectarBD();
        senteciaSQL = "SELECT * FROM cliente WHERE identidad LIKE '" + idCliente + "'";
        System.out.println("this = " + idCliente);
        try {
            ps = con.prepareStatement(senteciaSQL);
            rs = ps.executeQuery();
            while (rs.next()) {
                System.out.println("RESULTADO = ");
                txtNombre.setText(rs.getString(3));
                txtApellido.setText(rs.getString(4));
                if (rs.getBoolean(7) == true) {
                    txtDiscapacidad.setText("SI");
                } else {
                    txtDiscapacidad.setText("NO");
                }
            }
            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error no se pudo leer la basde de datos Leer " + ex.getMessage());
        }
    }

    public void acutualizViaje() {
        try {
            conectarBD();
            senteciaSQL = "UPDATE viaje_aeropuerto SET hora=?,idCliente=?,nombreAerolinea=?,direccion=?,costo=? WHERE idviaje=?";
            ps = con.prepareStatement(senteciaSQL);
            ps.setString(1, txtHora.getText());
            ps.setString(2, txtCodigo.getText());
            ps.setString(3, txtAerolinea.getText());
            ps.setString(4, txtDireccion.getText());
            ps.setString(5, txtCosto.getText());
            ps.setInt(6, Integer.parseInt(idViaje.getText()));
            ps.execute();
            con.close();
            System.out.println("id = " + idViaje.getText());

            Notification not = new Notification(this, Notification.Type.SUCCESS, Notification.Location.TOP_CENTER, "Datos de usuario Guardados Correctamente");
            not.showNotification();
        } catch (SQLException ex) {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "No se pudo actualizar el dato " + ex);
            not.showNotification();
            System.out.println("imp = " + ex);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtApellido = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtCodigo = new javax.swing.JFormattedTextField();
        txtCosto = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txtAerolinea = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txtDireccion = new javax.swing.JTextField();
        idViaje = new javax.swing.JTextField();
        txtDiscapacidad = new javax.swing.JTextField();
        txtHora = new javax.swing.JFormattedTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jButton3 = new javax.swing.JButton();
        PUpper = new java.awt.Panel();
        ExitSys = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51), 5));
        jPanel2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel2.setLayout(null);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(null);

        jLabel2.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel2.setText("Total");
        jPanel3.add(jLabel2);
        jLabel2.setBounds(50, 360, 50, 30);

        jLabel3.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel3.setText("Id Viaje");
        jPanel3.add(jLabel3);
        jLabel3.setBounds(40, 30, 70, 30);

        jLabel4.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel4.setText("Nombre");
        jPanel3.add(jLabel4);
        jLabel4.setBounds(40, 160, 70, 30);

        jLabel6.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel6.setText("Apellido");
        jPanel3.add(jLabel6);
        jLabel6.setBounds(40, 200, 70, 30);

        jLabel7.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel7.setText("Discapacidad");
        jPanel3.add(jLabel7);
        jLabel7.setBounds(20, 240, 110, 30);

        txtApellido.setEditable(false);
        txtApellido.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        jPanel3.add(txtApellido);
        txtApellido.setBounds(140, 200, 250, 30);

        jLabel5.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel5.setText("Hora");
        jPanel3.add(jLabel5);
        jLabel5.setBounds(50, 70, 40, 30);

        txtNombre.setEditable(false);
        txtNombre.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        jPanel3.add(txtNombre);
        txtNombre.setBounds(140, 160, 250, 30);

        jLabel8.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel8.setText("Id Cliente");
        jPanel3.add(jLabel8);
        jLabel8.setBounds(30, 110, 80, 30);

        txtCodigo.setEditable(false);
        try {
            txtCodigo.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("#### - #### - #####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtCodigo.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        txtCodigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCodigoKeyReleased(evt);
            }
        });
        jPanel3.add(txtCodigo);
        txtCodigo.setBounds(140, 110, 250, 30);

        txtCosto.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        txtCosto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtCostoMouseClicked(evt);
            }
        });
        txtCosto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCostoActionPerformed(evt);
            }
        });
        jPanel3.add(txtCosto);
        txtCosto.setBounds(140, 360, 250, 30);

        jLabel11.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel11.setText("Aerolinea");
        jPanel3.add(jLabel11);
        jLabel11.setBounds(40, 280, 80, 30);

        txtAerolinea.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        jPanel3.add(txtAerolinea);
        txtAerolinea.setBounds(140, 280, 250, 30);

        jLabel12.setFont(new java.awt.Font("Roboto Black", 1, 16)); // NOI18N
        jLabel12.setText("Dir. Aerolinea");
        jPanel3.add(jLabel12);
        jLabel12.setBounds(10, 320, 110, 30);

        txtDireccion.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        jPanel3.add(txtDireccion);
        txtDireccion.setBounds(140, 320, 250, 30);

        idViaje.setEditable(false);
        idViaje.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        jPanel3.add(idViaje);
        idViaje.setBounds(140, 30, 250, 30);

        txtDiscapacidad.setEditable(false);
        txtDiscapacidad.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        jPanel3.add(txtDiscapacidad);
        txtDiscapacidad.setBounds(140, 240, 250, 30);

        try {
            txtHora.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##:##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtHora.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        jPanel3.add(txtHora);
        txtHora.setBounds(140, 70, 250, 30);

        jPanel2.add(jPanel3);
        jPanel3.setBounds(10, 60, 470, 410);
        jPanel2.add(jScrollPane2);
        jScrollPane2.setBounds(730, -10, 2, 2);

        jButton3.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/guardar (2).png"))); // NOI18N
        jButton3.setText("Guardar");
        jButton3.setBorderPainted(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton3);
        jButton3.setBounds(160, 470, 170, 56);

        PUpper.setBackground(new java.awt.Color(0, 51, 51));
        PUpper.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PUpperMousePressed(evt);
            }
        });
        PUpper.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                PUpperMouseDragged(evt);
            }
        });
        PUpper.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ExitSys.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/BClose.png"))); // NOI18N
        ExitSys.setContentAreaFilled(false);
        ExitSys.setPreferredSize(new java.awt.Dimension(30, 30));
        ExitSys.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExitSysMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ExitSysMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ExitSysMouseExited(evt);
            }
        });
        ExitSys.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitSysActionPerformed(evt);
            }
        });
        PUpper.add(ExitSys, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 7, 40, 26));

        jLabel20.setFont(new java.awt.Font("Roboto Black", 0, 20)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Software Hotel");
        PUpper.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 7, 191, -1));
        PUpper.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(4, 13, -1, 26));
        PUpper.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 13, -1, 26));
        PUpper.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/LogIc.png"))); // NOI18N
        PUpper.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 7, 30, 30));

        jPanel2.add(PUpper);
        PUpper.setBounds(0, 0, 500, 39);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 501, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 555, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 6, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 501, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 561, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if (txtCodigo.getText().isEmpty() || txtHora.getText().isEmpty() || txtDireccion.getText().isEmpty()
                || txtAerolinea.getText().isEmpty() || txtCosto.getText().isEmpty()||txtHora.getText().isEmpty()) {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "Datos Incompletos, Favor llenar todos los campos");
            not.showNotification();
        } else 
        {
            crearRegistroA();
            
            Reservaciones.CFieldCosto.setText(txtCosto.getText());
            Reservaciones.CFieldIDT.setText(String.valueOf(Cnt2+1));
            Reservaciones.CFieldTipoT.setText("Viaje");
            
                this.dispose();
                
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void ExitSysMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseClicked

    }//GEN-LAST:event_ExitSysMouseClicked

    private void ExitSysMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseEntered

    }//GEN-LAST:event_ExitSysMouseEntered

    private void ExitSysMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitSysMouseExited

    }//GEN-LAST:event_ExitSysMouseExited

    private void ExitSysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitSysActionPerformed
        this.dispose();
    }//GEN-LAST:event_ExitSysActionPerformed

    private void PUpperMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMousePressed
        // TODO add your handling code here:
        //        xMouse = evt.getX();
        //        yMouse = evt.getY();
    }//GEN-LAST:event_PUpperMousePressed

    private void PUpperMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PUpperMouseDragged
        // TODO add your handling code here
        //        int x = evt.getXOnScreen();
        //        int y = evt.getYOnScreen();
        //        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_PUpperMouseDragged

    private void txtCodigoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCodigoKeyReleased
        int valor = 0;
        int conta = 0;
        String nomconsulta = "Identidad";
        try {
            conectarBD();
            if (nomconsulta.equals("Identidad")) {
                senteciaSQL = ("SELECT COUNT(*) FROM cliente WHERE UPPER(identidad) LIKE (UPPER('%" + txtCodigo.getText() + "%')) AND estado='Activo'");
                ps = con.prepareStatement(senteciaSQL);
                rs = ps.executeQuery();
            }

            if (rs.next()) {
                valor = rs.getInt(1);
            }

            datosViajesB = new String[valor][8];
            if (nomconsulta.equals("Identidad")) {
                senteciaSQL = ("SELECT * FROM cliente WHERE  UPPER(identidad) LIKE (UPPER('%" + txtCodigo.getText() + "%')) AND estado='Activo'");
                ps = con.prepareStatement(senteciaSQL);
                rs = ps.executeQuery();
            }
            while (rs.next()) {
                txtNombre.setText(rs.getString(3));
                txtApellido.setText(rs.getString(4));
                txtDiscapacidad.setText(rs.getString(7));
            }

        } catch (Exception e) {
        }
    }//GEN-LAST:event_txtCodigoKeyReleased

    private void txtCostoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtCostoMouseClicked
        if (txtDiscapacidad.getText().isEmpty()) {
            Notification not = new Notification(this, Notification.Type.WARNING, Notification.Location.TOP_CENTER, "INGRESE DATOS DE CLIENTE");
            not.showNotification();
        } else if (txtDiscapacidad.equals("Si")) {

           String AdHere = Reservaciones.Ad;
           int AdN = Integer.parseInt(AdHere);
            
            totalDis = (700 * 0.35)*AdN ;
            costo = Double.toString(totalDis);
            txtCosto.setText(costo);
            
        } else {
            
           String AdHere = Reservaciones.Ad;
           int AdN = Integer.parseInt(AdHere);
            
            totalDis = 700*AdN ;
            
            costo = Double.toString(totalDis);
            txtCosto.setText(costo);
        }
    }//GEN-LAST:event_txtCostoMouseClicked

    private void txtCostoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCostoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCostoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(rentaViajes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(rentaViajes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(rentaViajes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(rentaViajes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new rentaViajes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ExitSys;
    private java.awt.Panel PUpper;
    private javax.swing.JTextField idViaje;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField txtAerolinea;
    public static javax.swing.JTextField txtApellido;
    public static javax.swing.JFormattedTextField txtCodigo;
    private javax.swing.JTextField txtCosto;
    private javax.swing.JTextField txtDireccion;
    public static javax.swing.JTextField txtDiscapacidad;
    private javax.swing.JFormattedTextField txtHora;
    public static javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables
}
